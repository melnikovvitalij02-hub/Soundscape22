import { useState, useCallback } from 'react';
import { Search, Play, Music2, Loader2, Pause, ListMusic, Youtube, AlertCircle } from 'lucide-react';
import { usePlayer, type PlayerTrack } from '@/context/PlayerContext';
import { useLocale } from '@/context/LocaleContext';

type Track = PlayerTrack & {
  previewUrl?: string;
  albumId: string;
  albumName: string;
  releaseDate: string;
};

const SUPABASE_URL = 'https://cccoflivuzxzujieuhvo.supabase.co';
const SUPABASE_ANON_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImNjY29mbGl2dXp4enVqaWV1aHZvIiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODg4ODk3MDcsImV4cCI6MjEwNDQ2NTcwN30.-suTh6a9r7yQOPacLl7Ez8mrFIw7kKrepkqNT964bNI';

export default function MusicSearchPage() {
  const { currentTrack, isPlaying, play, toggle, playQueue, queue } = usePlayer();
  const { t } = useLocale();
  const [query, setQuery] = useState('');
  const [results, setResults] = useState<Track[]>([]);
  const [loading, setLoading] = useState(false);
  const [searched, setSearched] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const search = useCallback(async () => {
    if (!query.trim()) return;
    setLoading(true);
    setSearched(true);
    setError(null);

    try {
      const res = await fetch(
        `${SUPABASE_URL}/functions/v1/music-search?q=${encodeURIComponent(query)}`,
        { headers: { Authorization: `Bearer ${SUPABASE_ANON_KEY}`, Apikey: SUPABASE_ANON_KEY } },
      );
      if (!res.ok) {
        setError(t('Сервис поиска временно недоступен'));
        setResults([]);
        setLoading(false);
        return;
      }
      const data = await res.json();
      const tracks: Track[] = (data.results || []).map((r: Record<string, unknown>) => ({
        id: String(r.id),
        title: String(r.title || t('Без названия')),
        artist: String(r.artist || t('Неизвестен')),
        cover: r.cover as string | undefined,
        url: String(r.url),
        albumId: String(r.albumId),
        albumName: String(r.albumName),
        releaseDate: String(r.releaseDate),
      }));
      tracks.sort((a, b) => b.releaseDate.localeCompare(a.releaseDate));
      setResults(tracks);
    } catch {
      setError(t('Не удалось подключиться к сервису поиска'));
      setResults([]);
    }
    setLoading(false);
  }, [query, t]);

  const handlePlay = (track: Track) => {
    if (currentTrack?.id === track.id) {
      toggle();
    } else {
      play(track);
    }
  };

  const playAll = () => {
    if (results.length > 0) {
      playQueue(results, 0);
    }
  };

  const isCurrentPlaying = (trackId: string) => currentTrack?.id === trackId && isPlaying;

  const youtubeLink = (track: Track) =>
    `https://www.youtube.com/results?search_query=${encodeURIComponent(`${track.artist} ${track.title} official audio`)}`;

  const albumGroups = results.reduce<{ id: string; name: string; releaseDate: string; tracks: Track[] }[]>((groups, track) => {
    const group = groups.find((item) => item.id === track.albumId);
    if (group) {
      group.tracks.push(track);
      if (track.releaseDate > group.releaseDate) group.releaseDate = track.releaseDate;
    } else {
      groups.push({ id: track.albumId, name: track.albumName, releaseDate: track.releaseDate, tracks: [track] });
    }
    return groups;
  }, []).sort((a, b) => b.releaseDate.localeCompare(a.releaseDate));

  const renderTrackCard = (track: Track) => {
    const playing = isCurrentPlaying(track.id);
    return (
      <div key={track.id} className="track-card">
        <button
          onClick={() => handlePlay(track)}
          className="track-card-cover"
          type="button"
          aria-label={playing ? t('Пауза') : t('Слушать превью')}
        >
          {track.cover ? (
            <img src={track.cover} alt={track.title} />
          ) : (
            <div className="cover-placeholder">
              <Music2 size={48} />
            </div>
          )}
          <div className="cover-gradient" />
          <div className="cover-play-overlay">
            <div className={`cover-play-btn ${playing ? 'playing' : ''}`}>
              {playing
                ? <Pause size={24} fill="currentColor" />
                : <Play size={24} fill="currentColor" style={{ marginLeft: 2 }} />}
            </div>
          </div>
          {playing && (
            <div className="track-preview-badge">
              <div className="bars"><span /><span /><span /></div>
              <span>{t('Превью 30с')}</span>
            </div>
          )}
        </button>
        <div className="track-card-info">
          <p className="track-card-title">{track.title}</p>
          <p className="track-card-artist">{track.artist}</p>
        </div>
        <div className="track-card-actions">
          <button onClick={() => handlePlay(track)} className="track-action-btn play" type="button">
            {playing
              ? <><Pause size={14} /> {t('Пауза')}</>
              : <><Play size={14} /> {t('30с')}</>}
          </button>
          <a
            href={youtubeLink(track)}
            target="_blank"
            rel="noopener noreferrer"
            className="track-action-btn youtube"
          >
            <Youtube size={14} /> YouTube
          </a>
        </div>
      </div>
    );
  };

  return (
    <div className="space-y-6">
      <div className="page-header">
        <h1 className="page-title">
          <Search className="w-6 h-6" />
          {t('Поиск Музыки')}
        </h1>
        <p className="page-subtitle">
          {t('Слушай 30-секундное превью или открывай полную версию на YouTube')}
        </p>
      </div>

      <div className="search-container">
        <div className="page-search-wrapper">
          <Search className="page-search-icon" />
          <input
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && search()}
            placeholder={t('Введи название песни или исполнителя...')}
            className="page-search-input"
          />
        </div>
        <button onClick={search} disabled={loading} className="search-btn disabled:opacity-50">
          {loading ? <Loader2 className="w-5 h-5 animate-spin" /> : t('Искать')}
        </button>
      </div>

      {loading ? (
        <div className="search-loading">
          <Loader2 size={32} />
        </div>
      ) : error ? (
        <div className="empty-state">
          <div className="empty-icon error">
            <AlertCircle size={32} />
          </div>
          <div className="empty-title">{t('Ошибка')}</div>
          <div className="empty-text">{error}</div>
        </div>
      ) : !searched ? (
        <div className="empty-state">
          <div className="empty-icon"><Music2 size={32} /></div>
          <div className="empty-title">{t('Начни поиск')}</div>
          <div className="empty-text">
            {t('Введи название песни или имя исполнителя в строке поиска выше и нажми «Искать». 30 секунд превью здесь — полная версия на YouTube.')}
          </div>
        </div>
      ) : results.length === 0 ? (
        <div className="empty-state">
          <div className="empty-icon"><Music2 size={32} /></div>
          <div className="empty-title">{t('Ничего не найдено')}</div>
          <div className="empty-text">{t('По запросу')} «{query}» {t('ничего не найдено. Попробуй изменить запрос.')}</div>
        </div>
      ) : (
        <>
          <div className="search-results-bar">
            <p className="search-results-count">
              {t('Найдено')} {results.length} {t('треков. «30с» — превью, «YouTube» — полная версия.')}
            </p>
            <button onClick={playAll} className="search-play-all-btn" type="button">
              <ListMusic size={16} /> {t('Играть все превью')}
            </button>
          </div>
          <div>
            {albumGroups.map((album) => (
              <section key={album.id} className="album-group">
                <div className="album-group-header">
                  <h2 className="album-group-title">{album.name}</h2>
                  <span className="album-group-count">{album.tracks.length} {t('треков')}</span>
                </div>
                <div className="track-grid">
                  {album.tracks.map(renderTrackCard)}
                </div>
              </section>
            ))}
          </div>
        </>
      )}
    </div>
  );
}