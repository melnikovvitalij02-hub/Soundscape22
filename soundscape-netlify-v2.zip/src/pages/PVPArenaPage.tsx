import { useState, useEffect, useCallback } from 'react';
import { useAuth } from '@/context/AuthContext';
import { useLocale } from '@/context/LocaleContext';
import { supabase } from '@/lib/supabase';
import { Swords, Trophy, Search, Coins, Vote, Crown, Loader2, TrendingUp, TrendingDown, Zap, Users, Shield, Medal, Flame } from 'lucide-react';

type Beat = { id: string; user_id: string; title: string; genre: string; bpm: number; cover_url: string | null };
type ArenaMatch = { id: string; season_id: string | null; player_a_id: string; player_b_id: string; beat_a_id: string | null; beat_b_id: string | null; status: string; winner_id: string | null; rating_delta_a: number; rating_delta_b: number; spectator_votes_a: number; spectator_votes_b: number; total_bets_a: number; total_bets_b: number; coins_pool_a: number; coins_pool_b: number; genre: string | null; created_at: string; ends_at: string };
type RatingRow = { id: string; user_id: string; season_id: string; rating: number; wins: number; losses: number; streak: number; best_streak: number };
type Season = { id: string; name: string; month: number; year: number; start_date: string; end_date: string; is_current: boolean };
type MatchWithBeats = ArenaMatch & { beatA: Beat | null; beatB: Beat | null; myVote: 'a' | 'b' | null; myBet: number };
type LeaderRow = RatingRow & { username: string; avatar_url: string | null };

const COVER = '/cover-igotu.webp';
const BET_AMOUNTS = [10, 50, 100];

function getTier(rating: number) {
  if (rating >= 1800) return { name: 'Алмаз', Icon: Crown, color: 'text-cyan-400', ring: 'border-cyan-400/40', bg: 'bg-cyan-400/10' };
  if (rating >= 1600) return { name: 'Платина', Icon: Zap, color: 'text-emerald-400', ring: 'border-emerald-400/40', bg: 'bg-emerald-400/10' };
  if (rating >= 1400) return { name: 'Золото', Icon: Trophy, color: 'text-yellow-400', ring: 'border-yellow-400/40', bg: 'bg-yellow-400/10' };
  if (rating >= 1200) return { name: 'Серебро', Icon: Shield, color: 'text-slate-300', ring: 'border-slate-300/40', bg: 'bg-slate-300/10' };
  return { name: 'Бронза', Icon: Medal, color: 'text-amber-600', ring: 'border-amber-600/40', bg: 'bg-amber-600/10' };
}

export default function PVPArenaPage() {
  const { profile, isGuest, addCoins, refreshProfile } = useAuth();
  const { t } = useLocale();
  const [season, setSeason] = useState<Season | null>(null);
  const [myRating, setMyRating] = useState<RatingRow | null>(null);
  const [myBeats, setMyBeats] = useState<Beat[]>([]);
  const [active, setActive] = useState<MatchWithBeats[]>([]);
  const [history, setHistory] = useState<MatchWithBeats[]>([]);
  const [leaderboard, setLeaderboard] = useState<LeaderRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [searching, setSearching] = useState(false);
  const [showModal, setShowModal] = useState(false);
  const [selectedBeat, setSelectedBeat] = useState<string | null>(null);
  const [busy, setBusy] = useState<string | null>(null);
  const [status, setStatus] = useState<string | null>(null);
  const [tab, setTab] = useState<'arena' | 'leaderboard' | 'history'>('arena');

  const flash = (msg: string) => { setStatus(msg); setTimeout(() => setStatus(null), 2500); };

  const loadMyRating = useCallback(async (seasonId: string): Promise<RatingRow | null> => {
    if (!profile) return null;
    const { data } = await supabase.from('pvp_player_ratings').select('*').eq('user_id', profile.id).eq('season_id', seasonId).maybeSingle();
    if (data) { setMyRating(data as RatingRow); return data as RatingRow; }
    const { data: created } = await supabase.from('pvp_player_ratings').insert({ user_id: profile.id, season_id: seasonId }).select().maybeSingle();
    if (created) setMyRating(created as RatingRow);
    return (created as RatingRow) || null;
  }, [profile]);

  const enrich = useCallback(async (matches: ArenaMatch[]): Promise<MatchWithBeats[]> => {
    const beatIds = new Set<string>();
    matches.forEach((m) => { if (m.beat_a_id) beatIds.add(m.beat_a_id); if (m.beat_b_id) beatIds.add(m.beat_b_id); });
    const beatsMap: Record<string, Beat> = {};
    if (beatIds.size > 0) {
      const { data: beats } = await supabase.from('beats').select('id, user_id, title, genre, bpm, cover_url').in('id', [...beatIds]);
      (beats || []).forEach((b) => { beatsMap[b.id] = b as Beat; });
    }
    const myVotes: Record<string, 'a' | 'b'> = {};
    const myBets: Record<string, number> = {};
    if (profile && matches.length > 0) {
      const ids = matches.map((m) => m.id);
      const [{ data: votes }, { data: bets }] = await Promise.all([
        supabase.from('spectator_votes').select('match_id, vote_for').eq('user_id', profile.id).in('match_id', ids),
        supabase.from('spectator_bets').select('match_id, coins_wagered').eq('user_id', profile.id).in('match_id', ids),
      ]);
      (votes || []).forEach((v) => { myVotes[v.match_id] = v.vote_for as 'a' | 'b'; });
      (bets || []).forEach((b) => { myBets[b.match_id] = (myBets[b.match_id] || 0) + b.coins_wagered; });
    }
    return matches.map((m) => ({ ...m, beatA: m.beat_a_id ? beatsMap[m.beat_a_id] || null : null, beatB: m.beat_b_id ? beatsMap[m.beat_b_id] || null : null, myVote: myVotes[m.id] || null, myBet: myBets[m.id] || 0 }));
  }, [profile]);

  const loadAll = useCallback(async () => {
    if (!profile || isGuest) { setLoading(false); return; }
    const { data: s } = await supabase.from('pvp_seasons').select('*').eq('is_current', true).maybeSingle();
    const cur = s as Season | null;
    setSeason(cur);
    if (cur) await loadMyRating(cur.id);
    const { data: beats } = await supabase.from('beats').select('id, user_id, title, genre, bpm, cover_url').eq('user_id', profile.id).order('created_at', { ascending: false }).limit(20);
    setMyBeats((beats || []) as Beat[]);
    const { data: act } = await supabase.from('pvp_arena_matches').select('*').eq('status', 'active').order('created_at', { ascending: false }).limit(20);
    setActive(await enrich((act || []) as ArenaMatch[]));
    const { data: mine } = await supabase.from('pvp_arena_matches').select('*').or(`player_a_id.eq.${profile.id},player_b_id.eq.${profile.id}`).order('created_at', { ascending: false }).limit(10);
    setHistory(await enrich((mine || []) as ArenaMatch[]));
    if (cur) {
      const { data: lb } = await supabase.from('pvp_player_ratings').select('*').eq('season_id', cur.id).order('rating', { ascending: false }).limit(10);
      const rows = (lb || []) as RatingRow[];
      if (rows.length > 0) {
        const { data: profs } = await supabase.from('profiles').select('id, username, avatar_url').in('id', rows.map((r) => r.user_id));
        const pmap: Record<string, { username: string; avatar_url: string | null }> = {};
        (profs || []).forEach((p) => { pmap[p.id] = { username: p.username, avatar_url: p.avatar_url }; });
        setLeaderboard(rows.map((r) => ({ ...r, username: pmap[r.user_id]?.username || t('Игрок'), avatar_url: pmap[r.user_id]?.avatar_url || null })));
      } else { setLeaderboard([]); }
    }
  }, [profile, isGuest, enrich, loadMyRating]);

  useEffect(() => {
    loadAll().finally(() => setLoading(false));
    const channel = supabase
      .channel('pvp-arena-realtime')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'pvp_arena_matches' }, () => loadAll())
      .on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'spectator_votes' }, () => loadAll())
      .on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'spectator_bets' }, () => loadAll())
      .subscribe();
    return () => { supabase.removeChannel(channel); };
  }, [loadAll]);

  const findMatch = async () => { setSearching(true); await new Promise((r) => setTimeout(r, 1800)); setSearching(false); setShowModal(true); };

  const createBattle = async () => {
    if (!profile || !season || !selectedBeat) return;
    const beat = myBeats.find((b) => b.id === selectedBeat);
    setBusy('create');
    const { error } = await supabase.from('pvp_arena_matches').insert({ season_id: season.id, player_a_id: profile.id, player_b_id: profile.id, beat_a_id: selectedBeat, beat_b_id: null, status: 'active', genre: beat?.genre || null });
    setBusy(null);
    if (error) { flash(t('Ошибка создания битвы')); return; }
    setShowModal(false); setSelectedBeat(null); flash(t('Битва создана! Ждём соперника.')); loadAll();
  };

  const joinBattle = async (match: MatchWithBeats) => {
    if (!profile || !selectedBeat) return;
    setBusy('join-' + match.id);
    const { error } = await supabase.from('pvp_arena_matches').update({ player_b_id: profile.id, beat_b_id: selectedBeat }).eq('id', match.id);
    setBusy(null);
    if (error) { flash(t('Не удалось присоединиться')); return; }
    setShowModal(false); setSelectedBeat(null); flash(t('Ты в битве!')); loadAll();
  };

  const vote = async (match: MatchWithBeats, side: 'a' | 'b') => {
    if (!profile || match.myVote) return;
    setBusy('vote-' + match.id + side);
    const { error } = await supabase.from('spectator_votes').insert({ match_id: match.id, user_id: profile.id, vote_for: side });
    if (error) { setBusy(null); flash(t('Ошибка голосования')); return; }
    const upd = side === 'a' ? { spectator_votes_a: match.spectator_votes_a + 1 } : { spectator_votes_b: match.spectator_votes_b + 1 };
    await supabase.from('pvp_arena_matches').update(upd).eq('id', match.id);
    setBusy(null); loadAll();
  };

  const placeBet = async (match: MatchWithBeats, side: 'a' | 'b', amount: number) => {
    if (!profile) return;
    if ((profile.coins ?? 0) < amount) { flash(t('Недостаточно монет')); return; }
    if (match.myBet > 0) { flash(t('Ты уже сделал ставку')); return; }
    setBusy('bet-' + match.id + side + amount);
    const { error } = await supabase.from('spectator_bets').insert({ match_id: match.id, user_id: profile.id, bet_on: side, coins_wagered: amount });
    if (error) { setBusy(null); flash(t('Ошибка ставки')); return; }
    const upd = side === 'a' ? { total_bets_a: match.total_bets_a + 1, coins_pool_a: match.coins_pool_a + amount } : { total_bets_b: match.total_bets_b + 1, coins_pool_b: match.coins_pool_b + amount };
    await supabase.from('pvp_arena_matches').update(upd).eq('id', match.id);
    await addCoins(-amount);
    setBusy(null); flash(t('Ставка принята!')); loadAll();
  };

  const endMatch = async (match: MatchWithBeats) => {
    if (!profile || !season) return;
    setBusy('end-' + match.id);
    const sid = match.season_id || season.id;
    const base = { rating: 1000, streak: 0, wins: 0, losses: 0, best_streak: 0, user_id: '', season_id: sid, id: '' };
    const { data: ra } = await supabase.from('pvp_player_ratings').select('*').eq('user_id', match.player_a_id).eq('season_id', sid).maybeSingle();
    const { data: rb } = await supabase.from('pvp_player_ratings').select('*').eq('user_id', match.player_b_id).eq('season_id', sid).maybeSingle();
    const ratingA = (ra as RatingRow | null) || ({ ...base, user_id: match.player_a_id } as RatingRow);
    const ratingB = (rb as RatingRow | null) || ({ ...base, user_id: match.player_b_id } as RatingRow);
    let winnerId: string | null = null, deltaA = 0, deltaB = 0, draw = false;
    if (match.spectator_votes_a > match.spectator_votes_b) { winnerId = match.player_a_id; deltaA = 25 + Math.min(ratingA.streak * 5, 15); deltaB = -25; }
    else if (match.spectator_votes_b > match.spectator_votes_a) { winnerId = match.player_b_id; deltaB = 25 + Math.min(ratingB.streak * 5, 15); deltaA = -25; }
    else { draw = true; }
    await supabase.from('pvp_arena_matches').update({ status: 'completed', winner_id: winnerId, rating_delta_a: deltaA, rating_delta_b: deltaB }).eq('id', match.id);
    const isA = match.player_a_id === profile.id, isB = match.player_b_id === profile.id;
    if (isA || isB) {
      const myRow = isA ? ratingA : ratingB, myDelta = isA ? deltaA : deltaB;
      const won = winnerId === profile.id;
      const newStreak = won ? myRow.streak + 1 : draw ? myRow.streak : 0;
      await supabase.from('pvp_player_ratings').update({ rating: myRow.rating + myDelta, wins: won ? myRow.wins + 1 : myRow.wins, losses: !won && !draw ? myRow.losses + 1 : myRow.losses, streak: newStreak, best_streak: Math.max(myRow.best_streak, newStreak) }).eq('user_id', profile.id).eq('season_id', myRow.season_id);
    }
    setBusy(null); flash(draw ? t('Ничья! Рейтинг не изменился') : t('Битва завершена!')); loadAll(); refreshProfile?.();
  };

  const coverFor = (b: Beat | null) => b?.cover_url || COVER;
  const tier = getTier(myRating?.rating ?? 1000);
  const liveMatches = active.filter((m) => m.player_a_id !== m.player_b_id);
  const openMatches = active.filter((m) => m.player_a_id === m.player_b_id && m.player_a_id !== profile?.id);
  const daysLeft = season ? Math.max(0, Math.ceil((new Date(season.end_date).getTime() - Date.now()) / 86400000)) : 0;
  const isParticipant = (m: MatchWithBeats) => !!profile && (m.player_a_id === profile.id || m.player_b_id === profile.id);
  const pastDeadline = (m: MatchWithBeats) => new Date(m.ends_at).getTime() < Date.now();

  const TABS: { id: typeof tab; label: string; icon: typeof Swords }[] = [
    { id: 'arena', label: t('Арена'), icon: Swords },
    { id: 'leaderboard', label: t('Топ'), icon: Trophy },
    { id: 'history', label: t('История'), icon: TrendingUp },
  ];

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-theme-text flex items-center gap-2"><Swords className="w-6 h-6 text-theme-primary" /> {t('PvP Арена')}</h1>
        <p className="text-theme-muted text-sm mt-1">{t('Музыкальные битвы онлайн — шахматы, но для битов')}</p>
      </div>

      {/* Season + rating hero */}
      <div className={`glass-surface ${tier.bg} border ${tier.ring} rounded-2xl p-4 flex flex-col sm:flex-row items-center gap-4`}>
        <div className={`shrink-0 w-16 h-16 rounded-2xl ${tier.bg} border ${tier.ring} flex items-center justify-center`}>
          <tier.Icon className={`w-8 h-8 ${tier.color}`} />
        </div>
        <div className="flex-1 min-w-0">
          <p className="text-xs text-theme-muted uppercase tracking-wider">{t('Сезон')} · {season?.name || '—'}</p>
          <p className="text-lg font-bold text-theme-text flex items-center gap-2">{t(tier.name)} <span className={`text-sm font-mono ${tier.color}`}>{myRating?.rating ?? 1000}</span></p>
          <p className="text-xs text-theme-muted mt-0.5"><Flame className="w-3 h-3 inline text-theme-warning" /> {t('Серия:')}: {myRating?.streak ?? 0} · {t('Лучшая:')}: {myRating?.best_streak ?? 0} · W{myRating?.wins ?? 0}/L{myRating?.losses ?? 0} · {t('До конца сезона:')}: {daysLeft} {t('дн.')}</p>
        </div>
        <button onClick={findMatch} disabled={searching || !profile} className="px-5 py-2.5 bg-theme-primary text-white rounded-xl text-sm font-semibold hover:bg-theme-primary-hover transition-colors flex items-center gap-2 disabled:opacity-60">
          {searching ? <Loader2 className="w-4 h-4 animate-spin" /> : <Search className="w-4 h-4" />}{searching ? t('Поиск соперника...') : t('Найти битву')}
        </button>
      </div>

      {status && <div className="px-4 py-2 rounded-lg bg-theme-primary-bg border border-theme-primary-border text-theme-primary-text text-sm">{status}</div>}

      {/* Tabs */}
      <div className="flex gap-1 glass-surface bg-theme-surface/50 border border-theme-border rounded-xl p-1">
        {TABS.map((t) => (
          <button key={t.id} onClick={() => setTab(t.id)} className={`flex-1 px-3 py-2 rounded-lg text-sm font-medium flex items-center justify-center gap-1.5 transition-colors ${tab === t.id ? 'bg-theme-primary text-white' : 'text-theme-muted hover:text-theme-text hover:bg-theme-surface2'}`}>
            <t.icon className="w-4 h-4" /> {t.label}
          </button>
        ))}
      </div>

      {loading ? (
        <div className="flex items-center justify-center py-12"><Loader2 className="w-6 h-6 text-theme-muted animate-spin" /></div>
      ) : tab === 'arena' ? (
        <div className="space-y-4">
          {liveMatches.length === 0 ? (
            <div className="glass-surface bg-theme-surface/50 border border-theme-border rounded-2xl p-8 text-center"><Swords className="w-12 h-12 text-theme-muted mx-auto mb-3" /><p className="text-theme-muted">{t('Активных битв пока нет. Жми «Найти битву»!')}</p></div>
          ) : liveMatches.map((m) => {
            const total = m.spectator_votes_a + m.spectator_votes_b;
            const pctA = total > 0 ? (m.spectator_votes_a / total) * 100 : 50;
            const pctB = total > 0 ? (m.spectator_votes_b / total) * 100 : 50;
            const canEnd = isParticipant(m) || pastDeadline(m);
            return (
              <div key={m.id} className="glass-surface bg-theme-surface/60 border border-theme-border rounded-2xl p-4">
                <div className="flex items-center justify-between mb-3">
                  <span className="px-2 py-0.5 rounded-md text-xs font-medium bg-theme-success/15 text-theme-success flex items-center gap-1"><Users className="w-3 h-3" /> LIVE · {total} {t('голосов')}</span>
                  <span className="text-xs text-theme-muted flex items-center gap-1"><Coins className="w-3 h-3 text-theme-warning" /> {t('Банк:')}: {m.coins_pool_a + m.coins_pool_b}</span>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 items-stretch">
                  <BeatSide beat={m.beatA} side="a" pct={pctA} votes={m.spectator_votes_a} pool={m.coins_pool_a} bets={m.total_bets_a} myVote={m.myVote} myBet={m.myBet} busy={busy} onVote={() => vote(m, 'a')} onBet={(amt) => placeBet(m, 'a', amt)} color="primary" />
                  <BeatSide beat={m.beatB} side="b" pct={pctB} votes={m.spectator_votes_b} pool={m.coins_pool_b} bets={m.total_bets_b} myVote={m.myVote} myBet={m.myBet} busy={busy} onVote={() => vote(m, 'b')} onBet={(amt) => placeBet(m, 'b', amt)} color="accent" />
                </div>
                <div className="flex items-center justify-center gap-2 mt-3 pointer-events-none relative z-10">
                  <span className="px-3 py-1 rounded-full bg-theme-surface2 border border-theme-primary/40 text-theme-text text-xs font-bold shadow-lg">VS</span>
                </div>
                {canEnd && (
                  <button onClick={() => endMatch(m)} disabled={busy === 'end-' + m.id} className="mt-4 w-full px-3 py-2 rounded-lg bg-theme-surface2 border border-theme-border text-theme-text text-sm font-medium hover:border-theme-primary transition-colors flex items-center justify-center gap-2">
                    {busy === 'end-' + m.id ? <Loader2 className="w-4 h-4 animate-spin" /> : <Trophy className="w-4 h-4 text-theme-warning" />} {t('Завершить битву')}
                  </button>
                )}
              </div>
            );
          })}
        </div>
      ) : tab === 'leaderboard' ? (
        <div className="glass-surface bg-theme-surface/60 border border-theme-border rounded-2xl divide-y divide-theme-border">
          {leaderboard.length === 0 ? (
            <div className="p-8 text-center text-theme-muted">{t('Рейтинг пока пуст. Сыграй первую битву!')}</div>
          ) : leaderboard.map((p, i) => {
            const pt = getTier(p.rating);
            return (
              <div key={p.id} className="flex items-center gap-3 p-3">
                <div className={`w-7 text-center font-bold ${i === 0 ? 'text-theme-warning' : i < 3 ? 'text-theme-primary' : 'text-theme-muted'}`}>{i === 0 ? <Crown className="w-5 h-5 mx-auto text-theme-warning" /> : i + 1}</div>
                <img src={p.avatar_url || COVER} alt="" className="w-9 h-9 rounded-full object-cover" />
                <div className="flex-1 min-w-0">
                  <p className="text-sm text-theme-text font-medium truncate">{p.username}</p>
                  <p className={`text-xs ${pt.color} flex items-center gap-1`}><pt.Icon className="w-3 h-3" /> {t(pt.name)} · W{p.wins}/L{p.losses} · <Flame className="w-3 h-3 text-theme-warning" />{p.best_streak}</p>
                </div>
                <span className={`font-mono font-bold ${pt.color}`}>{p.rating}</span>
              </div>
            );
          })}
        </div>
      ) : (
        <div className="space-y-3">
          {history.length === 0 ? (
            <div className="glass-surface bg-theme-surface/50 border border-theme-border rounded-2xl p-8 text-center text-theme-muted">{t('У тебя пока нет битв.')}</div>
          ) : history.map((m) => {
            const won = m.winner_id === profile?.id, draw = m.status === 'completed' && !m.winner_id;
            const myDelta = m.player_a_id === profile?.id ? m.rating_delta_a : m.rating_delta_b;
            const side = m.player_a_id === profile?.id ? 'a' : 'b';
            const myBeat = side === 'a' ? m.beatA : m.beatB, oppBeat = side === 'a' ? m.beatB : m.beatA;
            return (
              <div key={m.id} className="glass-surface bg-theme-surface/60 border border-theme-border rounded-xl p-3 flex items-center gap-3">
                <div className={`shrink-0 w-10 h-10 rounded-lg flex items-center justify-center ${won ? 'bg-theme-success/15' : draw ? 'bg-theme-surface2' : 'bg-theme-warning/10'}`}>
                  {won ? <Trophy className="w-5 h-5 text-theme-success" /> : draw ? <Shield className="w-5 h-5 text-theme-muted" /> : <Swords className="w-5 h-5 text-theme-warning" />}
                </div>
                <img src={coverFor(myBeat)} alt="" className="w-10 h-10 rounded-lg object-cover" />
                <div className="flex-1 min-w-0">
                  <p className="text-sm text-theme-text font-medium truncate">{myBeat?.title || '—'} vs {oppBeat?.title || t('Ожидание...')}</p>
                  <p className="text-xs text-theme-muted">{m.genre || '—'} · {m.status === 'active' ? t('Идёт') : t('Завершено')}</p>
                </div>
                {m.status === 'completed' && (
                  <span className={`flex items-center gap-1 text-sm font-mono font-bold ${myDelta > 0 ? 'text-theme-success' : myDelta < 0 ? 'text-theme-warning' : 'text-theme-muted'}`}>
                    {myDelta > 0 ? <TrendingUp className="w-4 h-4" /> : myDelta < 0 ? <TrendingDown className="w-4 h-4" /> : null}{myDelta > 0 ? '+' : ''}{myDelta}
                  </span>
                )}
              </div>
            );
          })}
        </div>
      )}

      {/* Find / Create / Join modal */}
      {showModal && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4" onClick={() => setShowModal(false)}>
          <div className="glass-surface bg-theme-surface border border-theme-border rounded-2xl p-6 w-full max-w-lg space-y-4 max-h-[85vh] overflow-y-auto" onClick={(e) => e.stopPropagation()}>
            <div className="flex items-center justify-between">
              <h3 className="text-theme-text font-semibold flex items-center gap-2"><Swords className="w-5 h-5 text-theme-primary" /> {t('Найти битву')}</h3>
              <button onClick={() => setShowModal(false)} className="text-theme-muted hover:text-theme-text text-xl leading-none">×</button>
            </div>
            {myBeats.length === 0 ? (
              <p className="text-sm text-theme-muted text-center py-4">{t('Сначала создай бит в секвенсоре!')}</p>
            ) : (
              <>
                <div>
                  <p className="text-xs text-theme-muted uppercase tracking-wider mb-2">{t('Выбери свой бит')}</p>
                  <div className="space-y-1 max-h-44 overflow-y-auto">
                    {myBeats.map((b) => (
                      <button key={b.id} onClick={() => setSelectedBeat(b.id)} className={`w-full flex items-center gap-2 px-2 py-1.5 rounded-lg text-left transition-colors ${selectedBeat === b.id ? 'bg-theme-primary-bg border border-theme-primary-border' : 'hover:bg-theme-surface2 border border-transparent'}`}>
                        <img src={coverFor(b)} alt="" className="w-8 h-8 rounded object-cover" />
                        <span className="text-sm text-theme-text truncate flex-1">{b.title}</span>
                        <span className="text-xs text-theme-muted">{b.genre} · {b.bpm}</span>
                      </button>
                    ))}
                  </div>
                </div>
                {openMatches.length > 0 && (
                  <div>
                    <p className="text-xs text-theme-muted uppercase tracking-wider mb-2 flex items-center gap-1"><Users className="w-3 h-3" /> {t('Открытые битвы')} ({openMatches.length})</p>
                    <div className="space-y-1 max-h-40 overflow-y-auto">
                      {openMatches.map((m) => (
                        <button key={m.id} onClick={() => joinBattle(m)} disabled={!selectedBeat || busy === 'join-' + m.id} className="w-full flex items-center gap-2 px-2 py-1.5 rounded-lg text-left bg-theme-surface2 hover:border-theme-primary border border-transparent disabled:opacity-50 transition-colors">
                          {busy === 'join-' + m.id ? <Loader2 className="w-4 h-4 animate-spin text-theme-primary" /> : <Swords className="w-4 h-4 text-theme-primary" />}
                          <img src={coverFor(m.beatA)} alt="" className="w-8 h-8 rounded object-cover" />
                          <span className="text-sm text-theme-text truncate flex-1">{t('Присоединиться к «')} {m.beatA?.title || t('битва')}»</span>
                        </button>
                      ))}
                    </div>
                  </div>
                )}
                <button onClick={createBattle} disabled={!selectedBeat || busy === 'create'} className="w-full px-4 py-2.5 bg-theme-primary text-white rounded-lg text-sm font-semibold hover:bg-theme-primary-hover transition-colors disabled:opacity-50 flex items-center justify-center gap-2">
                  {busy === 'create' ? <Loader2 className="w-4 h-4 animate-spin" /> : <Swords className="w-4 h-4" />} {t('Создать новую битву')}
                </button>
              </>
            )}
          </div>
        </div>
      )}
    </div>
  );
}

function BeatSide({ beat, side, pct, votes, pool, bets, myVote, myBet, busy, onVote, onBet, color }: {
  beat: Beat | null; side: 'a' | 'b'; pct: number; votes: number; pool: number; bets: number; myVote: 'a' | 'b' | null; myBet: number; busy: string | null; onVote: () => void; onBet: (amt: number) => void; color: 'primary' | 'accent';
}) {
  const { t } = useLocale();
  const accent = color === 'primary' ? 'bg-theme-primary' : 'bg-theme-accent';
  const votedHere = myVote === side;
  const borderCls = votedHere ? (color === 'primary' ? 'border-theme-primary bg-theme-primary-bg' : 'border-theme-accent bg-theme-primary-bg') : 'border-theme-border bg-theme-surface2';
  return (
    <div className={`relative rounded-xl border p-3 transition-all ${borderCls}`}>
      <img src={beat?.cover_url || COVER} alt="" className="w-full h-20 rounded-lg object-cover mb-2" />
      <p className="text-sm text-theme-text font-medium truncate">{beat?.title || `${t('Бит')} ${side.toUpperCase()}`}</p>
      <p className="text-xs text-theme-muted">{beat ? `${beat.genre} · ${beat.bpm} BPM` : t('Ожидание...')}</p>
      <div className="mt-2 h-1.5 bg-theme-surface rounded-full overflow-hidden"><div className={`h-full ${accent} rounded-full transition-all`} style={{ width: `${pct}%` }} /></div>
      <p className="text-xs text-theme-muted mt-1">{Math.round(pct)}% · {votes} <Vote className="w-3 h-3 inline" /></p>
      <button onClick={onVote} disabled={!!myVote || busy?.startsWith('vote-')} className="mt-2 w-full px-2 py-1.5 rounded-lg text-xs font-medium border border-theme-border bg-theme-surface hover:border-theme-primary text-theme-text disabled:opacity-60 flex items-center justify-center gap-1">
        {votedHere ? <><Vote className="w-3 h-3 text-theme-primary" /> {t('Твой голос')}</> : t('Голосовать')}
      </button>
      <div className="mt-2 grid grid-cols-3 gap-1">
        {BET_AMOUNTS.map((amt) => (
          <button key={amt} onClick={() => onBet(amt)} disabled={myBet > 0 || busy?.startsWith('bet-')} className="px-1 py-1 rounded-md text-[11px] font-medium bg-theme-warning/10 text-theme-warning border border-theme-warning/30 hover:bg-theme-warning/20 disabled:opacity-50 flex items-center justify-center gap-0.5">
            <Coins className="w-3 h-3" /> {amt}
          </button>
        ))}
      </div>
      {myBet > 0 && <p className="text-[10px] text-theme-warning mt-1 text-center">{t('Ставка:')} {myBet}</p>}
      {bets > 0 && <p className="text-[10px] text-theme-muted mt-0.5 text-center">{bets} {t('ставок')} · {pool} {t('монет')}</p>}
    </div>
  );
}
