import { useState, useEffect, useCallback, type ReactNode } from 'react';
import { useAuth } from '@/context/AuthContext';
import { supabase, type AvatarShopItem, type Sticker } from '@/lib/supabase';
import {
  Coins, Check, ShoppingBag, Sparkles, Loader2, Crown, Star, Lock,
  Package, Palette, Zap, Music, Download, TrendingUp,
} from 'lucide-react';
import CoinPurchase from '@/components/CoinPurchase';
import { useLocale } from '@/context/LocaleContext';

type SamplePack = { id: string; name: string; producer_name: string; genre: string; price_coins: number; description: string; track_count: number; cover_url: string | null; is_exclusive: boolean };
type CosmeticItem = { id: string; name: string; type: 'skin' | 'frame' | 'theme' | 'effect'; price_coins: number; rarity: 'common' | 'rare' | 'epic' | 'legendary'; preview_url: string | null; description: string };
type UserCosmetic = { id: string; user_id: string; cosmetic_id: string; is_equipped: boolean; purchased_at: string };
type BoostItem = { id: string; name: string; type: string; price_coins: number; duration_hours: number; description: string };
type TabId = 'coins' | 'samples' | 'cosmetics' | 'boosts' | 'avatars' | 'stickers';

const RARITY_STYLES: Record<string, { border: string; glow: string; badge: string; label: string }> = {
  common: { border: 'border-theme-border', glow: '', badge: 'bg-theme-surface2 text-theme-muted', label: 'Обычный' },
  rare: { border: 'border-blue-500/50', glow: 'shadow-[0_0_15px_rgba(59,130,246,0.2)]', badge: 'bg-blue-500/20 text-blue-400', label: 'Редкий' },
  epic: { border: 'border-purple-500/50', glow: 'shadow-[0_0_15px_rgba(168,85,247,0.25)]', badge: 'bg-purple-500/20 text-purple-400', label: 'Эпический' },
  legendary: { border: 'border-amber-500/50', glow: 'shadow-[0_0_20px_rgba(245,158,11,0.3)]', badge: 'bg-amber-500/20 text-amber-400', label: 'Легендарный' },
};

const AVATAR_GRADIENTS = [
  'from-red-500 to-orange-500', 'from-blue-500 to-cyan-500', 'from-purple-500 to-pink-500',
  'from-green-500 to-emerald-500', 'from-amber-500 to-yellow-500', 'from-indigo-500 to-purple-500',
  'from-rose-500 to-pink-500', 'from-teal-500 to-cyan-500',
];

const TABS: { id: TabId; label: string; icon: typeof Coins }[] = [
  { id: 'coins', label: 'Монеты', icon: Coins },
  { id: 'samples', label: 'Сэмпл-паки', icon: Music },
  { id: 'cosmetics', label: 'Внешний вид', icon: Palette },
  { id: 'boosts', label: 'Ускорения', icon: Zap },
  { id: 'avatars', label: 'Аватары', icon: Crown },
  { id: 'stickers', label: 'Стикеры', icon: Sparkles },
];

const COSMETIC_TYPE_LABELS: Record<string, string> = { skin: 'Скин', frame: 'Рамка', theme: 'Тема', effect: 'Эффект' };

function EmptyState({ icon: Icon, text }: { icon: typeof Coins; text: string }) {
  return (<div className="bg-theme-surface/50 border border-theme-border rounded-2xl p-8 text-center glass-surface shop-card"><Icon className="w-12 h-12 text-theme-muted mx-auto mb-3" /><p className="text-theme-muted">{text}</p></div>);
}

function BuyBtn({ onClick, buyingId, id, canAfford, label, Icon = Coins }: { onClick: () => void; buyingId: string | null; id: string; canAfford: boolean; label: string; Icon?: typeof Coins }) {
  const { t } = useLocale();
  return (
    <button onClick={onClick} disabled={buyingId === id || !canAfford} className={`buy-btn w-full py-2.5 rounded-xl text-sm font-medium transition-all flex items-center justify-center gap-2 ${canAfford ? 'bg-gradient-to-r from-theme-warning to-theme-accent text-white hover:shadow-lg' : 'bg-theme-surface2 text-theme-muted cursor-not-allowed'} disabled:opacity-50`}>
      {buyingId === id ? <Loader2 className="w-4 h-4 animate-spin" /> : !canAfford ? <><Lock className="w-4 h-4" /> {t('Не хватает монет')}</> : <><Icon className="w-4 h-4" /> {label}</>}
    </button>
  );
}

function CoinPrice({ amount }: { amount: number }) {
  return (<div className="flex items-center gap-1.5 mb-3"><span className="coin coin-sm" /><span className="text-theme-text font-bold">{amount}</span></div>);
}

function OwnedBadge({ label, icon: Icon = Check }: { label: string; icon?: typeof Coins }) {
  return (<div className="w-full py-2.5 bg-theme-success/20 text-theme-success rounded-xl text-sm font-medium text-center flex items-center justify-center gap-2"><Icon className="w-4 h-4" /> {label}</div>);
}

function EquipBtn({ onClick, equippingId, id }: { onClick: () => void; equippingId: string | null; id: string }) {
  const { t } = useLocale();
  return (<button onClick={onClick} disabled={equippingId === id} className="w-full py-2.5 bg-theme-primary text-white rounded-xl text-sm font-medium hover:bg-theme-primary-hover transition-colors disabled:opacity-50 flex items-center justify-center gap-2">{equippingId === id ? <Loader2 className="w-4 h-4 animate-spin" /> : <Sparkles className="w-4 h-4" />} {t('Установить')}</button>);
}

function RarityBadge({ rarity, legendary }: { rarity: string; legendary: boolean }) {
  const { t } = useLocale();
  const r = RARITY_STYLES[rarity] || RARITY_STYLES.common;
  return (<div className={`absolute top-2 right-2 px-2 py-0.5 rounded-full text-xs font-bold ${r.badge} flex items-center gap-1`}>{legendary && <Star className="w-3 h-3" fill="currentColor" />}{t(r.label)}</div>);
}

function EquippedBadge() {
  const { t } = useLocale();
  return (<div className="absolute top-2 left-2 px-2 py-0.5 bg-theme-primary text-white text-xs font-medium rounded-full flex items-center gap-1"><Check className="w-3 h-3" /> {t('Активен')}</div>);
}

export default function ShopPage() {
  const { profile, isGuest, refreshProfile } = useAuth();
  const { t } = useLocale();
  const [activeTab, setActiveTab] = useState<TabId>('coins');

  const [samplePacks, setSamplePacks] = useState<SamplePack[]>([]);
  const [ownedSamplePacks, setOwnedSamplePacks] = useState<string[]>([]);
  const [cosmeticItems, setCosmeticItems] = useState<CosmeticItem[]>([]);
  const [ownedCosmetics, setOwnedCosmetics] = useState<string[]>([]);
  const [equippedCosmetics, setEquippedCosmetics] = useState<string[]>([]);
  const [boostItems, setBoostItems] = useState<BoostItem[]>([]);
  const [avatars, setAvatars] = useState<AvatarShopItem[]>([]);
  const [ownedAvatars, setOwnedAvatars] = useState<string[]>([]);
  const [stickers, setStickers] = useState<Sticker[]>([]);
  const [ownedStickers, setOwnedStickers] = useState<string[]>([]);

  const [loading, setLoading] = useState(false);
  const [buying, setBuying] = useState<string | null>(null);
  const [equipping, setEquipping] = useState<string | null>(null);
  const [message, setMessage] = useState<string | null>(null);

  const showMessage = (msg: string) => { setMessage(msg); setTimeout(() => setMessage(null), 3000); };

  const loadTab = useCallback(async (tab: TabId) => {
    if (!profile || isGuest || tab === 'coins') return;
    setLoading(true);
    if (tab === 'samples') {
      const [i, o] = await Promise.all([
        supabase.from('sample_packs').select('*').order('price_coins', { ascending: true }),
        supabase.from('user_sample_packs').select('sample_pack_id').eq('user_id', profile.id),
      ]);
      if (i.data) setSamplePacks(i.data as SamplePack[]);
      if (o.data) setOwnedSamplePacks((o.data as { sample_pack_id: string }[]).map((r) => r.sample_pack_id));
    } else if (tab === 'cosmetics') {
      const [i, o] = await Promise.all([
        supabase.from('cosmetic_items').select('*').order('price_coins', { ascending: true }),
        supabase.from('user_cosmetics').select('cosmetic_id,is_equipped').eq('user_id', profile.id),
      ]);
      if (i.data) setCosmeticItems(i.data as CosmeticItem[]);
      if (o.data) {
        const rows = o.data as UserCosmetic[];
        setOwnedCosmetics(rows.map((r) => r.cosmetic_id));
        setEquippedCosmetics(rows.filter((r) => r.is_equipped).map((r) => r.cosmetic_id));
      }
    } else if (tab === 'boosts') {
      const { data } = await supabase.from('boost_items').select('*').order('price_coins', { ascending: true });
      if (data) setBoostItems(data as BoostItem[]);
    } else if (tab === 'avatars') {
      const [i, o] = await Promise.all([
        supabase.from('avatar_shop_items').select('*').order('price', { ascending: true }),
        supabase.from('user_avatars').select('avatar_shop_item_id').eq('user_id', profile.id),
      ]);
      if (i.data) setAvatars(i.data as AvatarShopItem[]);
      if (o.data) setOwnedAvatars((o.data as { avatar_shop_item_id: string }[]).map((r) => r.avatar_shop_item_id));
    } else if (tab === 'stickers') {
      const [i, o] = await Promise.all([
        supabase.from('stickers').select('*').order('price_coins', { ascending: true }),
        supabase.from('user_stickers').select('sticker_id').eq('user_id', profile.id),
      ]);
      if (i.data) setStickers(i.data as Sticker[]);
      if (o.data) setOwnedStickers((o.data as { sticker_id: string }[]).map((r) => r.sticker_id));
    }
    setLoading(false);
  }, [profile, isGuest]);

  useEffect(() => { loadTab(activeTab); }, [activeTab, loadTab]);

  const getFreshCoins = async (): Promise<number | null> => {
    if (!profile) return null;
    const { data, error } = await supabase.from('profiles').select('coins').eq('id', profile.id).maybeSingle();
    if (error) return null;
    return data?.coins ?? null;
  };

  const purchaseWithCoins = async (
    cost: number, successMsg: string,
    doInsert: () => Promise<{ error: { message: string } | null }>,
  ): Promise<boolean> => {
    if (!profile) return false;
    const current = await getFreshCoins();
    if (current === null) { showMessage(t('Ошибка при проверке баланса')); return false; }
    if (current < cost) { showMessage(t('Недостаточно монет')); return false; }
    const { error: coinErr } = await supabase.rpc('change_coins', {
      p_amount: -cost,
      p_reason: successMsg,
    });
    if (coinErr) { showMessage(t('Ошибка при списании монет')); return false; }
    const { error: insertErr } = await doInsert();
    if (insertErr) {
      await supabase.rpc('change_coins', { p_amount: cost, p_reason: 'Возврат за неудачную покупку' });
      showMessage(t('Ошибка при покупке. Монеты возвращены.'));
      return false;
    }
    await refreshProfile();
    showMessage(successMsg);
    return true;
  };

  const handleBuySamplePack = async (item: SamplePack) => {
    if (!profile || isGuest) { showMessage(t('Войдите в аккаунт')); return; }
    if (ownedSamplePacks.includes(item.id)) return;
    setBuying(item.id);
    const ok = await purchaseWithCoins(item.price_coins, t('Сэмпл-пак «') + item.name + t('» куплен!'), () =>
      supabase.from('user_sample_packs').insert({ user_id: profile.id, sample_pack_id: item.id, purchased_at: new Date().toISOString() }));
    if (ok) setOwnedSamplePacks([...ownedSamplePacks, item.id]);
    setBuying(null);
  };

  const handleBuyCosmetic = async (item: CosmeticItem) => {
    if (!profile || isGuest) { showMessage(t('Войдите в аккаунт')); return; }
    if (ownedCosmetics.includes(item.id)) return;
    setBuying(item.id);
    const ok = await purchaseWithCoins(item.price_coins, t('«') + item.name + t('» куплено!'), () =>
      supabase.from('user_cosmetics').insert({ user_id: profile.id, cosmetic_id: item.id, is_equipped: false, purchased_at: new Date().toISOString() }));
    if (ok) setOwnedCosmetics([...ownedCosmetics, item.id]);
    setBuying(null);
  };

  const handleEquipCosmetic = async (item: CosmeticItem) => {
    if (!profile || isGuest || !ownedCosmetics.includes(item.id)) return;
    setEquipping(item.id);
    const { error } = await supabase.rpc('equip_cosmetic', { p_cosmetic_id: item.id });
    if (error) {
      setEquipping(null);
      showMessage(t('Не удалось установить предмет'));
      return;
    }
    const sameType = cosmeticItems.filter((c) => c.type === item.type).map((c) => c.id);
    setEquippedCosmetics([...equippedCosmetics.filter((id) => !sameType.includes(id)), item.id]);
    setEquipping(null);
    showMessage(t('«') + item.name + t('» установлено!'));
  };

  const handleBuyBoost = async (item: BoostItem) => {
    if (!profile || isGuest) { showMessage(t('Войдите в аккаунт')); return; }
    setBuying(item.id);
    const expires = new Date(Date.now() + item.duration_hours * 3600000).toISOString();
    await purchaseWithCoins(item.price_coins, t('«') + item.name + t('» активировано!'), () =>
      supabase.from('user_boosts').insert({ user_id: profile.id, boost_id: item.id, expires_at: expires, created_at: new Date().toISOString() }));
    setBuying(null);
  };

  const handleBuyAvatar = async (item: AvatarShopItem) => {
    if (!profile || isGuest) { showMessage(t('Войдите в аккаунт, чтобы покупать аватары')); return; }
    if (ownedAvatars.includes(item.id)) return;
    setBuying(item.id);
    const ok = await purchaseWithCoins(item.price, t('Аватар «') + item.name + t('» куплен!'), () =>
      supabase.from('user_avatars').insert({ user_id: profile.id, avatar_shop_item_id: item.id, purchased_at: new Date().toISOString() }));
    if (ok) setOwnedAvatars([...ownedAvatars, item.id]);
    setBuying(null);
  };

  const handleOpenStickerChest = async () => {
    if (!profile || isGuest) { showMessage(t('Войдите в аккаунт')); return; }
    setBuying('sticker-chest');
    const { data, error } = await supabase.rpc('open_sticker_chest');
    if (error || !data?.[0]) {
      showMessage(t('Не удалось открыть сундук. Проверьте баланс.'));
      setBuying(null);
      return;
    }
    const reward = data[0] as { sticker_id: string; sticker_name: string; sticker_emoji: string };
    setOwnedStickers((prev) => prev.includes(reward.sticker_id) ? prev : [...prev, reward.sticker_id]);
    await refreshProfile();
    setBuying(null);
    showMessage(t('В сундуке:') + ' ' + reward.sticker_emoji + ' ' + reward.sticker_name + '!');
  };

  const handleEquipAvatar = async (item: AvatarShopItem) => {
    if (!profile || isGuest || !ownedAvatars.includes(item.id)) return;
    setEquipping(item.id);
    const { error } = await supabase.from('profiles').update({ avatar_url: item.image_url }).eq('id', profile.id);
    if (!error) { await refreshProfile(); showMessage(t('Аватар «') + item.name + t('» установлен!')); }
    else showMessage(t('Ошибка при установке аватара'));
    setEquipping(null);
  };

  const coins = profile?.coins ?? 0;
  const earnedCoins = profile?.earned_coins ?? 0;
  const tabBody: ReactNode = (() => {
    if (loading) return (
      <div className="flex items-center justify-center py-20">
        <div className="w-8 h-8 border-2 border-theme-primary border-t-transparent rounded-full animate-spin" />
      </div>
    );
    if (activeTab === 'coins') return <CoinPurchase />;
    if (activeTab === 'samples') return samplePacks.length === 0 ? <EmptyState icon={Package} text={t('Сэмпл-паки скоро появятся')} /> : (
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {samplePacks.map((item) => {
          const owned = ownedSamplePacks.includes(item.id);
          const canAfford = coins >= item.price_coins;
          return (
            <div key={item.id} className="bg-theme-surface/50 border border-theme-border rounded-2xl overflow-hidden glass-surface shop-card">
              <div className="relative h-32 bg-gradient-to-br from-theme-primary/30 to-theme-accent/20 flex items-center justify-center">
                {item.cover_url ? <img src={item.cover_url} alt={item.name} className="w-full h-full object-cover" />
                  : <Package className="w-12 h-12 text-theme-primary/50" />}
                {item.is_exclusive && (
                  <span className="absolute top-2 right-2 px-2 py-0.5 bg-theme-warning/20 text-theme-warning text-xs font-bold rounded-full flex items-center gap-1">
                    <Star className="w-3 h-3" fill="currentColor" /> {t('Эксклюзив')}
                  </span>
                )}
              </div>
              <div className="p-4">
                <h3 className="text-theme-text font-bold text-sm mb-1">{item.name}</h3>
                <p className="text-theme-muted text-xs mb-1">{item.producer_name} · {item.genre}</p>
                <p className="text-theme-muted text-xs mb-3 flex items-center gap-1"><Music className="w-3 h-3" /> {item.track_count} {t('треков')}</p>
                <p className="text-theme-muted text-xs mb-4 line-clamp-2">{item.description}</p>
                <CoinPrice amount={item.price_coins} />
                {owned ? <OwnedBadge label={t('Куплено')} icon={Download} />
                  : <BuyBtn onClick={() => handleBuySamplePack(item)} buyingId={buying} id={item.id} canAfford={canAfford} label={t('Купить')} />}
              </div>
            </div>
          );
        })}
      </div>
    );
    if (activeTab === 'cosmetics') return cosmeticItems.length === 0 ? <EmptyState icon={Palette} text={t('Внешний вид скоро появится')} /> : (
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
        {cosmeticItems.map((item) => {
          const owned = ownedCosmetics.includes(item.id);
          const equipped = equippedCosmetics.includes(item.id);
          const r = RARITY_STYLES[item.rarity] || RARITY_STYLES.common;
          const canAfford = coins >= item.price_coins;
          return (
            <div key={item.id} className={`bg-theme-surface/50 border-2 rounded-2xl overflow-hidden glass-surface shop-card ${r.border} ${r.glow} ${equipped ? 'ring-2 ring-theme-primary' : ''}`}>
              <div className="relative h-28 flex items-center justify-center bg-theme-surface2">
                {item.preview_url ? <img src={item.preview_url} alt={item.name} className="w-full h-full object-cover" />
                  : <Palette className="w-10 h-10 text-theme-muted" />}
                <RarityBadge rarity={item.rarity} legendary={item.rarity === 'legendary'} />
                {equipped && <EquippedBadge />}
              </div>
              <div className="p-4">
                <h3 className="text-theme-text font-bold text-sm mb-1">{item.name}</h3>
                <p className="text-theme-muted text-xs mb-2">{t(COSMETIC_TYPE_LABELS[item.type] || item.type)}</p>
                <p className="text-theme-muted text-xs mb-3 line-clamp-2">{item.description}</p>
                <CoinPrice amount={item.price_coins} />
                {owned ? (equipped ? <OwnedBadge label="✓ Установлено" />
                  : <EquipBtn onClick={() => handleEquipCosmetic(item)} equippingId={equipping} id={item.id} />)
                  : <BuyBtn onClick={() => handleBuyCosmetic(item)} buyingId={buying} id={item.id} canAfford={canAfford} label={t('Купить')} />}
              </div>
            </div>
          );
        })}
      </div>
    );
    if (activeTab === 'boosts') return boostItems.length === 0 ? <EmptyState icon={Zap} text={t('Ускорения скоро появятся')} /> : (
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {boostItems.map((item) => {
          const canAfford = coins >= item.price_coins;
          return (
            <div key={item.id} className="bg-theme-surface/50 border border-theme-border rounded-2xl p-5 glass-surface shop-card">
              <div className="flex items-start justify-between mb-3">
                <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-theme-primary to-theme-accent flex items-center justify-center"><Zap className="w-6 h-6 text-white" /></div>
                <span className="px-2 py-0.5 bg-theme-primary/20 text-theme-primary text-xs font-medium rounded-full">{item.duration_hours} {t('ч.')}</span>
              </div>
              <h3 className="text-theme-text font-bold text-sm mb-1">{item.name}</h3>
              <p className="text-theme-muted text-xs mb-2">{item.type}</p>
              <p className="text-theme-muted text-xs mb-4 line-clamp-2">{item.description}</p>
              <CoinPrice amount={item.price_coins} />
              <BuyBtn onClick={() => handleBuyBoost(item)} buyingId={buying} id={item.id} canAfford={canAfford} label={t('Активировать')} Icon={Zap} />
            </div>
          );
        })}
      </div>
    );
    if (activeTab === 'avatars') return avatars.length === 0 ? <EmptyState icon={Crown} text={t('Магазин скоро будет пополнен')} /> : (
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
        {avatars.map((item, idx) => {
          const owned = ownedAvatars.includes(item.id);
          const equipped = profile?.avatar_url === item.image_url;
          const r = RARITY_STYLES[item.rarity] || RARITY_STYLES.common;
          const canAfford = coins >= item.price;
          const gradient = AVATAR_GRADIENTS[idx % AVATAR_GRADIENTS.length];
          return (
            <div key={item.id} className={`bg-theme-surface/50 border-2 rounded-2xl overflow-hidden glass-surface shop-card transition-all ${r.border} ${r.glow} ${equipped ? 'ring-2 ring-theme-primary' : ''}`}>
              <div className="relative h-40 flex items-center justify-center overflow-hidden">
                {item.image_url ? <img src={item.image_url} alt={item.name} className="w-full h-full object-cover" />
                  : <div className={`w-full h-full bg-gradient-to-br ${gradient} flex items-center justify-center`}><Crown className="w-16 h-16 text-white/80" /></div>}
                <RarityBadge rarity={item.rarity} legendary={item.rarity === 'legendary'} />
                {equipped && <EquippedBadge />}
              </div>
              <div className="p-4">
                <h3 className="text-theme-text font-bold text-base mb-1">{item.name}</h3>
                <div className="flex items-center gap-1.5 mb-4"><span className="coin coin-sm" /><span className="text-theme-text font-bold">{item.price}</span></div>
                {owned ? (equipped ? <OwnedBadge label={t('Установлен')} />
                  : <EquipBtn onClick={() => handleEquipAvatar(item)} equippingId={equipping} id={item.id} />)
                  : <BuyBtn onClick={() => handleBuyAvatar(item)} buyingId={buying} id={item.id} canAfford={canAfford} label={`${t('Купить за')} ${item.price}`} />}
              </div>
            </div>
          );
        })}
      </div>
    );
    if (activeTab === 'stickers') return stickers.length === 0 ? <EmptyState icon={Sparkles} text={t('Стикеры скоро появятся')} /> : (
      <div className="space-y-5">
        <div className="bg-theme-surface/50 border border-theme-primary/40 rounded-2xl p-5 glass-surface shop-card flex flex-col sm:flex-row sm:items-center gap-4 justify-between">
          <div>
            <h3 className="text-theme-text font-bold text-lg flex items-center gap-2"><Package className="w-5 h-5 text-theme-warning" /> {t('Сундук со стикером')}</h3>
            <p className="text-theme-muted text-sm mt-1">{t('Внутри случайный стикер из коллекции. Повторы превращаются в коллекционные находки.')}</p>
          </div>
          <BuyBtn onClick={handleOpenStickerChest} buyingId={buying} id="sticker-chest" canAfford={coins >= 15} label={`${t('Открыть за')} 15 ${t('монет')}`} Icon={Sparkles} />
        </div>
        <div>
          <p className="text-xs text-theme-muted uppercase tracking-wider mb-3">{t('Коллекция')}</p>
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-4">
            {stickers.map((item) => {
              const owned = ownedStickers.includes(item.id);
              const r = RARITY_STYLES[item.rarity] || RARITY_STYLES.common;
              return (
                <div key={item.id} className={`bg-theme-surface/50 border-2 rounded-2xl overflow-hidden glass-surface shop-card ${r.border} ${r.glow} ${owned ? '' : 'opacity-60'}`}>
                  <div className="relative h-24 flex items-center justify-center bg-theme-surface2">
                    {item.image_url ? <img src={item.image_url} alt={item.name} className="w-full h-full object-cover" /> : <span className="text-4xl">{item.emoji}</span>}
                    <RarityBadge rarity={item.rarity} legendary={item.rarity === 'legendary'} />
                  </div>
                  <div className="p-3">
                    <h3 className="text-theme-text font-bold text-sm mb-1">{owned ? item.name : t('Не найдено')}</h3>
                    <p className="text-theme-muted text-xs">{owned ? item.category : t('Откройте сундук')}</p>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    );
    return null;
  })();

  return (
    <div className="shop-page space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-theme-text flex items-center gap-2"><ShoppingBag className="w-6 h-6 text-theme-primary" /> {t('Магазин')}</h1>
          <p className="text-theme-muted text-sm mt-1">{t('Монеты, сэмплы, внешний вид и ускорения')}</p>
        </div>
        <div className="flex items-center gap-3 flex-wrap">
          <div className="flex items-center gap-3 bg-theme-surface/50 border border-theme-border rounded-2xl px-5 py-3 glass-surface shop-card">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-theme-warning to-theme-accent flex items-center justify-center"><span className="coin coin-sm" /></div>
            <div>
              <p className="text-theme-muted text-xs uppercase tracking-wider">{t('Игровой баланс')}</p>
              <p className="text-xl font-bold text-theme-text">{coins}</p>
            </div>
          </div>
          <button
            onClick={() => setActiveTab('coins')}
            className="flex items-center gap-2 px-4 py-2.5 bg-gradient-to-br from-theme-warning to-theme-accent text-white rounded-xl text-sm font-semibold hover:opacity-90 transition-opacity shadow-lg buy-btn"
          >
            <span className="coin coin-sm" /> {t('Пополнить монеты')}
          </button>
          <div className="flex items-center gap-3 bg-theme-surface/50 border border-theme-success/30 rounded-2xl px-5 py-3 glass-surface shop-card">
            <div className="w-10 h-10 rounded-xl bg-theme-success/20 flex items-center justify-center"><TrendingUp className="w-5 h-5 text-theme-success" /></div>
            <div>
              <p className="text-theme-muted text-xs uppercase tracking-wider">{t('Заработанные')}</p>
              <p className="text-xl font-bold text-theme-success">{earnedCoins}</p>
            </div>
          </div>
        </div>
      </div>

      {message && (
        <div className="bg-theme-primary-bg border border-theme-primary-border rounded-xl p-4 flex items-center gap-3">
          <Sparkles className="w-5 h-5 text-theme-primary" />
          <p className="text-theme-primary-text text-sm font-medium">{message}</p>
        </div>
      )}

      <div className="flex gap-2 overflow-x-auto pb-1">
        {TABS.map((tab) => (
          <button key={tab.id} onClick={() => setActiveTab(tab.id)}
            className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-sm font-medium whitespace-nowrap transition-all ${
              activeTab === tab.id ? 'bg-theme-primary text-white' : 'bg-theme-surface/50 text-theme-muted hover:text-theme-text border border-theme-border'
            }`}>
            <tab.icon className="w-4 h-4" /> {t(tab.label)}
          </button>
        ))}
      </div>

      {tabBody}


    </div>
  );
}
