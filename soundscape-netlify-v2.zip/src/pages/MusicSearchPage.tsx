import { useState, useCallback } from 'react';
import { Search, Play, Music2, Loader2, Pause, ListMusic, Youtube, AlertCircle } from 'lucide-react';
import { usePlayer, type PlayerTrack } from '@/context/PlayerContext';
import { useLocale } from '@/context/LocaleContext';

type Track = PlayerTrack & {
  previewUrl?: string;
  albumId: string;
  albumName: string;
  releaseDate: string;
};

const SUPABASE_URL = 'https://cccoflivuzxzujieuhvo.supabase.co';
const SUPABASE_ANON_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImNjY29mbGl2dXp4enVqaWV1aHZvIiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODg4ODk3MDcsImV4cCI6MjEwNDQ2NTcwN30.-suTh6a9r7yQOPacLl7Ez8mrFIw7kKrepkqNT964bNI';

export default function MusicSearchPage() {
  const { currentTrack, isPlaying, play, toggle, playQueue, queue } = usePlayer();
  const { t } = useLocale();
  const [query, setQuery] = useState('');
  const [results, setResults] = useState<Track[]>([]);
  const [loading, setLoading] = useState(false);
  const [searched, setSearched] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const search = useCallback(async () => {
    if (!query.trim()) return;
    setLoading(true);
    setSearched(true);
    setError(null);

    try {
      const res = await fetch(
        `${SUPABASE_URL}/functions/v1/music-search?q=${encodeURIComponent(query)}`,
        { headers: { Authorization: `Bearer ${SUPABASE_ANON_KEY}`, Apikey: SUPABASE_ANON_KEY } },
      );
      if (!res.ok) {
        setError(t('Сервис поиска временно недоступен'));
        setResults([]);
        setLoading(false);
        return;
      }
      const data = await res.json();
      const tracks: Track[] = (data.results || []).map((r: Record<string, unknown>) => ({
        id: String(r.id),
        title: String(r.title || t('Без названия')),
        artist: String(r.artist || t('Неизвестен')),
        cover: r.cover as string | undefined,
        url: String(r.url),
        albumId: String(r.albumId),
        albumName: String(r.albumName),
        releaseDate: String(r.releaseDate),
      }));
      tracks.sort((a, b) => b.releaseDate.localeCompare(a.releaseDate));
      setResults(tracks);
    } catch {
      setError(t('Не удалось подключиться к сервису поиска'));
      setResults([]);
    }
    setLoading(false);
  }, [query, t]);

  const handlePlay = (track: Track) => {
    if (currentTrack?.id === track.id) {
      toggle();
    } else {
      play(track);
    }
  };

  const playAll = () => {
    if (results.length > 0) {
      playQueue(results, 0);
    }
  };

  const isCurrentPlaying = (trackId: string) => currentTrack?.id === trackId && isPlaying;

  const youtubeLink = (track: Track) =>
    `https://www.youtube.com/results?search_query=${encodeURIComponent(`${track.artist} ${track.title} official audio`)}`;

  const albumGroups = results.reduce<{ id: string; name: string; releaseDate: string; tracks: Track[] }[]>((groups, track) => {
    const group = groups.find((item) => item.id === track.albumId);
    if (group) {
      group.tracks.push(track);
      if (track.releaseDate > group.releaseDate) group.releaseDate = track.releaseDate;
    } else {
      groups.push({ id: track.albumId, name: track.albumName, releaseDate: track.releaseDate, tracks: [track] });
    }
    return groups;
  }, []).sort((a, b) => b.releaseDate.localeCompare(a.releaseDate));

  const renderTrackCard = (track: Track) => {
    const playing = isCurrentPlaying(track.id);
    return (
      <div
        key={track.id}
        className="group text-left glass-surface bg-theme-surface/50 border border-theme-border rounded-2xl overflow-hidden hover:border-theme-warning/50 hover:shadow-xl hover:shadow-theme-warning/10 transition-all duration-300"
      >
        <button
          onClick={() => handlePlay(track)}
          className="block w-full text-left relative"
        >
          <div className="relative aspect-square bg-theme-surface2">
            {track.cover ? (
              <img
                src={track.cover}
                alt={track.title}
                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
              />
            ) : (
              <div className="w-full h-full flex items-center justify-center">
                <Music2 className="w-12 h-12 text-theme-muted" />
              </div>
            )}
            <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent" />
            <div className="absolute inset-0 bg-black/30 group-hover:bg-black/10 transition-colors flex items-center justify-center">
              <div className={`w-14 h-14 rounded-full bg-gradient-to-br from-amber-400 to-orange-500 flex items-center justify-center shadow-lg opacity-0 group-hover:opacity-100 transition-all duration-300 ${playing ? 'opacity-100 scale-110' : ''}`}>
                {playing ? (
                  <Pause className="w-6 h-6 text-white" fill="white" />
                ) : (
                  <Play className="w-6 h-6 text-white ml-0.5" fill="white" />
                )}
              </div>
            </div>
            {playing && (
              <div className="absolute bottom-2 left-2 flex items-center gap-1.5 px-2.5 py-1 bg-black/70 backdrop-blur-sm rounded-full">
                <div className="flex items-end gap-0.5 h-3">
                  <span className="w-0.5 h-2 bg-amber-400 animate-pulse" />
                  <span className="w-0.5 h-3 bg-amber-400 animate-pulse" style={{ animationDelay: '0.15s' }} />
                  <span className="w-0.5 h-1.5 bg-amber-400 animate-pulse" style={{ animationDelay: '0.3s' }} />
                </div>
                <span className="text-xs text-white font-medium">{t('Превью 30с')}</span>
              </div>
            )}
          </div>
        </button>
        <div className="p-3.5">
          <p className="text-theme-text text-sm font-semibold truncate">{track.title}</p>
          <p className="text-theme-muted text-xs truncate mt-0.5">{track.artist}</p>
        </div>
        <div className="px-3.5 pb-3.5 flex items-center gap-2">
          <button
            onClick={() => handlePlay(track)}
            className="flex-1 px-3 py-2 bg-amber-500/15 text-amber-400 rounded-lg text-xs font-semibold hover:bg-amber-500/25 transition-colors flex items-center justify-center gap-1.5"
          >
            {playing ? (
              <><Pause className="w-3.5 h-3.5" /> {t('Пауза')}</>
            ) : (
              <><Play className="w-3.5 h-3.5" /> {t('30с')}</>
            )}
          </button>
          <a
            href={youtubeLink(track)}
            target="_blank"
            rel="noopener noreferrer"
            className="flex-1 px-3 py-2 bg-red-500/15 text-red-400 rounded-lg text-xs font-semibold hover:bg-red-500/25 transition-colors flex items-center justify-center gap-1.5"
          >
            <Youtube className="w-3.5 h-3.5" />
            YouTube
          </a>
        </div>
      </div>
    );
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-theme-text flex items-center gap-2">
          <Search className="w-6 h-6 text-amber-400" />
          {t('Поиск Музыки')}
        </h1>
        <p className="text-theme-muted text-sm mt-1">
          {t('Слушай 30-секундное превью или открывай полную версию на YouTube')}
        </p>
      </div>

      <div className="search-container">
        <div className="page-search-wrapper">
          <Search className="page-search-icon" />
          <input
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && search()}
            placeholder={t('Введи название песни или исполнителя...')}
            className="page-search-input"
          />
        </div>
        <button
          onClick={search}
          disabled={loading}
          className="search-btn disabled:opacity-50"
        >
          {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : t('Искать')}
        </button>
      </div>

      {loading ? (
        <div className="flex items-center justify-center py-12">
          <Loader2 className="w-6 h-6 text-amber-400 animate-spin" />
        </div>
      ) : error ? (
        <div className="text-center py-12">
          <AlertCircle className="w-12 h-12 text-theme-danger mx-auto mb-3" />
          <p className="text-theme-muted text-sm">{error}</p>
        </div>
      ) : !searched ? (
        <div className="text-center py-12">
          <div className="inline-flex items-center justify-center w-20 h-20 rounded-2xl bg-gradient-to-br from-amber-500/20 to-orange-500/20 mb-4">
            <Music2 className="w-10 h-10 text-amber-400" />
          </div>
          <p className="text-theme-muted text-sm">
            {t('Введи название песни или имя исполнителя и нажми «Поиск»')}
          </p>
          <p className="text-theme-muted text-xs mt-1">
            {t('30 секунд превью здесь — полная версия на YouTube')}
          </p>
        </div>
      ) : results.length === 0 ? (
        <div className="text-center py-12">
          <Music2 className="w-12 h-12 text-theme-muted mx-auto mb-3" />
          <p className="text-theme-muted text-sm">{t('Ничего не найдено по запросу')} «{query}»</p>
        </div>
      ) : (
        <>
          <div className="flex items-center justify-between gap-3 flex-wrap">
            <p className="text-xs text-theme-muted">
              {t('Найдено')} {results.length} {t('треков. «30с» — превью, «YouTube» — полная версия.')}
            </p>
            <button
              onClick={playAll}
              className="flex items-center gap-2 px-4 py-2 bg-amber-500/15 text-amber-400 rounded-lg text-xs font-semibold hover:bg-amber-500/25 transition-colors"
            >
              <ListMusic className="w-4 h-4" />
              {t('Играть все превью')}
            </button>
          </div>
          <div className="space-y-8">
            {albumGroups.map((album) => (
              <section key={album.id}>
                <div className="flex items-baseline justify-between gap-3 mb-3">
                  <h2 className="text-base font-semibold text-theme-text">{album.name}</h2>
                  <span className="text-xs text-theme-muted">{album.tracks.length} {t('треков')}</span>
                </div>
                <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-6 gap-4">
                  {album.tracks.map(renderTrackCard)}
                </div>
              </section>
            ))}
          </div>
          {queue.length > 0 && (
            <p className="text-xs text-theme-muted text-center">
              {t('В очереди')} {queue.length} {t('треков — переключай в плеере внизу')}
            </p>
          )}
        </>
      )}
    </div>
  );
}
