import { useState } from 'react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/context/AuthContext';
import { useLocale } from '@/context/LocaleContext';
import { Music, Loader2, Lock, CheckCircle2 } from 'lucide-react';
import type { Page } from '@/components/Sidebar';

export default function ResetPasswordPage({ setPage }: { setPage: (p: Page) => void }) {
  const { isGuest } = useAuth();
  const { t } = useLocale();
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [done, setDone] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    if (password.length < 6) {
      setError(t('Пароль должен быть не короче 6 символов'));
      return;
    }
    if (password !== confirmPassword) {
      setError(t('Пароли не совпадают'));
      return;
    }

    setLoading(true);
    const { error: updateError } = await supabase.auth.updateUser({ password });
    setLoading(false);

    if (updateError) {
      setError(updateError.message || t('Не удалось изменить пароль. Попробуйте ещё раз.'));
      return;
    }

    setDone(true);
    setTimeout(() => setPage('home'), 3000);
  };

  if (done) {
    return (
      <div className="min-h-screen bg-theme-bg flex items-center justify-center p-4">
        <div className="max-w-md w-full text-center space-y-4">
          <div className="mx-auto w-16 h-16 rounded-2xl bg-theme-success/20 flex items-center justify-center">
            <CheckCircle2 className="w-8 h-8 text-theme-success" />
          </div>
          <h1 className="text-xl font-bold text-theme-text">{t('Пароль изменён')}</h1>
          <p className="text-sm text-theme-muted">{t('Пароль успешно обновлён. Войдите с новым паролем.')}</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-theme-bg flex items-center justify-center p-4 relative overflow-hidden">
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute top-1/4 left-1/4 w-96 h-96 rounded-full blur-3xl" style={{ background: 'rgba(var(--color-primary-rgb), 0.1)' }} />
      </div>

      <div className="relative w-full max-w-md">
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-gradient-to-br from-theme-primary to-theme-accent mb-4 shadow-lg">
            <Lock className="w-8 h-8 text-white" />
          </div>
          <h1 className="text-2xl font-bold text-theme-text">{t('Новый пароль')}</h1>
          <p className="text-theme-muted mt-2 text-sm">{t('Придумайте новый пароль для вашего аккаунта')}</p>
        </div>

        <div className="bg-theme-surface/80 backdrop-blur-xl border border-theme-border rounded-2xl p-8 shadow-2xl glass-surface">
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-xs font-medium text-theme-muted mb-1.5">{t('Новый пароль')}</label>
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
                minLength={6}
                autoComplete="new-password"
                className="w-full px-4 py-2.5 bg-theme-surface2 border border-theme-border rounded-lg text-theme-text text-sm focus:outline-none focus:border-theme-primary focus:ring-1 focus:ring-theme-primary transition-colors"
                placeholder="••••••••"
              />
              <p className="text-[11px] text-theme-muted mt-1.5">{t('Минимум 6 символов')}</p>
            </div>
            <div>
              <label className="block text-xs font-medium text-theme-muted mb-1.5">{t('Повторите пароль')}</label>
              <input
                type="password"
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
                required
                minLength={6}
                autoComplete="new-password"
                className="w-full px-4 py-2.5 bg-theme-surface2 border border-theme-border rounded-lg text-theme-text text-sm focus:outline-none focus:border-theme-primary focus:ring-1 focus:ring-theme-primary transition-colors"
                placeholder="••••••••"
              />
            </div>

            {error && (
              <div className="text-sm text-theme-danger bg-theme-danger/10 border border-theme-danger/20 rounded-lg px-4 py-2.5">
                {error}
              </div>
            )}

            <button
              type="submit"
              disabled={loading}
              className="w-full py-2.5 bg-gradient-to-r from-theme-primary to-theme-accent text-white rounded-lg font-medium text-sm hover:shadow-lg transition-all disabled:opacity-50 flex items-center justify-center gap-2"
            >
              {loading && <Loader2 className="w-4 h-4 animate-spin" />}
              {t('Изменить пароль')}
            </button>
          </form>

          <button
            onClick={() => setPage('home')}
            className="w-full mt-4 text-sm text-theme-muted hover:text-theme-text transition-colors"
          >
            {t('Назад')}
          </button>
        </div>
      </div>
    </div>
  );
}
