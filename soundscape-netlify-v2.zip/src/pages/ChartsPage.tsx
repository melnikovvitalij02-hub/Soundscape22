import { useState, useRef, useEffect, useCallback } from 'react';
import { useAuth } from '@/context/AuthContext';
import { useLocale } from '@/context/LocaleContext';
import { BarChart3, Play, Pause, SkipBack, SkipForward, Volume2, Heart, Loader2, Flame, TrendingUp, Music2, X } from 'lucide-react';

const COVER_CACHE_NAME = 'soundscape-covers';
const coverObjectUrls = new Map<string, string>();

async function getCachedCoverUrl(src: string): Promise<string> {
  if (coverObjectUrls.has(src)) return coverObjectUrls.get(src)!;
  try {
    const cache = await caches.open(COVER_CACHE_NAME);
    const cached = await cache.match(src);
    if (cached) {
      const blob = await cached.blob();
      const url = URL.createObjectURL(blob);
      coverObjectUrls.set(src, url);
      return url;
    }
    const resp = await fetch(src);
    if (!resp.ok) return src;
    await cache.put(src, new Response(await resp.blob(), { headers: { 'Content-Type': resp.headers.get('Content-Type') || 'image/webp' } }));
    const blob = await (await cache.match(src))!.blob();
    const url = URL.createObjectURL(blob);
    coverObjectUrls.set(src, url);
    return url;
  } catch {
    return src;
  }
}

const MAX_RETRIES = 3;
const RETRY_INTERVAL_MS = 2000;
const SOURCE_CACHE_KEY = 'soundscape-audio-cache';

type SourceCache = Record<string, number>;

function readSourceCache(): SourceCache {
  try {
    const raw = localStorage.getItem(SOURCE_CACHE_KEY);
    return raw ? JSON.parse(raw) : {};
  } catch {
    return {};
  }
}

function writeSourceCache(cache: SourceCache) {
  try {
    localStorage.setItem(SOURCE_CACHE_KEY, JSON.stringify(cache));
  } catch {
    // ignore quota / private mode errors
  }
}

type ChartTrack = {
  id: number;
  title: string;
  artist: string;
  url: string;
  cover: string;
  duration?: string;
};

const AUDIO_PROXY_BASE = 'https://cccoflivuzxzujieuhvo.supabase.co/functions/v1/audio-proxy';

function trackUrl(key: string): string {
  return `${AUDIO_PROXY_BASE}?track=${key}`;
}

const CHART_TRACKS: ChartTrack[] = [
  {
    id: 1,
    title: 'I GOT U',
    artist: 'Toxis',
    url: trackUrl('igotu'),
    cover: '/cover-igotu.webp',
    duration: '2:48',
  },
  {
    id: 2,
    title: 'Мало 2.0',
    artist: 'Егор Крид',
    url: trackUrl('malo'),
    cover: '/cover-malo.webp',
    duration: '2:35',
  },
  {
    id: 3,
    title: 'Тону',
    artist: 'HOLLYFLAME',
    url: trackUrl('tonu'),
    cover: '/cover-tonu.webp',
    duration: '3:12',
  },
  {
    id: 4,
    title: 'Малиновая Лада',
    artist: 'GAYAZOV BROTHERS',
    url: trackUrl('lada'),
    cover: '/cover-lada.webp',
    duration: '2:22',
  },
  {
    id: 5,
    title: 'По барам',
    artist: 'Anna Asti',
    url: trackUrl('baram'),
    cover: '/cover-baram.webp',
    duration: '2:58',
  },
  {
    id: 6,
    title: 'Слеза',
    artist: 'Егор Крид',
    url: trackUrl('sleza'),
    cover: '/cover-sleza.webp',
    duration: '3:18',
  },
  {
    id: 7,
    title: 'BALOO',
    artist: 'Бодя Мир642',
    url: trackUrl('baloo'),
    cover: '/cover-baloo.webp',
    duration: '2:46',
  },
  {
    id: 8,
    title: 'Если я буду танцевать',
    artist: 'Баста & Моя Мишель',
    url: trackUrl('basta'),
    cover: '/cover-esli-ya-budu-tantsevat.webp',
    duration: '3:36',
  },
  {
    id: 9,
    title: 'GAZ',
    artist: 'Zivert',
    url: trackUrl('gaz'),
    cover: '/cover-gaz.webp',
    duration: '3:02',
  },
  {
    id: 10,
    title: "We Don't Talk Anymore",
    artist: 'Charlie Puth',
    url: trackUrl('charlie'),
    cover: '/cover-we-dont-talk-anymore.webp',
    duration: '3:37',
  },
  {
    id: 11,
    title: 'Орлы или вороны',
    artist: 'Максим Фадеев & Григорий Лепс',
    url: trackUrl('orly'),
    cover: '/cover-orly.webp',
    duration: '3:28',
  },
  {
    id: 12,
    title: 'Ave Maria',
    artist: 'Димаш Кудайберген & Игорь Крутой',
    url: trackUrl('avemaria'),
    cover: '/cover-ave-maria.webp',
    duration: '4:18',
  },
  {
    id: 13,
    title: 'Так хочется жить',
    artist: 'Рождество',
    url: trackUrl('rozhdestvo'),
    cover: '/cover-rozhdestvo.webp',
    duration: '4:32',
  },
  {
    id: 14,
    title: 'Сансара',
    artist: 'Баста',
    url: trackUrl('sansara'),
    cover: '/cover-sansara.webp',
    duration: '3:48',
  },
  {
    id: 15,
    title: 'Как хотел я',
    artist: 'Дима Билан',
    url: trackUrl('bilan'),
    cover: '/cover-bilan.webp',
    duration: '3:42',
  },
  {
    id: 16,
    title: 'Милый негодяй',
    artist: 'Егор Крид',
    url: trackUrl('milyy'),
    cover: '/cover-milyy.webp',
    duration: '2:54',
  },
];

function CachedCover({ src, alt, className }: { src: string; alt: string; className?: string }) {
  const [url, setUrl] = useState<string | null>(null);
  const [failed, setFailed] = useState(false);

  useEffect(() => {
    let cancelled = false;
    setUrl(null);
    setFailed(false);
    getCachedCoverUrl(src).then((u) => {
      if (!cancelled) setUrl(u);
    });
    return () => { cancelled = true; };
  }, [src]);

  return (
    <>
      {!url && !failed && <div className="w-full h-full bg-theme-surface2 animate-pulse" />}
      {url && (
        <img
          src={url}
          alt={alt}
          loading="lazy"
          className={className}
          onError={(e) => {
            if (e.currentTarget.src !== '/cover-igotu.webp') {
              e.currentTarget.src = '/cover-igotu.webp';
            } else {
              setFailed(true);
            }
          }}
        />
      )}
      {failed && <div className="w-full h-full bg-theme-surface2 flex items-center justify-center"><Music2 className="w-5 h-5 text-theme-muted" /></div>}
    </>
  );
}

export default function ChartsPage() {
  const { addXp } = useAuth();
  const { t } = useLocale();
  const [currentTrack, setCurrentTrack] = useState<ChartTrack | null>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [loading, setLoading] = useState(false);
  const [audioError, setAudioError] = useState<string | null>(null);
  const [progress, setProgress] = useState(0);
  const [duration, setDuration] = useState(0);
  const [volume, setVolume] = useState(0.7);
  const [favorites, setFavorites] = useState<Set<number>>(new Set());

  const audioRef = useRef<HTMLAudioElement | null>(null);
  const retryCountRef = useRef(0);
  const retryTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const loadingTrackRef = useRef<ChartTrack | null>(null);

  useEffect(() => {
    return () => {
      if (retryTimerRef.current) clearTimeout(retryTimerRef.current);
    };
  }, []);

  useEffect(() => {
    const saved = localStorage.getItem('soundscape-favorites');
    if (saved) {
      try {
        setFavorites(new Set(JSON.parse(saved)));
      } catch {
        // ignore
      }
    }
  }, []);

  const toggleFavorite = (trackId: number) => {
    setFavorites((prev) => {
      const next = new Set(prev);
      if (next.has(trackId)) {
        next.delete(trackId);
      } else {
        next.add(trackId);
      }
      localStorage.setItem('soundscape-favorites', JSON.stringify([...next]));
      return next;
    });
  };

  const clearRetryTimer = () => {
    if (retryTimerRef.current) {
      clearTimeout(retryTimerRef.current);
      retryTimerRef.current = null;
    }
  };

  const attemptPlay = useCallback((track: ChartTrack, attempt: number) => {
    const audio = audioRef.current;
    if (!audio) return;
    // Abort if the user has since selected a different track.
    if (loadingTrackRef.current?.id !== track.id) return;

    audio.src = track.url;
    audio.volume = volume;
    audio.load();
    audio.play().then(() => {
      if (loadingTrackRef.current?.id !== track.id) return;
      setIsPlaying(true);
      setLoading(false);
      setAudioError(null);
      retryCountRef.current = 0;
      addXp(5);
      // Cache the successful source so subsequent plays are faster.
      const cache = readSourceCache();
      cache[track.url] = Date.now();
      writeSourceCache(cache);
    }).catch(() => {
      if (loadingTrackRef.current?.id !== track.id) return;
      if (attempt < MAX_RETRIES) {
        retryCountRef.current = attempt + 1;
        setLoading(true);
        retryTimerRef.current = setTimeout(() => attemptPlay(track, attempt + 1), RETRY_INTERVAL_MS);
      } else {
        setLoading(false);
        setIsPlaying(false);
        setAudioError(t('Не удалось загрузить трек. Попробуйте другой.'));
        retryCountRef.current = 0;
        loadingTrackRef.current = null;
      }
    });
  }, [volume, addXp, t]);

  const playTrack = (track: ChartTrack) => {
    if (currentTrack?.id === track.id && isPlaying) {
      audioRef.current?.pause();
      return;
    }
    clearRetryTimer();
    retryCountRef.current = 0;
    loadingTrackRef.current = track;
    setLoading(true);
    setAudioError(null);
    setCurrentTrack(track);
    setProgress(0);
    setDuration(0);
    attemptPlay(track, 0);
  };

  const closePlayer = useCallback(() => {
    clearRetryTimer();
    if (audioRef.current) {
      audioRef.current.pause();
      audioRef.current.src = '';
    }
    setCurrentTrack(null);
    setIsPlaying(false);
    setProgress(0);
    setDuration(0);
    setLoading(false);
    setAudioError(null);
    retryCountRef.current = 0;
    loadingTrackRef.current = null;
  }, []);

  const togglePlay = () => {
    if (!audioRef.current || !currentTrack) return;
    if (isPlaying) {
      audioRef.current.pause();
    } else {
      audioRef.current.play().catch(() => {});
    }
  };

  const playNext = () => {
    if (!currentTrack) return;
    const idx = CHART_TRACKS.findIndex((t) => t.id === currentTrack.id);
    const next = CHART_TRACKS[(idx + 1) % CHART_TRACKS.length];
    playTrack(next);
  };

  const playPrev = () => {
    if (!currentTrack) return;
    const idx = CHART_TRACKS.findIndex((t) => t.id === currentTrack.id);
    const prev = CHART_TRACKS[(idx - 1 + CHART_TRACKS.length) % CHART_TRACKS.length];
    playTrack(prev);
  };

  const handleTimeUpdate = () => {
    if (audioRef.current) {
      setProgress(audioRef.current.currentTime);
      if (Number.isFinite(audioRef.current.duration)) {
        setDuration(audioRef.current.duration);
      }
    }
  };

  const handleLoadedMetadata = () => {
    const audio = audioRef.current;
    if (!audio) return;
    setDuration(Number.isFinite(audio.duration) ? audio.duration : 0);
    setProgress(0);
  };

  const handleSeek = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = Number(e.target.value);
    setProgress(val);
    if (audioRef.current) audioRef.current.currentTime = val;
  };

  const handleVolume = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = Number(e.target.value);
    setVolume(val);
    if (audioRef.current) audioRef.current.volume = val;
  };

  const parseDuration = (value?: string) => {
    if (!value) return 0;
    const [minutes, seconds] = value.split(':').map(Number);
    return minutes * 60 + seconds;
  };

  const formatTime = (s: number) => {
    if (!s || isNaN(s)) return '0:00';
    const m = Math.floor(s / 60);
    const sec = Math.floor(s % 60);
    return `${m}:${sec.toString().padStart(2, '0')}`;
  };

  const displayDuration = currentTrack ? duration || parseDuration(currentTrack.duration) : 0;

  return (
    <div className="space-y-6">
      <div className="flex items-start justify-between gap-4">
        <div className="cosmic-page-header">
          <h1 className="text-2xl font-bold text-theme-text flex items-center gap-2 cosmic-header-glow">
            <BarChart3 className="w-6 h-6 text-theme-primary" />
            {t('Чарты')}
          </h1>
          <p className="text-theme-muted text-sm mt-1">
            {t('Топ-чарт музыки — слушай прямо в браузере')}
          </p>
        </div>
        <div className="flex items-center gap-2">
          <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-theme-surface2 border border-theme-primary/30">
            <Flame className="w-3.5 h-3.5 text-theme-warning" />
            <span className="text-xs font-medium text-theme-muted">{CHART_TRACKS.length} {t('треков')}</span>
          </div>
          <div className="hidden sm:flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-theme-surface/60 border border-theme-border glass-surface">
            <TrendingUp className="w-3.5 h-3.5 text-theme-success" />
            <span className="text-xs font-medium text-theme-muted">{t('обновлено сегодня')}</span>
          </div>
        </div>
      </div>

      <audio
        ref={audioRef}
        preload="none"
        onTimeUpdate={handleTimeUpdate}
        onPlay={() => setIsPlaying(true)}
        onPause={() => setIsPlaying(false)}
        onEnded={playNext}
        onError={() => {
          // Retries + terminal error are driven by play().catch() in attemptPlay.
          // This event fires on the same failures; no-op to avoid duplicate handling.
        }}
        onLoadedMetadata={handleLoadedMetadata}
      />

      {currentTrack && audioError && (
        <div className="rounded-xl border border-theme-danger/30 bg-theme-danger/10 px-4 py-3 text-sm text-theme-danger">
          {audioError}
        </div>
      )}

      {currentTrack && (
        <div className="glass-surface bg-theme-surface/80 border border-theme-border rounded-2xl p-3 sm:p-4 sticky top-4 z-10 relative overflow-hidden">
          <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-theme-primary to-transparent opacity-60" />
          {/* Mobile layout: compact, two rows */}
          <div className="sm:hidden space-y-2">
            <div className="flex items-center gap-2.5">
              <div className="relative w-10 h-10 rounded-lg overflow-hidden shrink-0 bg-theme-surface2 ring-1 ring-theme-border/50">
                <CachedCover src={currentTrack.cover} alt={currentTrack.title} className="w-full h-full object-cover" />
                {loading && <div className="absolute inset-0 bg-black/50 flex items-center justify-center"><Loader2 className="w-4 h-4 text-white animate-spin" /></div>}
                {!loading && isPlaying && (
                  <div className="absolute inset-0 bg-black/30 flex items-center justify-center">
                    <div className="flex gap-0.5 items-end h-3">
                      <div className="w-0.5 bg-theme-primary rounded-full animate-pulse" style={{ height: '50%' }} />
                      <div className="w-0.5 bg-theme-primary rounded-full animate-pulse" style={{ height: '100%', animationDelay: '0.15s' }} />
                      <div className="w-0.5 bg-theme-primary rounded-full animate-pulse" style={{ height: '70%', animationDelay: '0.3s' }} />
                    </div>
                  </div>
                )}
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-theme-text text-xs font-medium truncate">{currentTrack.title}</p>
                <p className="text-theme-muted text-[10px] truncate">{loading ? t('Loading...') : currentTrack.artist}</p>
              </div>
              <button onClick={closePlayer} className="p-1 text-theme-muted hover:text-theme-text hover:bg-theme-surface2 rounded transition-colors shrink-0" aria-label={t('Закрыть плеер')}>
                <X className="w-3.5 h-3.5" />
              </button>
              <button onClick={() => toggleFavorite(currentTrack.id)} className="p-1 text-theme-muted hover:text-theme-danger transition-colors shrink-0">
                <Heart className="w-3.5 h-3.5" fill={favorites.has(currentTrack.id) ? 'currentColor' : 'none'} />
              </button>
              <button onClick={playPrev} className="p-1 text-theme-muted hover:text-theme-text transition-colors shrink-0">
                <SkipBack className="w-3.5 h-3.5" />
              </button>
              <button onClick={togglePlay} className="p-1.5 bg-theme-primary text-white rounded-full hover:bg-theme-primary-hover transition-colors shrink-0" style={{ boxShadow: '0 2px 10px rgba(var(--color-primary-rgb), 0.3)' }}>
                {isPlaying ? <Pause className="w-3 h-3" /> : <Play className="w-3 h-3 ml-0.5" />}
              </button>
              <button onClick={playNext} className="p-1 text-theme-muted hover:text-theme-text transition-colors shrink-0">
                <SkipForward className="w-3.5 h-3.5" />
              </button>
            </div>
            <div className="flex items-center gap-1.5 px-1">
              <span className="text-[9px] text-theme-muted font-mono shrink-0 tabular-nums">{formatTime(progress)}</span>
              <input type="range" min={0} max={displayDuration} value={progress} onChange={handleSeek} className="flex-1 accent-theme-primary" style={{ height: '3px' }} />
              <span className="text-[9px] text-theme-muted font-mono shrink-0 tabular-nums">{formatTime(displayDuration)}</span>
            </div>
          </div>
          {/* Desktop layout: single row */}
          <div className="hidden sm:flex items-center gap-4">
            <div className="relative w-14 h-14 rounded-xl overflow-hidden shrink-0 bg-theme-surface2 ring-1 ring-theme-border">
              <CachedCover src={currentTrack.cover} alt={currentTrack.title} className="w-full h-full object-cover" />
              {loading && (
                <div className="absolute inset-0 bg-black/50 flex items-center justify-center">
                  <Loader2 className="w-5 h-5 text-white animate-spin" />
                </div>
              )}
              {!loading && isPlaying && (
                <div className="absolute inset-0 bg-black/30 flex items-center justify-center">
                  <div className="flex gap-0.5 items-end h-5">
                    <div className="w-0.5 bg-theme-primary rounded-full animate-pulse" style={{ height: '50%' }} />
                    <div className="w-0.5 bg-theme-primary rounded-full animate-pulse" style={{ height: '100%', animationDelay: '0.15s' }} />
                    <div className="w-0.5 bg-theme-primary rounded-full animate-pulse" style={{ height: '70%', animationDelay: '0.3s' }} />
                    <div className="w-0.5 bg-theme-primary rounded-full animate-pulse" style={{ height: '90%', animationDelay: '0.45s' }} />
                  </div>
                </div>
              )}
            </div>
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2">
                <p className="text-theme-text text-sm font-medium truncate">{currentTrack.title}</p>
                {isPlaying && <span className="text-[10px] text-theme-success font-bold uppercase tracking-wide shrink-0">{t('сейчас играет')}</span>}
                {loading && <span className="text-[10px] text-theme-muted shrink-0 flex items-center gap-1"><Loader2 className="w-3 h-3 animate-spin" />{t('Loading...')}</span>}
              </div>
              <p className="text-theme-muted text-xs truncate">{currentTrack.artist}</p>
              <div className="flex items-center gap-2 mt-1.5">
                <span className="text-xs text-theme-muted font-mono">{formatTime(progress)}</span>
                <input type="range" min={0} max={displayDuration} value={progress} onChange={handleSeek} className="flex-1 accent-theme-primary" />
                <span className="text-xs text-theme-muted font-mono">{formatTime(displayDuration)}</span>
              </div>
            </div>
            <div className="flex items-center gap-1.5 shrink-0">
              <button onClick={closePlayer} className="p-2 text-theme-muted hover:text-theme-text hover:bg-theme-surface2 rounded-lg transition-colors" aria-label={t('Закрыть плеер')}>
                <X className="w-5 h-5" />
              </button>
              <button onClick={() => toggleFavorite(currentTrack.id)} className="p-2 text-theme-muted hover:text-theme-danger transition-colors rounded-lg hover:bg-theme-surface2">
                <Heart className="w-5 h-5" fill={favorites.has(currentTrack.id) ? 'currentColor' : 'none'} />
              </button>
              <button onClick={playPrev} className="p-2 text-theme-muted hover:text-theme-text transition-colors rounded-lg hover:bg-theme-surface2">
                <SkipBack className="w-5 h-5" />
              </button>
              <button onClick={togglePlay} className="p-3 bg-theme-primary text-white rounded-full hover:bg-theme-primary-hover transition-colors shadow-lg" style={{ boxShadow: '0 4px 20px rgba(var(--color-primary-rgb), 0.3)' }}>
                {isPlaying ? <Pause className="w-5 h-5" /> : <Play className="w-5 h-5" />}
              </button>
              <button onClick={playNext} className="p-2 text-theme-muted hover:text-theme-text transition-colors rounded-lg hover:bg-theme-surface2">
                <SkipForward className="w-5 h-5" />
              </button>
            </div>
            <div className="hidden md:flex items-center gap-2 shrink-0">
              <Volume2 className="w-4 h-4 text-theme-muted" />
              <input type="range" min={0} max={1} step={0.05} value={volume} onChange={handleVolume} className="w-16 accent-theme-primary" />
            </div>
          </div>
        </div>
      )}

      <div className="space-y-2">
        {CHART_TRACKS.map((track, i) => {
          const isActive = currentTrack?.id === track.id;
          const isFav = favorites.has(track.id);
          const rankColors = ['text-theme-warning', 'text-theme-muted', 'text-theme-muted'];
          return (
            <div
              key={track.id}
              className={`cosmic-card glass-surface flex items-center gap-3 sm:gap-4 p-3 rounded-xl border transition-all cursor-pointer group ${
                isActive
                  ? 'bg-theme-primary-bg border-theme-primary-border'
                  : 'bg-theme-surface/50 border-theme-border hover:border-theme-primary hover:bg-theme-surface/70'
              }`}
              onClick={() => playTrack(track)}
            >
              <div className={`w-8 text-center font-bold text-lg shrink-0 ${rankColors[i] || 'text-theme-muted'} ${i === 0 ? 'flex items-center justify-center gap-1' : ''}`}>
                {i === 0 && <Flame className="w-3.5 h-3.5" />}
                {i + 1}
              </div>

              <div className="relative w-12 h-12 rounded-lg overflow-hidden shrink-0 bg-theme-surface2 ring-1 ring-theme-border/50">
                <CachedCover src={track.cover} alt={track.title} className="w-full h-full object-cover" />
                {isActive && isPlaying && (
                  <div className="absolute inset-0 bg-black/40 flex items-center justify-center">
                    <div className="flex gap-0.5 items-end h-4">
                      <div className="w-1 bg-theme-primary rounded-full animate-pulse" style={{ height: '60%' }} />
                      <div className="w-1 bg-theme-primary rounded-full animate-pulse" style={{ height: '100%', animationDelay: '0.1s' }} />
                      <div className="w-1 bg-theme-primary rounded-full animate-pulse" style={{ height: '40%', animationDelay: '0.2s' }} />
                    </div>
                  </div>
                )}
                {!isActive && (
                  <div className="absolute inset-0 bg-black/0 group-hover:bg-black/30 flex items-center justify-center transition-colors">
                    <Play className="w-4 h-4 text-white opacity-0 group-hover:opacity-100 transition-opacity" fill="currentColor" />
                  </div>
                )}
              </div>

              <div className="flex-1 min-w-0">
                <p className={`text-sm font-medium truncate ${isActive ? 'text-theme-primary-text' : 'text-theme-text'}`}>
                  {track.title}
                </p>
                <p className="text-xs text-theme-muted truncate flex items-center gap-1">
                  <Music2 className="w-3 h-3 shrink-0" />
                  {track.artist}
                </p>
              </div>

              <button
                onClick={(e) => {
                  e.stopPropagation();
                  toggleFavorite(track.id);
                }}
                className={`p-1.5 transition-colors shrink-0 rounded-lg hover:bg-theme-surface2 ${isFav ? 'text-theme-danger' : 'text-theme-muted hover:text-theme-text'}`}
              >
                <Heart className="w-4 h-4" fill={isFav ? 'currentColor' : 'none'} />
              </button>

              <span className="text-xs text-theme-muted font-mono shrink-0 hidden sm:block">
                {track.duration}
              </span>

              <button
                onClick={(e) => {
                  e.stopPropagation();
                  playTrack(track);
                }}
                className={`p-1 rounded-full transition-colors shrink-0 ${
                  isActive
                    ? 'bg-theme-primary text-white'
                    : 'text-theme-muted hover:text-theme-text hover:bg-theme-surface2'
                }`}
              >
                {isActive && isPlaying ? <Pause className="w-3 h-3" /> : <Play className="w-3 h-3" />}
              </button>
            </div>
          );
        })}
      </div>

    </div>
  );
}
