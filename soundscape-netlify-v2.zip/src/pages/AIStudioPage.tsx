import { useState } from 'react';
import { useAuth } from '@/context/AuthContext';
import { useLocale } from '@/context/LocaleContext';
import { PenLine, Copy, ArrowRight, Loader2, Sparkles, Check, X } from 'lucide-react';
import type { Page } from '@/components/Sidebar';

const GENRES = ['Хип-Хоп', 'Трэп', 'House', 'Техно', 'Lo-Fi', 'Драм-н-Бейс', 'Дабстеп', 'Рэгги', 'Рок', 'Поп', 'R&B', 'Фонк', 'Эмбиент', 'Синтвейв'];

const LYRIC_THEMES = ['Любовь', 'Город', 'Ночь', 'Свобода', 'Дружба', 'Мечты', 'Одиночество', 'Путешествие', 'Борьба'];

type RhymeScheme = 'AABB' | 'ABAB' | 'ABBA';
type StructurePreset = {
  verses: number;
  bridge: boolean;
  rhyme: RhymeScheme;
};

const STRUCTURE_PRESETS: Record<string, StructurePreset> = {
  'Куплет+Припев': { verses: 4, bridge: false, rhyme: 'AABB' },
  'Куплет+Припев+Бридж': { verses: 4, bridge: true, rhyme: 'ABAB' },
  '2 Куплета+Припев': { verses: 4, bridge: false, rhyme: 'AABB' },
};
const STRUCTURE_KEYS = Object.keys(STRUCTURE_PRESETS);

const GENRE_MOODS: Record<string, string[]> = {
  'Хип-Хоп': ['бит качает', 'улица в каждом слове', 'рифма точная'],
  'Трэп': ['тяжёлый бас', 'туман в голове', 'каждый звук как выстрел'],
  'House': ['четыре четверти', 'свет стробоскопа', 'танцпол дышит'],
  'Техно': ['прямая бочка', 'машина и пульс', 'минимум слов'],
  'Lo-Fi': ['тёплый шум', 'кассета шуршит', 'дождь за окном'],
  'Драм-н-Бейс': ['скорость без тормозов', 'ломаный ритм', 'пульс на пределе'],
  'Дабстеп': ['провал в басу', 'вибрация стен', 'давление растёт'],
  'Рэгги': ['лёгкий кач', 'солнце на плечах', 'душа поёт медленно'],
  'Рок': ['гитара рвётся', 'драйв без компромиссов', 'эхо усилителей'],
  'Поп': ['мелодия ловкая', 'припев в голове', 'сердце подпевает'],
  'R&B': ['гладкий вокал', 'ночь длинная', 'шёлк в каждом слове'],
  'Фонк': ['кованый бас', 'тёмный вайб', 'ритм давит низ'],
  'Эмбиент': ['пустота поёт', 'звук растворяется', 'пространство дышит'],
  'Синтвейв': ['неон в ночи', 'ретро-будущее', 'город из кассет'],
};

// Expanded rhyme dictionary with more terminal vowel groups
const RHYME_MAP: Record<string, string[]> = {
  'а': ['судьба', 'игра', 'жара', 'мечта', 'сила', 'крыла', 'страна', 'волна', 'тишина', 'стена', 'рука', 'река', 'облака', 'искра', 'дуга', 'слеза', 'полоса', 'лоза', 'коза', 'роза', 'гроза'],
  'е': ['свет', 'след', 'лет', 'ответ', 'рассвет', 'секрет', 'портрет', 'билет', 'планета', 'комета', 'ветер', 'разве', 'средь', 'бред', 'кредо', 'победа', 'обед', 'беседа'],
  'о': ['легко', 'далеко', 'высоко', 'глубоко', 'одинок', 'поток', 'рок', 'ток', 'исток', 'восток', 'толчок', 'скачок', 'прыжок', 'песок', 'строк', 'листок', 'мосток'],
  'и': ['внутри', 'смотри', 'фонари', 'зари', 'лучи', 'ключи', 'уроки', 'пороки', 'руки', 'звуки', 'разлуки', 'науки', 'муки', 'птицы', 'границы', 'спицы', 'лица'],
  'у': ['бегу', 'снегу', 'смогу', 'помогу', 'берегу', 'дрожу', 'хожу', 'держу', 'нижу', 'сижу', 'лежу', 'слежу', 'молчу', 'плачу', 'значу', 'прячу'],
  'я': ['огня', 'меня', 'дня', 'земля', 'октября', 'бытия', 'семья', 'звонкая', 'пламя', 'знамя', 'имя', 'время', 'племя', 'темя', 'ремня', 'коня', 'огня'],
  'ь': ['тень', 'день', 'пень', 'олень', 'карусель', 'метель', 'портфель', 'цель', 'мель', 'постель', 'щель', 'модель', 'параллель'],
  'й': ['рай', 'май', 'край', 'сыграй', 'выбирай', 'замечай', 'прощай', 'встречай', 'открывай', 'прекращай', 'начинай', 'узнавай', 'поднимай', 'вспоминай'],
  'ю': ['люблю', 'молю', 'пою', 'создаю', 'обниму', 'пройду', 'найду', 'уйду', 'приведу', 'введу', 'выведу', 'переду'],
};

function pickRhyme(seed: string, usedRhymes: Set<string>): string {
  const lastChar = seed.toLowerCase().trim().slice(-1);
  const rhymes = RHYME_MAP[lastChar] || RHYME_MAP['а'];
  const available = rhymes.filter((r) => !usedRhymes.has(r));
  const pool = available.length > 0 ? available : rhymes;
  const pick = pool[Math.floor(Math.random() * pool.length)];
  usedRhymes.add(pick);
  return pick;
}

function shuffle<T>(arr: T[]): T[] {
  const a = [...arr];
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}

function pickN<T>(arr: T[], n: number): T[] {
  return shuffle(arr).slice(0, n);
}

function pick<T>(arr: T[]): T {
  return arr[Math.floor(Math.random() * arr.length)];
}

// Few-shot examples to guide the style — each shows a quality verse with
// clear theme, imagery, and rhyming. The generator uses these as templates.
const FEW_SHOT_EXAMPLES = [
  {
    theme: 'Город',
    verse: [
      'Город засыпает, просыпается мафия',
      'Мы считаем купюры, они шепчут нам правила',
      'На районе тихо, только сирены воют',
      'Брат за брата — это закон, мы не знаем страха',
    ],
  },
  {
    theme: 'Любовь',
    verse: [
      'Твой взгляд как выстрел в самое сердце',
      'Каждое слово — билет в бесконечность',
      'Держу твою руку, не нужно мне обещаний',
      'Ты — мой рассвет среди тёмных прощаний',
    ],
  },
  {
    theme: 'Борьба',
    verse: [
      'Каждый шаг — это бой с самим собой',
      'Падаю семь раз, но встаю восьмым',
      'Шрамы не прячем, они как медали',
      'Мы не сдаёмся, нас не остановили',
    ],
  },
];

// Each theme bank has multiple verse sets so different verses get different imagery
type ThemeBank = {
  verseSets: string[][];
  chorus: string[];
  bridge: string[];
};

const THEME_BANKS: Record<string, ThemeBank> = {
  'Любовь': {
    verseSets: [
      ['твой взгляд', 'шум в груди', 'тепло рук', 'свет в окне'],
      ['город дождей', 'тишина между', 'шаг рядом', 'пульс два'],
      ['первая встреча', 'несказанные слова', 'время назад', 'память возвращает'],
      ['держу тебя', 'не отпущу', 'рядом сквозь', 'всегда найду'],
    ],
    chorus: ['одна история на двоих', 'крепкий свет в темноте', 'держу тебя крепче', 'сильнее холода и тишины', 'возвращаюсь к тебе', 'наше сердце бьётся вместе'],
    bridge: ['найду твою руку в толпе', 'тишина звучит честнее слов', 'не нужны обещания', 'начинаем сначала каждый день'],
  },
  'Город': {
    verseSets: [
      ['неон в лужах', 'шаги по асфальту', 'чужие лица', 'ветер по крышам'],
      ['маршрут среди высоток', 'последний автобус', 'окна вселенных', 'секреты ночей'],
      ['район просыпается', 'тени в переулках', 'фонари мигают', 'голоса улиц'],
      ['бетон и стекло', 'каждый со своей болью', 'перекрёсток судеб', 'город не спит'],
    ],
    chorus: ['город дышит вместе с нами', 'фонари горят как звёзды', 'свой горизонт среди огней', 'шум улиц — наша музыка', 'новый поворот каждый день'],
    bridge: ['сбавим шаг на перекрёстке', 'за бетонными стенами сердца', 'сирены уносят мысли', 'свой маршрут — свой путь'],
  },
  'Ночь': {
    verseSets: [
      ['луна на подоконнике', 'усталость под улыбкой', 'звёзды не спешат', 'воздух пахнет'],
      ['сон приходит', 'тени ближе к рассвету', 'сердце догоняет', 'мысли уплывают'],
      ['тишина собирает', 'окно смотрит в небо', 'дыхание ровное', 'ночь укрывает'],
      ['последний звонок', 'гаснет экран', 'закрываю дверь', 'завтра новый день'],
    ],
    chorus: ['ночь открывает двери', 'танцуем с тишиной вдвоём', 'звёзды над нами горят', 'темнота не конец пути', 'утро придёт обязательно'],
    bridge: ['закрой глаза и слушай', 'ответ рождается после тишины', 'отпускаем день без сожаления', 'небо без границ над нами'],
  },
  'Свобода': {
    verseSets: [
      ['снимаю ожидания', 'ветер расправляет крылья', 'не нужен знак', 'горизонт ближе'],
      ['дорога без ответов', 'голос громче запретов', 'закрытые двери', 'пространство выбора'],
      ['первый шаг вне клетки', 'небо над головой', 'никто не указ', 'мой путь мои правила'],
      ['оставляю чемоданы', 'река течёт свободно', 'дышу полной грудью', 'впереди только свет'],
    ],
    chorus: ['свобода начинается внутри', 'не сверну с этого пути', 'искра горит ярче цепей', 'созданы для полёта', 'пишу маршрут сам'],
    bridge: ['страх идёт рядом молча', 'сломанные правила — новый закон', 'слышу себя впервые', 'собственное имя как песня'],
  },
  'Дружба': {
    verseSets: [
      ['рядом когда слова', 'делим дорогу', 'смех возвращает', 'знаем друг о друге'],
      ['плечо рядом', 'разные мечты', 'умеем молчать', 'время проверяет'],
      ['через города и годы', 'первая встреча помнится', 'спинка спины', 'общие шрамы'],
      ['не нужно объяснять', 'понимаем с полуслова', 'дверь всегда открыта', 'команда на века'],
    ],
    chorus: ['выдерживает расстояния', 'держим друг друга на плаву', 'плечом к плечу сквозь бурю', 'одной командой навсегда', 'ты рядом даже когда нет'],
    bridge: ['будь собой — этого достаточно', 'поддержка звучит тише слов', 'тот первый смех не забуду', 'сердце помнит дорогу домой'],
  },
  'Мечты': {
    verseSets: [
      ['ступени из сомнений', 'цель яснее', 'маленький свет', 'дорога начинается'],
      ['превращаю ожидание', 'ошибка добавляет сил', 'вершина видна', 'шаг за шагом'],
      ['каждый день ближе', 'не停下у верить', 'преграды как уроки', 'кушая реальность'],
      ['белые пятна на карте', 'компас внутри', 'звёзды как маяки', 'рассвет — это старт'],
    ],
    chorus: ['мечта ближе чем кажется', 'зажигаем звёзды сами', 'путь мой — мой выбор', 'поднимаюсь выше каждый раз', 'свет для старта внутри'],
    bridge: ['не сравнивай рассвет с закатом', 'сомнение проходит как туча', 'тихое решение — громкий шаг', 'след делами а не словами'],
  },
  'Одиночество': {
    verseSets: [
      ['комната слушает', 'дождь рисует', 'не путаю с пустотой', 'старые письма'],
      ['несказанные слова', 'свет в коридоре', 'память возвращает', 'окно смотрит'],
      ['один на один с собой', 'чай остывает', 'книга на полке', 'время замирает'],
      ['улицы без меня', 'эхо собственных мыслей', 'зеркало не врет', 'наедине с правдой'],
    ],
    chorus: ['остаётся голос внутри', 'тишина не враг а друг', 'собираю себя по частям', 'путь ведёт вперёд даже одному', 'ищу свой свет в темноте'],
    bridge: ['признание боли — первый шаг', 'уход не конец а начало', 'навстречу переменам без страха', 'внутренний разговор честнее всех'],
  },
  'Путешествие': {
    verseSets: [
      ['рассвет на вокзале', 'новые города', 'ветер приносит истории', 'горы учат'],
      ['море отвечает', 'каждая остановка', 'туда где не знаю', 'дорога стирает границы'],
      ['билет в один конец', 'карта без маршрута', 'незнакомый язык', 'тысячи миль'],
      ['границы на бумаге', 'небо везде одинаково', 'чемодан и гитара', 'мир становится больше'],
    ],
    chorus: ['дорога зовёт вперёд', 'новый горизонт каждый день', 'в пути ответ на всё', 'музыка и любопытство', 'рассвет меняет карту мира'],
    bridge: ['заблудиться — значит найти', 'не торопи путь насладись', 'возвращение — новое начало', 'следующая станция — сюрприз'],
  },
  'Борьба': {
    verseSets: [
      ['каждый удар делает сильнее', 'зубы стиснуты', 'подняться после падения', 'не сломлен'],
      ['тень сомнения за спиной', 'крик внутри', 'продолжаю идти', 'сквозь боль'],
      ['стена передо мной', 'кулаки в кровь', 'верю в себя', 'доказываю каждому'],
      ['начинал с нуля', 'никто не верил', 'работал молча', 'результат говорит'],
    ],
    chorus: ['не сдаюсь никогда', 'больно но продолжаю', 'моя сила больше страха', 'каждый шрам как медаль', 'победа за каждым шагом'],
    bridge: ['память о поражении — топливо', 'сомнениям говорю нет', 'привыкаю к высоте', 'я — свой главный соперник'],
  },
};

// Build a verse line from a seed, mood, and rhyme word
function makeLine(seed: string, genreMood: string, withRhyme: boolean, rhymeWord?: string): string {
  const base = seed.charAt(0).toLowerCase() + seed.slice(1);
  if (withRhyme && rhymeWord) {
    return `${base}, ${genreMood} — ${rhymeWord}`;
  }
  return `${base}, ${genreMood}`;
}

// Generate a block of lines following the given rhyme scheme
function buildBlock(seeds: string[], genreMood: string, lineCount: number, scheme: RhymeScheme, usedRhymes: Set<string>): string[] {
  const pool = pickN(seeds, Math.max(lineCount, 4));
  const lines: string[] = [];
  let i = 0;
  while (lines.length < lineCount) {
    if (scheme === 'AABB') {
      const a = pool[i % pool.length];
      const b = pool[(i + 1) % pool.length];
      const rhymeA = pickRhyme(a, usedRhymes);
      lines.push(makeLine(a, genreMood, true, rhymeA));
      lines.push(makeLine(b, genreMood, true, pickRhyme(b, usedRhymes)));
      if (lines.length < lineCount) {
        const c = pool[(i + 2) % pool.length];
        const d = pool[(i + 3) % pool.length];
        lines.push(makeLine(c, genreMood, true, pickRhyme(c, usedRhymes)));
        lines.push(makeLine(d, genreMood, true, pickRhyme(d, usedRhymes)));
      }
      i += 4;
    } else if (scheme === 'ABAB') {
      const a = pool[i % pool.length];
      const b = pool[(i + 1) % pool.length];
      const c = pool[(i + 2) % pool.length];
      const d = pool[(i + 3) % pool.length];
      const rhymeA = pickRhyme(a, usedRhymes);
      const rhymeB = pickRhyme(b, usedRhymes);
      lines.push(makeLine(a, genreMood, true, rhymeA));
      lines.push(makeLine(b, genreMood, true, rhymeB));
      lines.push(makeLine(c, genreMood, true, rhymeA));
      lines.push(makeLine(d, genreMood, true, rhymeB));
      i += 4;
    } else {
      // ABBA
      const a = pool[i % pool.length];
      const b = pool[(i + 1) % pool.length];
      const c = pool[(i + 2) % pool.length];
      const d = pool[(i + 3) % pool.length];
      const rhymeA = pickRhyme(a, usedRhymes);
      const rhymeB = pickRhyme(b, usedRhymes);
      lines.push(makeLine(a, genreMood, true, rhymeA));
      lines.push(makeLine(b, genreMood, true, rhymeB));
      lines.push(makeLine(c, genreMood, true, rhymeB));
      lines.push(makeLine(d, genreMood, true, rhymeA));
      i += 4;
    }
  }
  return lines.slice(0, lineCount);
}

function buildLyrics(theme: string, genre: string, structureKey: string, customPrompt: string, t: (k: string) => string): string {
  const preset = STRUCTURE_PRESETS[structureKey] || STRUCTURE_PRESETS['Куплет+Припев+Бридж'];
  const bank = THEME_BANKS[theme] || THEME_BANKS['Любовь'];
  const mood = pick(GENRE_MOODS[genre] || GENRE_MOODS['Хип-Хоп']);
  const usedRhymes = new Set<string>();
  const lines: string[] = [];

  const promptLine = customPrompt.trim()
    ? `${t('Тема')}: ${customPrompt.trim()} — ${t('Жанр')}: ${genre}`
    : `${t('Жанр')}: ${genre} — ${t('Тема')}: ${t(theme)}`;

  lines.push(promptLine);
  lines.push('');

  // Always generate at least 4 verses, each with a DIFFERENT verse set for unique imagery
  const totalVerses = Math.max(4, preset.verses);
  for (let v = 0; v < totalVerses; v++) {
    lines.push(`[${t('Куплет')} ${v + 1}]`);
    // Use different verse set for each verse to ensure unique imagery
    const verseSeeds = bank.verseSets[v % bank.verseSets.length];
    // Vary rhyme scheme across verses for diversity
    const verseScheme: RhymeScheme = v % 3 === 0 ? 'AABB' : v % 3 === 1 ? 'ABAB' : 'ABBA';
    const verseLines = buildBlock(verseSeeds, mood, 4, verseScheme, usedRhymes);
    lines.push(...verseLines);
    lines.push('');

    // Add chorus after verses 2 and 4 (two choruses total)
    if (v === 1 || v === 3) {
      lines.push(`[${t('Припев')}]`);
      const chorusLines = buildBlock(bank.chorus, mood, 4, preset.rhyme, usedRhymes);
      lines.push(...chorusLines);
      lines.push('');
    }
  }

  // Bridge between verses and final chorus
  if (preset.bridge) {
    lines.push(`[${t('Бридж')}]`);
    lines.push(...buildBlock(bank.bridge, mood, 4, 'ABAB', usedRhymes));
    lines.push('');
  }

  // Final chorus (second or third depending on structure)
  lines.push(`[${t('Припев')}]`);
  lines.push(...buildBlock(bank.chorus, mood, 4, preset.rhyme, usedRhymes));

  return lines.join('\n');
}

function getVowelTail(word: string): string {
  const lower = word.toLowerCase().replace(/[^а-яё]/g, '');
  const vowels = lower.replace(/[^аеёиоуыэюя]/g, '');
  return vowels.slice(-2);
}

function checkRhymes(text: string): boolean {
  const lines = text.split('\n').filter((l) => {
    const trimmed = l.trim();
    return trimmed && !trimmed.startsWith('[') && !trimmed.includes('Жанр:') && !trimmed.includes('Тема:');
  });
  if (lines.length < 2) return false;
  let rhymePairs = 0;
  for (let i = 0; i < lines.length - 1; i += 2) {
    const tailA = getVowelTail(lines[i]);
    const tailB = getVowelTail(lines[i + 1]);
    if (tailA && tailB && (tailA === tailB || tailA.slice(-1) === tailB.slice(-1))) {
      rhymePairs++;
    }
  }
  return rhymePairs >= Math.max(1, Math.floor(lines.length / 4));
}

export default function AIStudioPage({ setPage }: { setPage?: (p: Page) => void }) {
  const { addXp } = useAuth();
  const { t } = useLocale();
  const [genre, setGenre] = useState('Хип-Хоп');
  const [lyricTheme, setLyricTheme] = useState('Любовь');
  const [structureKey, setStructureKey] = useState<string>('Куплет+Припев+Бридж');
  const [customPrompt, setCustomPrompt] = useState('');
  const [generatedLyrics, setGeneratedLyrics] = useState('');
  const [generatingLyrics, setGeneratingLyrics] = useState(false);
  const [hasRhyme, setHasRhyme] = useState(false);

  const generateLyrics = () => {
    setGeneratingLyrics(true);
    setTimeout(() => {
      const lyrics = buildLyrics(lyricTheme, genre, structureKey, customPrompt.trim(), t);
      setGeneratedLyrics(lyrics);
      setHasRhyme(checkRhymes(lyrics));
      setGeneratingLyrics(false);
      addXp(15);
    }, 600);
  };

  const copyLyrics = () => {
    navigator.clipboard.writeText(generatedLyrics);
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-theme-text flex items-center gap-2">
          <PenLine className="w-6 h-6 text-theme-accent" />
          {t('ИИ Студия')}
        </h1>
        <p className="text-theme-muted text-sm mt-1">
          {t('Генератор текста песен с разнообразными темами и смыслами')}
        </p>
      </div>

      <div className="bg-theme-surface/50 border border-theme-border rounded-2xl p-6 glass-surface">
        <h3 className="text-sm font-medium text-theme-text mb-4 flex items-center gap-2">
          <PenLine className="w-4 h-4 text-theme-warning" />
          {t('Генератор текста песен')}
        </h3>

        <div className="space-y-4">
          <div>
            <label className="text-xs text-theme-muted uppercase tracking-wider mb-2 block">{t('Тема песни')}</label>
            <div className="flex flex-wrap gap-2">
              {LYRIC_THEMES.map((th) => (
                <button
                  key={th}
                  onClick={() => setLyricTheme(th)}
                  className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${
                    lyricTheme === th ? 'bg-theme-warning text-white' : 'bg-theme-surface2 text-theme-muted hover:text-theme-text'
                  }`}
                >
                  {t(th)}
                </button>
              ))}
            </div>
          </div>

          <div>
            <label className="text-xs text-theme-muted uppercase tracking-wider mb-2 block">{t('Структура')}</label>
            <select
              value={structureKey}
              onChange={(e) => setStructureKey(e.target.value)}
              className="w-full px-3 py-2.5 bg-theme-surface2 border border-theme-border rounded-xl text-theme-text text-sm focus:outline-none focus:border-theme-primary focus:ring-1 focus:ring-theme-primary transition-colors"
            >
              {STRUCTURE_KEYS.map((s) => (
                <option key={s} value={s} className="bg-theme-surface2 text-theme-text">
                  {t(s)}
                </option>
              ))}
            </select>
          </div>

          <div className="flex items-center gap-2 text-xs text-theme-muted">
            <span>{t('Жанр')}:</span>
            <span className="px-2 py-0.5 bg-theme-surface2 rounded text-theme-text font-medium">{t(genre)}</span>
          </div>

          <div>
            <label className="text-xs text-theme-muted uppercase tracking-wider mb-2 block flex items-center gap-1.5">
              <Sparkles className="w-3.5 h-3.5" />
              {t('Свой промпт (необязательно)')}
            </label>
            <input
              type="text"
              value={customPrompt}
              onChange={(e) => setCustomPrompt(e.target.value)}
              placeholder={t('Например: про осень в Москве, про первую любовь, про переезд...')}
              className="w-full px-3 py-2.5 bg-theme-surface2 border border-theme-border rounded-xl text-theme-text text-sm focus:outline-none focus:border-theme-primary focus:ring-1 focus:ring-theme-primary transition-colors"
            />
            <p className="text-[11px] text-theme-muted mt-1">
              {t('Опишите свою тему — ИИ подстроит текст под ваш промпт')}
            </p>
          </div>

          <div>
            <label className="text-xs text-theme-muted uppercase tracking-wider mb-2 block">{t('Жанр')}</label>
            <div className="flex flex-wrap gap-2">
              {GENRES.map((g) => (
                <button
                  key={g}
                  onClick={() => setGenre(g)}
                  className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${
                    genre === g ? 'bg-theme-primary text-white' : 'bg-theme-surface2 text-theme-muted hover:text-theme-text'
                  }`}
                >
                  {t(g)}
                </button>
              ))}
            </div>
          </div>

          <button
            onClick={generateLyrics}
            disabled={generatingLyrics}
            className="px-5 py-2.5 bg-gradient-to-r from-theme-warning to-theme-primary text-white rounded-xl text-sm font-medium hover:shadow-lg transition-all disabled:opacity-50 flex items-center gap-2"
          >
            {generatingLyrics ? <Loader2 className="w-4 h-4 animate-spin" /> : <PenLine className="w-4 h-4" />}
            {t('Сгенерировать текст')}
          </button>

          {generatedLyrics && (
            <div className="mt-4">
              <div className="flex items-center justify-between mb-2">
                <p className="text-xs text-theme-muted">
                  {t('Текст песни')} ({t(lyricTheme)}{customPrompt ? `, ${t('промпт')}: ${customPrompt}` : ''}, {t(genre)}):
                </p>
                <div className="flex items-center gap-2">
                  <span className={`flex items-center gap-1 px-2 py-0.5 rounded-md text-[11px] font-medium ${hasRhyme ? 'bg-theme-success/15 text-theme-success' : 'bg-theme-danger/15 text-theme-danger'}`}>
                    {hasRhyme ? <Check className="w-3 h-3" /> : <X className="w-3 h-3" />}
                    {hasRhyme ? t('Рифма есть') : t('Рифма отсутствует')}
                  </span>
                  <button
                    onClick={copyLyrics}
                    className="p-1.5 text-theme-muted hover:text-theme-text transition-colors"
                    title={t('Скопировать')}
                  >
                    <Copy className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
              <div className="p-4 bg-theme-surface2 rounded-xl border border-theme-border">
                <pre className="text-theme-text text-sm whitespace-pre-wrap font-sans leading-relaxed">{generatedLyrics}</pre>
              </div>
              {setPage && (
                <button
                  onClick={() => setPage('beat')}
                  className="mt-3 px-4 py-2 bg-theme-primary text-white rounded-lg text-xs font-medium hover:bg-theme-primary-hover transition-colors flex items-center gap-2"
                >
                  {t('Открыть Бит-Секвенсор для создания музыки')} <ArrowRight className="w-3.5 h-3.5" />
                </button>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
