import { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';
import App from './App.tsx';
import { PlayerProvider } from '@/context/PlayerContext';
import { SeasonalProvider } from '@/context/SeasonalContext';
import { LocaleProvider } from '@/context/LocaleContext';
import './index.css';

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <SeasonalProvider>
      <LocaleProvider>
        <PlayerProvider>
          <App />
        </PlayerProvider>
      </LocaleProvider>
    </SeasonalProvider>
  </StrictMode>
);
