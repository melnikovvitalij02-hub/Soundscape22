import { createContext, useContext, useMemo, type ReactNode } from 'react';

export type SeasonalTheme = {
  id: string;
  name: string;
  emoji: string;
  cssVars: Record<string, string>;
  bodyClass: string;
};

const NO_THEME: SeasonalTheme = {
  id: 'none',
  name: '',
  emoji: '',
  cssVars: {},
  bodyClass: '',
};

function getActiveTheme(date: Date): SeasonalTheme {
  const month = date.getMonth() + 1;
  const day = date.getDate();

  // Halloween: Oct 31 - Nov 2
  if ((month === 10 && day >= 31) || (month === 11 && day <= 2)) {
    return {
      id: 'halloween',
      name: 'Хэллоуин',
      emoji: 'HAPPY HALLOWEEN',
      cssVars: {
        '--color-primary': '#f97316',
        '--color-primary-hover': '#ea580c',
        '--color-accent': '#a855f7',
        '--color-surface': '#1a0a02',
        '--color-surface2': '#2a1208',
        '--color-border': 'rgba(249,115,22,0.15)',
      },
      bodyClass: 'seasonal-halloween',
    };
  }

  // New Year: Dec 25 - Jan 7
  if ((month === 12 && day >= 25) || (month === 1 && day <= 7)) {
    return {
      id: 'newyear',
      name: 'Новый Год',
      emoji: 'С НОВЫМ ГОДОМ!',
      cssVars: {
        '--color-primary': '#ef4444',
        '--color-primary-hover': '#dc2626',
        '--color-accent': '#fbbf24',
        '--color-surface': '#0a0a12',
        '--color-surface2': '#141420',
        '--color-border': 'rgba(239,68,68,0.15)',
      },
      bodyClass: 'seasonal-newyear',
    };
  }

  // Valentine's Day: Feb 13-15
  if (month === 2 && day >= 13 && day <= 15) {
    return {
      id: 'valentine',
      name: 'День Святого Валентина',
      emoji: 'С ДНЁМ ВЛЮБЛЁННЫХ',
      cssVars: {
        '--color-primary': '#ec4899',
        '--color-primary-hover': '#db2777',
        '--color-accent': '#f43f5e',
        '--color-surface': '#120a0e',
        '--color-surface2': '#1f1218',
        '--color-border': 'rgba(236,72,153,0.15)',
      },
      bodyClass: 'seasonal-valentine',
    };
  }

  // Spring/March 8: Mar 7-9
  if (month === 3 && day >= 7 && day <= 9) {
    return {
      id: 'spring8',
      name: '8 Марта',
      emoji: 'С 8 МАРТА!',
      cssVars: {
        '--color-primary': '#f472b6',
        '--color-primary-hover': '#ec4899',
        '--color-accent': '#fb7185',
        '--color-surface': '#0e0a10',
        '--color-surface2': '#1a1218',
        '--color-border': 'rgba(244,114,182,0.15)',
      },
      bodyClass: 'seasonal-spring',
    };
  }

  return NO_THEME;
}

type SeasonalContextType = {
  theme: SeasonalTheme;
  isActive: boolean;
};

const SeasonalContext = createContext<SeasonalContextType | undefined>(undefined);

export function SeasonalProvider({ children }: { children: ReactNode }) {
  const theme = useMemo(() => getActiveTheme(new Date()), []);

  const value = useMemo(() => ({
    theme,
    isActive: theme.id !== 'none',
  }), [theme]);

  return (
    <SeasonalContext.Provider value={value}>
      {children}
    </SeasonalContext.Provider>
  );
}

export function useSeasonal() {
  const ctx = useContext(SeasonalContext);
  if (!ctx) return { theme: NO_THEME, isActive: false };
  return ctx;
}
