const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, HEAD, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey, Range",
};

type TrackMeta = { title: string; artist: string; sources: string[] };

const TRACKS: Record<string, TrackMeta> = {
  igotu: {
    title: "I GOT U",
    artist: "Toxis",
    sources: [
      "https://dl4s5.bazamp3.com/aHR0cDovL2YubXAzcG9pc2submV0L21wMy8wMDUvMzMzLzA5Mi81MzMzMDkyLm1wMz90aXRsZT1Ub3hpcystK0krR290K1UrJTI4YmF6YW1wMy5jb20lMjkubXAz",
      "https://muz.zvukofon.com/dl/1401492714/Toxis_-_I_Got_U_(musportal.org).mp3",
    ],
  },
  malo: {
    title: "Мало 2.0",
    artist: "Егор Крид",
    sources: [
      "https://lmusic.kz/api/download/398966",
      "https://ru.monfons.com/dl/16225370/Egor_Krid_-_Malo_2.0_(ru.monfons.com).mp3",
      "https://ru-d3.drivemusic.me/dl/QtaCWxS7rLVKrxViG00nsA/1791955851/download_music/2026/01/egor-krid-malo-2.0.mp3",
    ],
  },
  tonu: {
    title: "Тону",
    artist: "HOLLYFLAME",
    sources: [
      "https://muz.zvukofon.com/dl/1401492714/HOLLYFLAME_-_Tonu_(musportal.org).mp3",
      "https://ru-d1.drivemusic.me/dl/YHRo8g7VVEXLHEK_7z7hBQ/1791958658/download_music/2024/11/hollyflame-tonu.mp3",
    ],
  },
  lada: {
    title: "Малиновая Лада",
    artist: "GAYAZOV BROTHERS",
    sources: [
      "https://s.muzrecord.com/files/gayazov-brother-malinovaya-lada.mp3?download=1",
      "https://ru.monfons.com/dl/16225370/GAYAZOV_BROTHERS_-_Malinovaya_Lada_(ru.monfons.com).mp3",
    ],
  },
  baram: {
    title: "По барам",
    artist: "ANNA ASTI",
    sources: [
      "https://ru.monfons.com/dl/16225370/ANNA_ASTI_-_Po_baram_(ru.monfons.com).mp3",
      "https://ru-d3.drivemusic.me/dl/QtaCWxS7rLVKrxViG00nsA/1791955851/download_music/2026/01/anna-asti-po-baram.mp3",
    ],
  },
  sleza: {
    title: "Слеза",
    artist: "Егор Крид",
    sources: [
      "https://ru-d1.drivemusic.me/dl/seiiOLnJ_6w0GvYvyinz4w/1791959759/download_music/2017/12/egor-krid-sleza.mp3",
      "https://ru.monfons.com/dl/16225370/Egor_Krid_-_Sleza_(ru.monfons.com).mp3",
    ],
  },
  baloo: {
    title: "BALOO",
    artist: "Бодя Мир642",
    sources: [
      "https://ru-d3.drivemusic.me/dl/QtaCWxS7rLVKrxViG00nsA/1791955851/download_music/2026/01/bodja-mir642-amp-dewensoon-baloo.mp3",
    ],
  },
  basta: {
    title: "Если я буду танцевать",
    artist: "Баста",
    sources: [
      "https://zvukim.ru/uploads/files/2026-07/basta_-moya-mishelj-_-esli-ya-budu-tantsevatj.mp3",
      "https://ru.monfons.com/dl/16225370/Basta_Moya_Mishel_-_Esli_ya_budu_tantsevat_(ru.monfons.com).mp3",
    ],
  },
  gaz: {
    title: "GAZ",
    artist: "Zivert",
    sources: [
      "https://ru-d3.drivemusic.me/dl/9_krCZiAjd0ro4f6cKNZ_g/1791956024/download_music/2026/04/zivert-gaz.mp3",
      "https://ru.monfons.com/dl/16225370/Zivert_-_GAZ_(ru.monfons.com).mp3",
    ],
  },
  charlie: {
    title: "We Don't Talk Anymore",
    artist: "Charlie Puth",
    sources: [
      "https://ru-d1.drivemusic.me/dl/s-sNL79B3OpE4b4aJxnDOw/1791956072/download_music/2016/01/charlie-puth-feat.-selena-gomez-we-dont-talk-anymore.mp3",
    ],
  },
  orly: {
    title: "Орлы или вороны",
    artist: "Григорий Лепс",
    sources: [
      "https://ru-d3.drivemusic.me/dl/F3V94dVs0ABoC9kXiba4Yg/1791956136/download_music/2017/09/maksim-fadeev-grigorijj-leps-orly-ili-vorony.mp3",
    ],
  },
  avemaria: {
    title: "Ave Maria",
    artist: "Димаш Кудайберген",
    sources: [
      "https://ru-d1.drivemusic.me/dl/YHRo8g7VVEXLHEK_7z7hBQ/1791958658/download_music/2024/11/igor-krutojj-dimash-kudajjbergen-ave-maria.mp3",
    ],
  },
  rozhdestvo: {
    title: "Так хочется жить",
    artist: "Рождество",
    sources: [
      "https://ru-d3.drivemusic.me/dl/QXFdA9YrW7eFNjXlBBEU2Q/1791959826/download_music/2022/07/rozhdestvo-tak-khochetsja-zhit.mp3",
    ],
  },
  sansara: {
    title: "Сансара",
    artist: "Баста",
    sources: [
      "https://ru-d1.drivemusic.me/dl/qp71UZRK20eAiZnB9fV9nw/1791956250/download_music/2017/04/basta-sansara.mp3",
    ],
  },
  bilan: {
    title: "Как хотел я",
    artist: "Дима Билан",
    sources: [
      "https://d1.hitmo.net/L3QvMTgxNjAwMC/QlNC40LzQsCDQkdC40LvQsNC9IC0g0JrQsNC6INGF0L7RgtC10Lsg0Y8gKGhpdG1vLm5ldCkubXAz.mp3",
    ],
  },
  milyy: {
    title: "Милый негодяй",
    artist: "Егор Крид",
    sources: [
      "https://d13.drivemusic.me/dl/g_2Lc5pZCxx7lj2T-_GDMA/1792266278/download_music/2026/10/egor-krid-milyjj-ubljudok.mp3",
    ],
  },
};

function getReferer(url: string): string {
  try {
    const parsed = new URL(url);
    return `${parsed.protocol}//${parsed.host}/`;
  } catch {
    return "https://www.google.com/";
  }
}

function normalize(value: string): string {
  return value.toLowerCase().replace(/ё/g, "е").replace(/[^a-zа-я0-9]/g, "");
}

type DeezerTrack = { title?: string; preview?: string; artist?: { name?: string } };
type ITunesTrack = { trackName?: string; artistName?: string; previewUrl?: string };

async function resolveDeezerPreview(meta: TrackMeta): Promise<string | null> {
  try {
    const queries = [`track:"${meta.title}"`, `${meta.artist} ${meta.title}`, meta.title];
    for (const q of queries) {
      const response = await fetchWithTimeout(
        `https://api.deezer.com/search?q=${encodeURIComponent(q)}&limit=10`,
        { headers: { Accept: "application/json" } },
        4000,
      );
      if (!response.ok) continue;
      const payload = await response.json() as { data?: DeezerTrack[] };
      const tracks = payload.data || [];
      const wantedTitle = normalize(meta.title);
      const match = tracks.find((t) => {
        if (!t.preview) return false;
        const title = normalize(t.title || "");
        return title === wantedTitle || title.includes(wantedTitle) || wantedTitle.includes(title);
      });
      if (match?.preview) return match.preview;
      const firstWithPreview = tracks.find((t) => Boolean(t.preview));
      if (firstWithPreview?.preview) return firstWithPreview.preview;
    }
    return null;
  } catch {
    return null;
  }
}

async function resolveITunesPreview(meta: TrackMeta): Promise<string | null> {
  try {
    const response = await fetchWithTimeout(
      `https://itunes.apple.com/search?media=music&entity=song&limit=25&term=${encodeURIComponent(`${meta.artist} ${meta.title}`)}`,
      { headers: { Accept: "application/json" } },
      4000,
    );
    if (!response.ok) return null;
    const payload = await response.json() as { results?: ITunesTrack[] };
    const results = payload.results || [];
    const wantedTitle = normalize(meta.title);
    const match = results.find((t) => {
      if (!t.previewUrl) return false;
      const title = normalize(t.trackName || "");
      return title === wantedTitle || title.includes(wantedTitle) || wantedTitle.includes(title);
    });
    if (match?.previewUrl) return match.previewUrl;
    const firstWithPreview = results.find((t) => Boolean(t.previewUrl));
    return firstWithPreview?.previewUrl || null;
  } catch {
    return null;
  }
}

async function fetchWithTimeout(url: string, init: RequestInit, timeoutMs: number): Promise<Response> {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  try {
    return await fetch(url, { ...init, signal: controller.signal });
  } finally {
    clearTimeout(timer);
  }
}

async function tryFetchAudio(url: string, range: string | null): Promise<Response | null> {
  const headers: Record<string, string> = {
    Accept: "audio/mpeg, audio/*, */*",
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
    Referer: getReferer(url),
  };
  if (range) headers.Range = range;

  try {
    const response = await fetchWithTimeout(url, { headers, redirect: "follow" }, 8000);
    if (response.ok || response.status === 206) {
      const ct = (response.headers.get("Content-Type") || "").toLowerCase();
      if (ct.includes("text/html")) return null;
      return response;
    }
    return null;
  } catch {
    return null;
  }
}

async function trySourcesInParallel(sources: string[], range: string | null): Promise<Response | null> {
  const attempts = sources.map((url) => tryFetchAudio(url, range));
  const results = await Promise.allSettled(attempts);
  for (const result of results) {
    if (result.status === "fulfilled" && result.value) return result.value;
  }
  return null;
}

Deno.serve(async (request: Request) => {
  if (request.method === "OPTIONS") {
    return new Response(null, { status: 204, headers: corsHeaders });
  }

  if (request.method !== "GET" && request.method !== "HEAD") {
    return new Response("Method not allowed", { status: 405, headers: corsHeaders });
  }

  try {
    const trackKey = new URL(request.url).searchParams.get("track");
    const meta = trackKey ? TRACKS[trackKey] : undefined;
    if (!meta) {
      return new Response("Track not found", { status: 404, headers: corsHeaders });
    }

    const range = request.headers.get("Range");

    // 1. Try ALL direct sources in parallel — fastest wins
    let audioResponse = await trySourcesInParallel(meta.sources, range);

    // 2. Fallback to Deezer + iTunes previews in parallel
    if (!audioResponse) {
      const [deezerUrl, itunesUrl] = await Promise.all([
        resolveDeezerPreview(meta),
        resolveITunesPreview(meta),
      ]);
      const previewSources = [deezerUrl, itunesUrl].filter(Boolean) as string[];
      if (previewSources.length > 0) {
        audioResponse = await trySourcesInParallel(previewSources, range);
      }
    }

    if (!audioResponse) {
      return new Response(
        JSON.stringify({ error: "Audio source unavailable", track: trackKey }),
        { status: 404, headers: { ...corsHeaders, "Content-Type": "application/json" } },
      );
    }

    const sourceCt = (audioResponse.headers.get("Content-Type") || "").toLowerCase();
    const contentType = "audio/mpeg";

    const responseHeaders: Record<string, string> = {
      ...corsHeaders,
      "Content-Type": contentType,
      "Accept-Ranges": "bytes",
      "Cache-Control": "public, max-age=3600",
    };
    const length = audioResponse.headers.get("Content-Length");
    const contentRange = audioResponse.headers.get("Content-Range");
    if (length) responseHeaders["Content-Length"] = length;
    if (contentRange) responseHeaders["Content-Range"] = contentRange;

    return new Response(audioResponse.body, {
      status: audioResponse.status,
      headers: responseHeaders,
    });
  } catch (error) {
    console.error("Audio proxy error:", error);
    return new Response(
      JSON.stringify({ error: "Audio service unavailable" }),
      { status: 502, headers: { ...corsHeaders, "Content-Type": "application/json" } },
    );
  }
});
