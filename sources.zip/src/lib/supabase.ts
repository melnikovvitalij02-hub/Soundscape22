import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

if (!supabaseUrl || !supabaseAnonKey) {
  throw new Error('Missing Supabase environment variables');
}

export const supabase = createClient(supabaseUrl, supabaseAnonKey, {
  auth: {
    persistSession: true,
    autoRefreshToken: true,
  detectSessionInUrl: true,
  storage: window.localStorage,
  storageKey: 'soundscape-auth',
  debug: false,
  },
});

export type Profile = {
  id: string;
  username: string;
  avatar_url: string | null;
  bio: string;
  xp: number;
  level: number;
  coins: number;
  created_at: string;
  updated_at: string;
  is_online: boolean;
  last_seen: string;
};

export type PrivateMessage = {
  id: string;
  sender_id: string;
  recipient_id: string;
  content: string;
  read: boolean;
  created_at: string;
};

export type ChatMessage = {
  id: string;
  user_id: string;
  username: string;
  avatar_url: string | null;
  content: string;
  created_at: string;
};

export type Project = {
  id: string;
  user_id: string;
  name: string;
  data: Record<string, unknown>;
  genre: string;
  bpm: number;
  created_at: string;
  updated_at: string;
};

export type Achievement = {
  id: string;
  name: string;
  description: string;
  icon: string;
  xp_reward: number;
  coin_reward: number;
  requirement_type: string;
  requirement_value: number;
};

export type UserAchievement = {
  id: string;
  user_id: string;
  achievement_id: string;
  earned_at: string;
};

export type Friendship = {
  id: string;
  requester_id: string;
  addressee_id: string;
  status: 'pending' | 'accepted' | 'blocked';
  created_at: string;
  accepted_at: string | null;
};

export type GameScore = {
  id: string;
  user_id: string;
  game_name: string;
  score: number;
  played_at: string;
};

export type Beat = {
  id: string;
  user_id: string;
  title: string;
  genre: string;
  bpm: number;
  audio_url: string | null;
  cover_url: string | null;
  play_count: number;
  created_at: string;
};

export type BeatLike = {
  id: string;
  beat_id: string;
  user_id: string;
  created_at: string;
};

export type BeatComment = {
  id: string;
  beat_id: string;
  user_id: string;
  username: string;
  avatar_url: string | null;
  content: string;
  created_at: string;
};

export type VoiceComment = {
  id: string;
  beat_id: string;
  user_id: string;
  username: string;
  avatar_url: string | null;
  audio_url: string;
  duration: number;
  created_at: string;
};

export type Clan = {
  id: string;
  name: string;
  description: string;
  leader_id: string;
  tag: string;
  created_at: string;
};

export type ClanMember = {
  id: string;
  clan_id: string;
  user_id: string;
  role: string;
  joined_at: string;
};

export type PvPBattle = {
  id: string;
  beat_a_id: string;
  beat_b_id: string;
  creator_a_id: string;
  creator_b_id: string | null;
  votes_a: number;
  votes_b: number;
  status: string;
  winner_id: string | null;
  created_at: string;
  ends_at: string;
};

export type Story = {
  id: string;
  user_id: string;
  track_title: string;
  audio_url: string | null;
  image_url: string | null;
  created_at: string;
  expires_at: string;
};

export type CollabPlaylist = {
  id: string;
  name: string;
  creator_id: string;
  created_at: string;
};

export type DailyReward = {
  id: string;
  user_id: string;
  last_claimed_date: string | null;
  streak_days: number;
  total_coins_earned: number;
  created_at: string;
};

export type SeasonalEvent = {
  id: string;
  name: string;
  description: string;
  start_date: string;
  end_date: string;
  theme: string;
  bonus_xp_multiplier: number;
  is_active: boolean;
};

export type Subscription = {
  id: string;
  user_id: string;
  status: string;
  plan: string;
  started_at: string | null;
  expires_at: string | null;
};

export type AvatarShopItem = {
  id: string;
  name: string;
  image_url: string;
  price: number;
  rarity: string;
  created_at: string;
};

export type Community = {
  id: string;
  name: string;
  description: string;
  genre: string;
  icon: string;
  member_count: number;
  created_at: string;
};

export type ListeningStat = {
  id: string;
  user_id: string;
  date: string;
  minutes_listened: number;
  created_at: string;
};

export type SupportDonation = {
  id: string;
  supporter_id: string;
  creator_id: string;
  amount: number;
  message: string;
  created_at: string;
};

export type Remix = {
  id: string;
  original_beat_id: string;
  remixer_id: string;
  title: string;
  audio_url: string | null;
  created_at: string;
};

export const XP_PER_LEVEL = 500;

export function xpForLevel(level: number): number {
  return (level - 1) * XP_PER_LEVEL;
}

export function levelFromXp(xp: number): number {
  return Math.floor(xp / XP_PER_LEVEL) + 1;
}

export function xpProgress(xp: number): { current: number; needed: number; percent: number } {
  const level = levelFromXp(xp);
  const base = xpForLevel(level);
  const current = xp - base;
  const needed = XP_PER_LEVEL;
  return { current, needed, percent: (current / needed) * 100 };
}
