import { useState, useEffect } from 'react';
import { useAuth } from '@/context/AuthContext';
import { supabase, xpProgress } from '@/lib/supabase';
import ThemeSwitcher from '@/components/ThemeSwitcher';
import {
  Music,
  Drum,
  Mic,
  Search,
  MessageCircle,
  Gamepad2,
  User,
  LogOut,
  Coins,
  Zap,
  Menu,
  X,
  BarChart3,
  MessageSquare,
  Newspaper,
  Swords,
  ListMusic,
  Users2,
  Info,
  BarChart,
  Gift,
  Calendar,
  ShoppingBag,
  Waves,
  Sparkles,
  Crown,
} from 'lucide-react';

export type Page =
  | 'home'
  | 'beat'
  | 'studio'
  | 'search'
  | 'charts'
  | 'chat'
  | 'messages'
  | 'games'
  | 'profile'
  | 'feed'
  | 'clans'
  | 'pvp'
  | 'playlists'
  | 'communities'
  | 'about'
  | 'stats'
  | 'seasonal'
  | 'daily'
  | 'shop'
  | 'automix'
  | 'ai-enhanced';

const navItems: { id: Page; label: string; icon: typeof Music }[] = [
  { id: 'profile', label: 'Профиль', icon: User },
  { id: 'home', label: 'Главная', icon: Music },
  { id: 'beat', label: 'Бит-Секвенсор', icon: Drum },
  { id: 'studio', label: 'ИИ Студия', icon: Mic },
  { id: 'search', label: 'Поиск Музыки', icon: Search },
  { id: 'charts', label: 'Чарты', icon: BarChart3 },
  { id: 'chat', label: 'Чат', icon: MessageCircle },
  { id: 'messages', label: 'Сообщения', icon: MessageSquare },
  { id: 'games', label: 'Игры', icon: Gamepad2 },
  { id: 'feed', label: 'Лента битов', icon: Newspaper },
  { id: 'clans', label: 'Кланы', icon: Crown },
  { id: 'pvp', label: 'PvP Битвы', icon: Swords },
  { id: 'playlists', label: 'Плейлисты', icon: ListMusic },
  { id: 'communities', label: 'Сообщества', icon: Users2 },
  { id: 'daily', label: 'Награды', icon: Gift },
  { id: 'seasonal', label: 'События', icon: Calendar },
  { id: 'stats', label: 'Статистика', icon: BarChart },
  { id: 'shop', label: 'Магазин', icon: ShoppingBag },
  { id: 'automix', label: 'Автомикс', icon: Waves },
  { id: 'ai-enhanced', label: 'AI Инструменты', icon: Sparkles },
  { id: 'about', label: 'О нас', icon: Info },
];

export default function Sidebar({
  page,
  setPage,
}: {
  page: Page;
  setPage: (p: Page) => void;
}) {
  const { profile, signOut } = useAuth();
  const [mobileOpen, setMobileOpen] = useState(false);
  const [unreadCount, setUnreadCount] = useState(0);

  useEffect(() => {
    if (!profile) return;
    const channel = supabase
      .channel('chat-unread')
      .on(
        'postgres_changes',
        {
          event: 'INSERT',
          schema: 'public',
          table: 'chat_messages',
          filter: `user_id=neq.${profile.id}`,
        },
        () => {
          setUnreadCount((c) => c + 1);
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [profile]);

  const handleNav = (p: Page) => {
    setPage(p);
    setMobileOpen(false);
    if (p === 'chat') setUnreadCount(0);
  };

  const progress = profile ? xpProgress(profile.xp) : null;

  const logo = (
    <div className="flex items-center gap-2">
      <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-theme-primary to-theme-accent flex items-center justify-center">
        <Music className="w-5 h-5 text-white" />
      </div>
      <span className="text-theme-text font-bold text-sm">Soundscape Pro</span>
    </div>
  );

  const navContent = (
    <nav className="flex-1 px-3 py-4 space-y-1 overflow-y-auto">
      {navItems.map((item) => {
        const Icon = item.icon;
        const active = page === item.id;
        return (
          <button
            key={item.id}
            onClick={() => handleNav(item.id)}
            className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-all ${
              active
                ? 'bg-theme-primary-bg text-theme-primary-text border border-theme-primary-border'
                : 'text-theme-muted hover:text-theme-text hover:bg-theme-surface2'
            }`}
          >
            <Icon className="w-5 h-5 shrink-0" />
            <span className="flex-1 text-left">{item.label}</span>
            {item.id === 'chat' && unreadCount > 0 && (
              <span className="px-2 py-0.5 text-xs font-bold bg-theme-danger text-white rounded-full">
                {unreadCount}
              </span>
            )}
          </button>
        );
      })}
    </nav>
  );

  const profileSection = (
    <div className="px-3 py-3 border-t border-theme-border">
      {profile && progress && (
        <div className="mb-3 px-3 space-y-2">
          <div className="flex items-center justify-between text-xs">
            <span className="text-theme-muted">Уровень {profile.level}</span>
            <span className="text-theme-muted">
              {progress.current}/{progress.needed} XP
            </span>
          </div>
          <div className="h-1.5 bg-theme-surface2 rounded-full overflow-hidden">
            <div
              className="h-full bg-gradient-to-r from-theme-primary to-theme-accent rounded-full transition-all duration-500"
              style={{ width: `${progress.percent}%` }}
            />
          </div>
          <div className="flex items-center gap-3 text-xs">
            <span className="flex items-center gap-1 text-theme-warning">
              <Coins className="w-3.5 h-3.5" />
              {profile.coins}
            </span>
            <span className="flex items-center gap-1 text-theme-primary">
              <Zap className="w-3.5 h-3.5" />
              {profile.xp} XP
            </span>
          </div>
        </div>
      )}
      <ThemeSwitcher />
      <button
        onClick={() => handleNav('profile')}
        className="w-full flex items-center gap-3 px-3 py-2 rounded-lg text-sm text-theme-muted hover:text-theme-text hover:bg-theme-surface2 transition-colors"
      >
        {profile?.avatar_url ? (
          <img
            src={profile.avatar_url}
            alt=""
            className="w-8 h-8 rounded-full object-cover"
          />
        ) : (
          <div className="w-8 h-8 rounded-full bg-gradient-to-br from-theme-primary to-theme-accent flex items-center justify-center text-white text-xs font-bold">
            {profile?.username?.[0]?.toUpperCase() || '?'}
          </div>
        )}
        <span className="flex-1 text-left truncate">{profile?.username || 'Пользователь'}</span>
      </button>
      <button
        onClick={signOut}
        className="w-full flex items-center gap-3 px-3 py-2 rounded-lg text-sm text-theme-muted hover:text-theme-danger hover:bg-theme-danger/10 transition-colors mt-1"
      >
        <LogOut className="w-5 h-5" />
        <span>Выйти</span>
      </button>
    </div>
  );

  return (
    <>
      {/* Mobile header */}
      <div className="lg:hidden fixed top-0 left-0 right-0 z-50 flex items-center justify-between px-4 py-3 bg-theme-surface/95 backdrop-blur-xl border-b border-theme-border glass-surface">
        {logo}
        <button
          onClick={() => setMobileOpen(!mobileOpen)}
          className="p-2 text-theme-muted hover:text-theme-text"
        >
          {mobileOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
        </button>
      </div>

      {/* Mobile overlay */}
      {mobileOpen && (
        <div
          className="lg:hidden fixed inset-0 z-40 bg-black/60 backdrop-blur-sm"
          onClick={() => setMobileOpen(false)}
        />
      )}

      {/* Mobile sidebar */}
      <aside
        className={`lg:hidden fixed top-0 left-0 bottom-0 z-50 w-72 bg-theme-surface border-r border-theme-border flex flex-col transition-transform duration-300 glass-surface ${
          mobileOpen ? 'translate-x-0' : '-translate-x-full'
        }`}
      >
        <div className="h-14 flex items-center px-4 border-b border-theme-border">
          {logo}
        </div>
        {navContent}
        {profileSection}
      </aside>

      {/* Desktop sidebar */}
      <aside className="hidden lg:flex fixed top-0 left-0 bottom-0 w-64 bg-theme-surface border-r border-theme-border flex-col z-30 glass-surface">
        <div className="h-14 flex items-center px-4 border-b border-theme-border">
          {logo}
        </div>
        {navContent}
        {profileSection}
      </aside>
    </>
  );
}
