import { useState } from 'react';
import { useAuth } from '@/context/AuthContext';
import { Music, Loader2, User } from 'lucide-react';

export default function AuthScreen() {
  const { signIn, signUp, signInGuest } = useAuth();
  const [mode, setMode] = useState<'signin' | 'signup'>('signin');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [username, setUsername] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setLoading(true);
    const result =
      mode === 'signin'
        ? await signIn(email, password)
        : await signUp(email, password, username);
    setLoading(false);
    if (result.error) {
      setError(result.error);
    } else if (mode === 'signup') {
      setSuccess(true);
    }
  };

  return (
    <div className="min-h-screen bg-theme-bg flex items-center justify-center p-4 relative overflow-hidden">
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute top-1/4 left-1/4 w-96 h-96 rounded-full blur-3xl" style={{ background: 'rgba(var(--color-primary-rgb), 0.1)' }} />
        <div className="absolute bottom-1/4 right-1/4 w-96 h-96 rounded-full blur-3xl" style={{ background: 'rgba(var(--color-accent-rgb), 0.1)' }} />
      </div>

      <div className="relative w-full max-w-md">
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-gradient-to-br from-theme-primary to-theme-accent mb-4 shadow-lg" style={{ boxShadow: '0 10px 40px rgba(var(--color-primary-rgb), 0.3)' }}>
            <Music className="w-8 h-8 text-white" />
          </div>
          <h1 className="text-3xl font-bold text-theme-text tracking-tight">Soundscape Pro</h1>
          <p className="mt-2 text-sm font-medium bg-gradient-to-r from-cyan-400 via-emerald-400 to-amber-400 bg-clip-text text-transparent">
            Долина звука
          </p>
          <p className="text-theme-muted mt-1 text-sm">
            Музыкальная социальная платформа — создавай, делись, играй
          </p>
        </div>

        <div className="bg-theme-surface/80 backdrop-blur-xl border border-theme-border rounded-2xl p-8 shadow-2xl glass-surface">
          <div className="flex gap-2 mb-6 p-1 bg-theme-surface2 rounded-lg">
            <button
              onClick={() => setMode('signin')}
              className={`flex-1 py-2 rounded-md text-sm font-medium transition-all ${
                mode === 'signin'
                  ? 'bg-theme-primary text-white shadow-lg'
                  : 'text-theme-muted hover:text-theme-text'
              }`}
            >
              Войти
            </button>
            <button
              onClick={() => setMode('signup')}
              className={`flex-1 py-2 rounded-md text-sm font-medium transition-all ${
                mode === 'signup'
                  ? 'bg-theme-primary text-white shadow-lg'
                  : 'text-theme-muted hover:text-theme-text'
              }`}
            >
              Регистрация
            </button>
          </div>

          {success && (
            <div className="text-sm text-theme-success bg-theme-success/10 border border-theme-success/20 rounded-lg px-4 py-3 text-center">
              Аккаунт создан! Проверьте почту для подтверждения, затем войдите.
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4">
            {mode === 'signup' && (
              <div>
                <label className="block text-xs font-medium text-theme-muted mb-1.5">Имя пользователя</label>
                <input
                  type="text"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  required
                  className="w-full px-4 py-2.5 bg-theme-surface2 border border-theme-border rounded-lg text-theme-text text-sm focus:outline-none focus:border-theme-primary focus:ring-1 focus:ring-theme-primary transition-colors"
                  placeholder="ваш_никнейм"
                />
              </div>
            )}
            <div>
              <label className="block text-xs font-medium text-theme-muted mb-1.5">Эл. почта</label>
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
                className="w-full px-4 py-2.5 bg-theme-surface2 border border-theme-border rounded-lg text-theme-text text-sm focus:outline-none focus:border-theme-primary focus:ring-1 focus:ring-theme-primary transition-colors"
                placeholder="you@example.com"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-theme-muted mb-1.5">Пароль</label>
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
                minLength={6}
                className="w-full px-4 py-2.5 bg-theme-surface2 border border-theme-border rounded-lg text-theme-text text-sm focus:outline-none focus:border-theme-primary focus:ring-1 focus:ring-theme-primary transition-colors"
                placeholder="••••••••"
              />
            </div>

            {error && (
              <div className="text-sm text-theme-danger bg-theme-danger/10 border border-theme-danger/20 rounded-lg px-4 py-2.5">
                {error}
              </div>
            )}

            <button
              type="submit"
              disabled={loading}
              className="w-full py-2.5 bg-gradient-to-r from-theme-primary to-theme-accent text-white rounded-lg font-medium text-sm hover:shadow-lg transition-all disabled:opacity-50 flex items-center justify-center gap-2"
              style={{ boxShadow: '0 8px 30px rgba(var(--color-primary-rgb), 0.3)' }}
            >
              {loading && <Loader2 className="w-4 h-4 animate-spin" />}
              {mode === 'signin' ? 'Войти' : 'Создать аккаунт'}
            </button>

            <div className="flex items-center gap-3 my-2">
              <div className="flex-1 h-px bg-theme-border" />
              <span className="text-xs text-theme-muted">или</span>
              <div className="flex-1 h-px bg-theme-border" />
            </div>

            <button
              type="button"
              onClick={signInGuest}
              className="w-full py-2.5 bg-theme-surface2 border border-theme-border text-theme-text rounded-lg font-medium text-sm hover:border-theme-primary hover:text-theme-primary transition-all flex items-center justify-center gap-2"
            >
              <User className="w-4 h-4" />
              Войти как гость
            </button>
          </form>
        </div>

        <p className="text-center text-xs text-theme-muted mt-6">
          Создавай биты, записывай аудио, общайся, играй и зарабатывай XP
        </p>
      </div>
    </div>
  );
}
