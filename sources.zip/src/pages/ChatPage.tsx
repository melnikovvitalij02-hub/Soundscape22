import { useState, useEffect, useRef, useCallback } from 'react';
import { useAuth } from '@/context/AuthContext';
import { supabase, type ChatMessage } from '@/lib/supabase';
import { Send, MessageCircle, Loader2, AlertCircle, Check } from 'lucide-react';

export default function ChatPage() {
  const { profile, addXp } = useAuth();
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(true);
  const [sending, setSending] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [lastSentId, setLastSentId] = useState<string | null>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const fetchMessages = useCallback(async () => {
    const { data, error: fetchError } = await supabase
      .from('chat_messages')
      .select('*')
      .order('created_at', { ascending: true })
      .limit(100);
    if (fetchError) {
      setError('Не удалось загрузить сообщения. Проверь подключение.');
    } else if (data) {
      setMessages(data as ChatMessage[]);
    }
    setLoading(false);
  }, []);

  useEffect(() => {
    fetchMessages();

    const channel = supabase
      .channel('chat-messages')
      .on(
        'postgres_changes',
        {
          event: 'INSERT',
          schema: 'public',
          table: 'chat_messages',
        },
        (payload) => {
          setMessages((prev) => {
            const exists = prev.some((m) => m.id === (payload.new as ChatMessage).id);
            if (exists) return prev;
            return [...prev, payload.new as ChatMessage];
          });
        }
      )
      .on(
        'postgres_changes',
        {
          event: 'DELETE',
          schema: 'public',
          table: 'chat_messages',
        },
        () => {
          setMessages((prev) => prev.slice(0, -1));
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [fetchMessages]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const sendMessage = async () => {
    if (!input.trim() || !profile) return;
    setSending(true);
    setError(null);

    const content = input.trim();
    const tempId = `temp-${Date.now()}`;
    const optimisticMsg: ChatMessage = {
      id: tempId,
      user_id: profile.id,
      username: profile.username,
      avatar_url: profile.avatar_url,
      content,
      created_at: new Date().toISOString(),
    };
    setMessages((prev) => [...prev, optimisticMsg]);
    setInput('');

    const { data, error: insertError } = await supabase
      .from('chat_messages')
      .insert({
        user_id: profile.id,
        username: profile.username,
        avatar_url: profile.avatar_url,
        content,
      })
      .select('*')
      .single();

    if (insertError) {
      setError('Сообщение не отправилось. Попробуй ещё раз.');
      setMessages((prev) => prev.filter((m) => m.id !== tempId));
      setInput(content);
    } else {
      setMessages((prev) =>
        prev.map((m) => (m.id === tempId ? (data as ChatMessage) : m))
      );
      setLastSentId((data as ChatMessage).id);
      await addXp(5);
    }
    setSending(false);
  };

  const formatTime = (ts: string) => {
    const date = new Date(ts);
    return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  };

  return (
    <div className="space-y-4">
      <div>
        <h1 className="text-2xl font-bold text-theme-text flex items-center gap-2">
          <MessageCircle className="w-6 h-6 text-theme-primary" />
          Глобальный Чат
        </h1>
        <p className="text-theme-muted text-sm mt-1">
          Общение с сообществом Soundscape в реальном времени
        </p>
      </div>

      <div className="glass-surface bg-theme-surface/50 border border-theme-border rounded-2xl flex flex-col h-[calc(100vh-220px)] min-h-[400px]">
        {/* Messages */}
        <div className="flex-1 overflow-y-auto p-4 space-y-3">
          {loading ? (
            <div className="flex items-center justify-center h-full">
              <Loader2 className="w-6 h-6 text-theme-primary animate-spin" />
            </div>
          ) : messages.length === 0 ? (
            <div className="flex flex-col items-center justify-center h-full text-center">
              <MessageCircle className="w-12 h-12 text-theme-muted mb-3" />
              <p className="text-theme-muted text-sm">Сообщений пока нет. Начни разговор первым!</p>
            </div>
          ) : (
            messages.map((msg) => {
              const isOwn = msg.user_id === profile?.id;
              const isPending = msg.id.startsWith('temp-');
              const justSent = msg.id === lastSentId;
              return (
                <div
                  key={msg.id}
                  className={`flex gap-2 ${isOwn ? 'flex-row-reverse' : 'flex-row'}`}
                >
                  <div className="shrink-0">
                    {msg.avatar_url ? (
                      <img
                        src={msg.avatar_url}
                        alt=""
                        className="w-8 h-8 rounded-full object-cover"
                      />
                    ) : (
                      <div className="w-8 h-8 rounded-full bg-gradient-to-br from-theme-primary to-theme-accent flex items-center justify-center text-white text-xs font-bold">
                        {msg.username?.[0]?.toUpperCase()}
                      </div>
                    )}
                  </div>
                  <div className={`max-w-[70%] ${isOwn ? 'items-end' : 'items-start'} flex flex-col`}>
                    <div className="flex items-baseline gap-2 mb-0.5">
                      <span className="text-xs font-medium text-theme-text">{msg.username}</span>
                      <span className="text-[10px] text-theme-muted">{formatTime(msg.created_at)}</span>
                    </div>
                    <div
                      className={`px-3 py-2 rounded-2xl text-sm ${
                        isOwn
                          ? 'bg-gradient-to-br from-theme-primary to-theme-accent text-white rounded-tr-sm'
                          : 'bg-theme-surface2 text-theme-text rounded-tl-sm'
                      } ${isPending ? 'opacity-60' : ''}`}
                    >
                      <p className="break-words">{msg.content}</p>
                      {isOwn && !isPending && justSent && (
                        <div className="flex items-center justify-end gap-1 mt-0.5">
                          <Check className="w-3 h-3 text-white/70" />
                          <span className="text-[10px] text-white/70">Отправлено</span>
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              );
            })
          )}
          <div ref={messagesEndRef} />
        </div>

        {/* Error banner */}
        {error && (
          <div className="px-4 py-2 bg-theme-danger/10 border-t border-theme-danger/20 flex items-center gap-2 text-theme-danger text-xs">
            <AlertCircle className="w-4 h-4 shrink-0" />
            <span>{error}</span>
            <button
              onClick={() => setError(null)}
              className="ml-auto text-theme-danger/70 hover:text-theme-danger"
            >
              ✕
            </button>
          </div>
        )}

        {/* Input */}
        <div className="border-t border-theme-border p-3 flex gap-2">
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && !sending && sendMessage()}
            placeholder="Введите сообщение..."
            className="flex-1 px-4 py-2.5 bg-theme-surface2 border border-theme-border rounded-xl text-theme-text text-sm focus:outline-none focus:border-theme-primary focus:ring-1 focus:ring-theme-primary transition-colors"
          />
          <button
            onClick={sendMessage}
            disabled={sending || !input.trim()}
            className="px-4 py-2.5 bg-theme-primary text-white rounded-xl text-sm font-medium hover:bg-theme-primary-hover transition-colors disabled:opacity-50 flex items-center gap-2"
          >
            {sending ? <Loader2 className="w-4 h-4 animate-spin" /> : <Send className="w-4 h-4" />}
          </button>
        </div>
      </div>
    </div>
  );
}
