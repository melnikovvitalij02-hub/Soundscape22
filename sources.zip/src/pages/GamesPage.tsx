import { useState, useRef, useEffect, useCallback } from 'react';
import { useAuth } from '@/context/AuthContext';
import { supabase } from '@/lib/supabase';
import { Gamepad2, Trophy, Play, ArrowLeft } from 'lucide-react';
import PacManGame from '@/pages/games/PacManGame';
import SpaceShooterGame from '@/pages/games/SpaceShooterGame';
import SpaceInvadersGame from '@/pages/games/SpaceInvadersGame';

type GameId = 'snake' | 'clicker' | 'pacman' | 'shooter' | 'invaders' | null;

export default function GamesPage() {
  const { profile, addXp, addCoins, isGuest } = useAuth();
  const [activeGame, setActiveGame] = useState<GameId>(null);
  const [highScores, setHighScores] = useState<Record<string, number>>({});

  const fetchScores = useCallback(async () => {
    if (isGuest) {
      const saved = localStorage.getItem('soundscape-guest-scores');
      if (saved) setHighScores(JSON.parse(saved));
      return;
    }
    if (!profile) return;
    const { data } = await supabase
      .from('game_scores')
      .select('game_name, score')
      .eq('user_id', profile.id)
      .order('score', { ascending: false });
    if (data) {
      const scores: Record<string, number> = {};
      data.forEach((s) => {
        if (!scores[s.game_name] || scores[s.game_name] < s.score) {
          scores[s.game_name] = s.score;
        }
      });
      setHighScores(scores);
    }
  }, [profile, isGuest]);

  useEffect(() => {
    fetchScores();
  }, [fetchScores]);

  const recordScore = async (gameName: string, score: number) => {
    if (isGuest) {
      setHighScores((prev) => {
        const next = { ...prev, [gameName]: Math.max(prev[gameName] || 0, score) };
        localStorage.setItem('soundscape-guest-scores', JSON.stringify(next));
        return next;
      });
      return;
    }
    if (!profile) return;
    await supabase.from('game_scores').insert({
      user_id: profile.id,
      game_name: gameName,
      score,
    });
    await addXp(Math.floor(score / 10));
    await addCoins(Math.floor(score / 5));
    fetchScores();
  };

  if (activeGame === 'snake') {
    return <SnakeGame onExit={() => setActiveGame(null)} onScore={recordScore} />;
  }
  if (activeGame === 'clicker') {
    return <StarClicker onExit={() => setActiveGame(null)} onScore={recordScore} />;
  }
  if (activeGame === 'pacman') {
    return <PacManGame onExit={() => setActiveGame(null)} onScore={recordScore} />;
  }
  if (activeGame === 'shooter') {
    return <SpaceShooterGame onExit={() => setActiveGame(null)} onScore={recordScore} />;
  }
  if (activeGame === 'invaders') {
    return <SpaceInvadersGame onExit={() => setActiveGame(null)} onScore={recordScore} />;
  }

  const games = [
    {
      id: 'snake' as const,
      title: 'Змейка',
      desc: 'Классическая игра «Змейка». Ешь еду, расти, не врезайся в стены.',
      icon: '🐍',
      color: 'from-theme-success to-theme-accent',
      score: highScores['snake'] || 0,
    },
    {
      id: 'clicker' as const,
      title: 'Звёздный Кликер',
      desc: 'Кликай по звёздам так быстро, как сможешь, за 30 секунд!',
      icon: '⭐',
      color: 'from-theme-warning to-theme-primary',
      score: highScores['clicker'] || 0,
    },
    {
      id: 'pacman' as const,
      title: 'Pac-Man',
      desc: 'Классический Pac-Man. Собирай точки, ешь призраков, выживай!',
      icon: '🟡',
      color: 'from-theme-warning to-theme-primary',
      score: highScores['pacman'] || 0,
    },
    {
      id: 'shooter' as const,
      title: 'Space Shooter',
      desc: 'Стреляй по вражеским кораблям, не дай им пролететь мимо!',
      icon: '🚀',
      color: 'from-theme-primary to-theme-accent',
      score: highScores['shooter'] || 0,
    },
    {
      id: 'invaders' as const,
      title: 'Space Invaders',
      desc: 'Уничтожь всех пришельцев, пока они не добрались до тебя!',
      icon: '👾',
      color: 'from-theme-accent to-theme-primary',
      score: highScores['invaders'] || 0,
    },
  ];

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-theme-text flex items-center gap-2">
          <Gamepad2 className="w-6 h-6 text-theme-accent" />
          Аркадные Игры
        </h1>
        <p className="text-theme-muted text-sm mt-1">
          Играй и зарабатывай XP и монеты
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {games.map((game) => (
          <div
            key={game.id}
            className="glass-surface bg-theme-surface/50 border border-theme-border rounded-2xl p-6 hover:border-theme-border transition-all"
          >
            <div className={`inline-flex items-center justify-center w-14 h-14 rounded-2xl bg-gradient-to-br ${game.color} mb-4 text-2xl`}>
              {game.icon}
            </div>
            <h3 className="text-theme-text font-semibold text-base mb-1">{game.title}</h3>
            <p className="text-theme-muted text-xs mb-4">{game.desc}</p>
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-1.5 text-xs text-theme-warning">
                <Trophy className="w-4 h-4" />
                Рекорд: {game.score}
              </div>
              <button
                onClick={() => setActiveGame(game.id)}
                className="px-4 py-2 bg-theme-accent text-white rounded-lg text-sm font-medium hover:bg-theme-accent-hover transition-colors flex items-center gap-2"
              >
                <Play className="w-4 h-4" /> Играть
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

// ===== Snake Game =====
function SnakeGame({ onExit, onScore }: { onExit: () => void; onScore: (name: string, score: number) => void }) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [score, setScore] = useState(0);
  const [gameOver, setGameOver] = useState(false);
  const [running, setRunning] = useState(false);
  const snakeRef = useRef<{ x: number; y: number }[]>([{ x: 10, y: 10 }]);
  const foodRef = useRef<{ x: number; y: number }>({ x: 15, y: 10 });
  const dirRef = useRef<{ x: number; y: number }>({ x: 1, y: 0 });
  const nextDirRef = useRef<{ x: number; y: number }>({ x: 1, y: 0 });
  const loopRef = useRef<number | null>(null);
  const touchStartRef = useRef<{ x: number; y: number } | null>(null);

  const GRID = 20;
  const CELL = 20;

  const draw = useCallback(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    ctx.fillStyle = '#0f172a';
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    ctx.strokeStyle = '#1e293b';
    for (let i = 0; i <= GRID; i++) {
      ctx.beginPath();
      ctx.moveTo(i * CELL, 0);
      ctx.lineTo(i * CELL, GRID * CELL);
      ctx.stroke();
      ctx.beginPath();
      ctx.moveTo(0, i * CELL);
      ctx.lineTo(GRID * CELL, i * CELL);
      ctx.stroke();
    }

    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';

    const food = foodRef.current;
    ctx.font = '16px serif';
    ctx.fillText('🍎', food.x * CELL + CELL / 2, food.y * CELL + CELL / 2);

    const snake = snakeRef.current;
    snake.forEach((seg, i) => {
      const isHead = i === 0;
      ctx.font = isHead ? '16px serif' : '14px serif';
      ctx.fillText(isHead ? '🐍' : '🟢', seg.x * CELL + CELL / 2, seg.y * CELL + CELL / 2);
    });
  }, []);

  const tick = useCallback(() => {
    dirRef.current = nextDirRef.current;
    const snake = snakeRef.current;
    const head = { x: snake[0].x + dirRef.current.x, y: snake[0].y + dirRef.current.y };

    if (
      head.x < 0 || head.x >= GRID || head.y < 0 || head.y >= GRID ||
      snake.some((s) => s.x === head.x && s.y === head.y)
    ) {
      setGameOver(true);
      setRunning(false);
      if (loopRef.current) clearInterval(loopRef.current);
      return;
    }

    snake.unshift(head);

    if (head.x === foodRef.current.x && head.y === foodRef.current.y) {
      setScore((s) => s + 10);
      foodRef.current = {
        x: Math.floor(Math.random() * GRID),
        y: Math.floor(Math.random() * GRID),
      };
    } else {
      snake.pop();
    }

    draw();
  }, [draw]);

  const handleTouchStart = (e: React.TouchEvent) => {
    touchStartRef.current = { x: e.touches[0].clientX, y: e.touches[0].clientY };
  };
  const handleTouchEnd = (e: React.TouchEvent) => {
    if (!touchStartRef.current || !running) return;
    const dx = e.changedTouches[0].clientX - touchStartRef.current.x;
    const dy = e.changedTouches[0].clientY - touchStartRef.current.y;
    const dir = dirRef.current;
    if (Math.abs(dx) > Math.abs(dy)) {
      if (dir.x === 0) nextDirRef.current = { x: dx > 0 ? 1 : -1, y: 0 };
    } else {
      if (dir.y === 0) nextDirRef.current = { x: 0, y: dy > 0 ? 1 : -1 };
    }
    touchStartRef.current = null;
  };

  const handlePointerDown = (e: React.PointerEvent) => {
    touchStartRef.current = { x: e.clientX, y: e.clientY };
  };
  const handlePointerUp = (e: React.PointerEvent) => {
    if (!touchStartRef.current || !running) return;
    const dx = e.clientX - touchStartRef.current.x;
    const dy = e.clientY - touchStartRef.current.y;
    if (Math.abs(dx) < 5 && Math.abs(dy) < 5) {
      touchStartRef.current = null;
      return;
    }
    const dir = dirRef.current;
    if (Math.abs(dx) > Math.abs(dy)) {
      if (dir.x === 0) nextDirRef.current = { x: dx > 0 ? 1 : -1, y: 0 };
    } else {
      if (dir.y === 0) nextDirRef.current = { x: 0, y: dy > 0 ? 1 : -1 };
    }
    touchStartRef.current = null;
  };

  const start = () => {
    snakeRef.current = [{ x: 10, y: 10 }];
    foodRef.current = { x: 15, y: 10 };
    dirRef.current = { x: 1, y: 0 };
    nextDirRef.current = { x: 1, y: 0 };
    setScore(0);
    setGameOver(false);
    setRunning(true);
    draw();
    if (loopRef.current) clearInterval(loopRef.current);
    loopRef.current = window.setInterval(tick, 120);
  };

  useEffect(() => {
    const handleKey = (e: KeyboardEvent) => {
      const dir = dirRef.current;
      switch (e.key) {
        case 'ArrowUp':
        case 'w':
          if (dir.y === 0) nextDirRef.current = { x: 0, y: -1 };
          break;
        case 'ArrowDown':
        case 's':
          if (dir.y === 0) nextDirRef.current = { x: 0, y: 1 };
          break;
        case 'ArrowLeft':
        case 'a':
          if (dir.x === 0) nextDirRef.current = { x: -1, y: 0 };
          break;
        case 'ArrowRight':
        case 'd':
          if (dir.x === 0) nextDirRef.current = { x: 1, y: 0 };
          break;
      }
    };
    window.addEventListener('keydown', handleKey);
    return () => {
      window.removeEventListener('keydown', handleKey);
      if (loopRef.current) clearInterval(loopRef.current);
    };
  }, []);

  useEffect(() => {
    if (gameOver) onScore('snake', score);
  }, [gameOver, score, onScore]);

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <button
          onClick={onExit}
          className="flex items-center gap-2 text-theme-muted hover:text-theme-text text-sm transition-colors"
        >
          <ArrowLeft className="w-4 h-4" /> Назад к играм
        </button>
        <div className="text-theme-text text-sm">
          Очки: <span className="font-bold text-theme-success">{score}</span>
        </div>
      </div>

      <div className="flex flex-col items-center gap-4">
        <canvas
          ref={canvasRef}
          width={GRID * CELL}
          height={GRID * CELL}
          className="rounded-xl border border-theme-border bg-theme-bg max-w-full h-auto touch-none"
          style={{ touchAction: 'none' }}
          onContextMenu={(e) => e.preventDefault()}
          onTouchStart={handleTouchStart}
          onTouchEnd={handleTouchEnd}
          onPointerDown={handlePointerDown}
          onPointerUp={handlePointerUp}
        />
        {gameOver && (
          <div className="text-center">
            <p className="text-theme-danger font-medium text-sm mb-2">Игра окончена! Финальный счёт: {score}</p>
          </div>
        )}
        <button
          onClick={start}
          className="px-6 py-2.5 bg-theme-success text-white rounded-xl text-sm font-medium hover:bg-theme-success/90 transition-colors flex items-center gap-2"
        >
          <Play className="w-4 h-4" /> {gameOver ? 'Играть снова' : 'Начать игру'}
        </button>

        <p className="text-xs text-theme-muted">Управление: водите пальцем по экрану (или мышью на ПК)</p>
      </div>
    </div>
  );
}

// ===== Star Clicker =====
function StarClicker({ onExit, onScore }: { onExit: () => void; onScore: (name: string, score: number) => void }) {
  const [score, setScore] = useState(0);
  const [timeLeft, setTimeLeft] = useState(30);
  const [playing, setPlaying] = useState(false);
  const [stars, setStars] = useState<{ id: number; x: number; y: number }[]>([]);
  const timerRef = useRef<number | null>(null);
  const starIdRef = useRef(0);

  const startGame = () => {
    setScore(0);
    setTimeLeft(30);
    setPlaying(true);
    setStars([]);
    if (timerRef.current) clearInterval(timerRef.current);
    timerRef.current = window.setInterval(() => {
      setTimeLeft((t) => {
        if (t <= 1) {
          setPlaying(false);
          if (timerRef.current) clearInterval(timerRef.current);
          return 0;
        }
        return t - 1;
      });
    }, 1000);
  };

  useEffect(() => {
    if (!playing) return;
    const spawnInterval = setInterval(() => {
      const newStar = {
        id: starIdRef.current++,
        x: Math.random() * 80 + 5,
        y: Math.random() * 70 + 5,
      };
      setStars((prev) => [...prev, newStar]);
      setTimeout(() => {
        setStars((prev) => prev.filter((s) => s.id !== newStar.id));
      }, 2000);
    }, 600);
    return () => clearInterval(spawnInterval);
  }, [playing]);

  useEffect(() => {
    if (!playing && timeLeft === 0) {
      onScore('clicker', score);
    }
  }, [playing, timeLeft, score, onScore]);

  useEffect(() => {
    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, []);

  const clickStar = (id: number) => {
    setStars((prev) => prev.filter((s) => s.id !== id));
    setScore((s) => s + 1);
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <button
          onClick={onExit}
          className="flex items-center gap-2 text-theme-muted hover:text-theme-text text-sm transition-colors"
        >
          <ArrowLeft className="w-4 h-4" /> Назад к играм
        </button>
        <div className="flex items-center gap-4 text-theme-text text-sm">
          <span>Очки: <span className="font-bold text-theme-warning">{score}</span></span>
          <span>Время: <span className="font-bold text-theme-danger">{timeLeft}s</span></span>
        </div>
      </div>

      <div className="glass-surface bg-theme-surface/50 border border-theme-border rounded-2xl p-6">
        {!playing && timeLeft === 0 && (
          <div className="text-center mb-4">
            <Trophy className="w-10 h-10 text-theme-warning mx-auto mb-2" />
            <p className="text-theme-text font-medium">Игра окончена! Ты собрал {score} звёзд!</p>
          </div>
        )}
        <div className="relative w-full h-80 bg-theme-bg/50 rounded-xl overflow-hidden">
          {playing ? (
            stars.map((star) => (
              <button
                key={star.id}
                onClick={() => clickStar(star.id)}
                className="absolute hover:scale-125 transition-transform flex items-center justify-center"
                style={{ left: `${star.x}%`, top: `${star.y}%`, minWidth: '44px', minHeight: '44px' }}
              >
                <span style={{ fontSize: '2rem', lineHeight: 1 }}>⭐</span>
              </button>
            ))
          ) : (
            <div className="absolute inset-0 flex items-center justify-center">
              <button
                onClick={startGame}
                className="px-6 py-2.5 bg-theme-warning text-white rounded-xl text-sm font-medium hover:bg-theme-warning/90 transition-colors flex items-center gap-2"
              >
                <Play className="w-4 h-4" /> Начать игру
              </button>
            </div>
          )}
        </div>
        <p className="text-xs text-theme-muted text-center mt-3">
          Кликай по звёздам так быстро, как сможешь, за 30 секунд!
        </p>
      </div>
    </div>
  );
}
