import { useState, useRef, useEffect, useCallback } from 'react';
import { useAuth } from '@/context/AuthContext';
import { Mic, Square, Play, Pause, Music2, Activity, Sparkles, PenLine, Copy, ArrowRight, Loader2 } from 'lucide-react';
import type { Page } from '@/components/Sidebar';

const GENRES = ['Хип-Хоп', 'Трэп', 'House', 'Техно', 'Lo-Fi', 'Драм-н-Бейс', 'Дабстеп', 'Рэгги', 'Рок', 'Поп', 'R&B', 'Фонк', 'Эмбиент', 'Синтвейв'];
const INSTRUMENTS = ['Кик', 'Снейр', 'Хай-Хэт', 'Бас', 'Синт', 'Пианино', 'Лид', 'Перкуссия'];

const NOTE_NAMES = ['C', 'C#', 'D', 'D#', 'E', 'F', 'F#', 'G', 'G#', 'A', 'A#', 'B'];

function freqToNote(freq: number): string {
  const semitones = Math.round(12 * Math.log2(freq / 440));
  const noteIndex = ((semitones + 9) % 12 + 12) % 12;
  const octave = Math.floor((semitones + 9) / 12) + 4;
  return `${NOTE_NAMES[noteIndex]}${octave}`;
}

function detectPitch(buffer: Float32Array, sampleRate: number): number | null {
  const SIZE = 2048;
  let bestOffset = -1;
  let bestCorrelation = 0;
  let rms = 0;

  for (let i = 0; i < SIZE; i++) {
    const val = buffer[i];
    rms += val * val;
  }
  rms = Math.sqrt(rms / SIZE);
  if (rms < 0.01) return null;

  for (let offset = 32; offset < 1000; offset++) {
    let correlation = 0;
    for (let i = 0; i < SIZE; i++) {
      correlation += Math.abs(buffer[i] - buffer[i + offset]);
    }
    correlation = 1 - correlation / SIZE;
    if (correlation > bestCorrelation) {
      bestCorrelation = correlation;
      bestOffset = offset;
    }
  }

  if (bestCorrelation > 0.9 && bestOffset > 0) {
    return sampleRate / bestOffset;
  }
  return null;
}

const LYRIC_THEMES = ['Любовь', 'Город', 'Ночь', 'Свобода', 'Дружба', 'Мечты', 'Одиночество', 'Путешествие'];
const LYRIC_STRUCTURES = ['Куплет + Припев', 'Куплет + Припев + Бридж', 'Только Припев', '2 Куплета + Припев'];

const RHYME_MAP: Record<string, string[]> = {
  'а': ['судьба', 'жизнь', 'игра', 'жара', 'мечта', 'сила', 'крыла'],
  'е': ['свет', 'след', 'лет', 'ответ', 'рассвет', 'секрет', 'портрет'],
  'о': ['легко', 'далеко', 'высоко', 'глубоко', 'одинок', 'поток', 'рок'],
  'и': ['внутри', 'смотри', 'фонари', 'до зари', 'ночью', 'лучи'],
  'у': ['бегу', 'снегу', 'смогу', 'помогу', 'на бегу', 'берегу'],
  'я': ['огня', 'меня', 'дня', 'тень', 'огня', 'звонкая'],
};

function pickRhyme(word: string): string {
  const lastChar = word.toLowerCase().slice(-1);
  const rhymes = RHYME_MAP[lastChar] || RHYME_MAP['а'];
  return rhymes[Math.floor(Math.random() * rhymes.length)];
}

function buildLyrics(theme: string, genre: string, structure: string): string {
  const themeLower = theme.toLowerCase();
  const lines: string[] = [];

  const verseLines = [
    `В ${themeLower} я вижу смысл, что не обмануть`,
    `Каждый день как кадр, я не хочу свернуть`,
    `Этот город спит, но внутри горит огонь`,
    `Мой путь — это мой ритм, мой персональный сон`,
    `Где-то там вдали мерцают фонари`,
    `Я иду вперёд, не нужно мне пути`,
    `Время — это песня, что поёт в груди`,
    `Сердце бьётся в такт, не нужно мне ${pickRhyme('такт')}`,
  ];

  const chorusLines = [
    `Это ${themeLower}, это моя ${pickRhyme('жизнь')}`,
    `Под битом этим я лечу, я не догнать`,
    `Звук внутри меня, и он не замолчит`,
    `С ${themeLower} в сердце я не одинок`,
    `Музыка — мой дом, мой вечный поток`,
    `Под этим ритмом мы летим с тобой`,
    `Это больше, чем просто ${pickRhyme('слово')}`,
  ];

  const bridgeLines = [
    `А когда темнеет — я слышу голос твой`,
    `Каждый удар сердца — это бит простой`,
    `Где-то на грани ночи и дня`,
    `Я нахожу то, что зовёт меня`,
  ];

  const pickN = (arr: string[], n: number) => {
    const shuffled = [...arr].sort(() => Math.random() - 0.5);
    return shuffled.slice(0, n);
  };

  if (structure === 'Только Припев') {
    lines.push('[Припев]');
    lines.push(...pickN(chorusLines, 4));
  } else if (structure === 'Куплет + Припев') {
    lines.push('[Куплет 1]');
    lines.push(...pickN(verseLines, 4));
    lines.push('');
    lines.push('[Припев]');
    lines.push(...pickN(chorusLines, 4));
  } else if (structure === 'Куплет + Припев + Бридж') {
    lines.push('[Куплет 1]');
    lines.push(...pickN(verseLines, 4));
    lines.push('');
    lines.push('[Припев]');
    lines.push(...pickN(chorusLines, 4));
    lines.push('');
    lines.push('[Бридж]');
    lines.push(...pickN(bridgeLines, 4));
    lines.push('');
    lines.push('[Припев]');
    lines.push(...pickN(chorusLines, 4));
  } else {
    lines.push('[Куплет 1]');
    lines.push(...pickN(verseLines, 4));
    lines.push('');
    lines.push('[Куплет 2]');
    lines.push(...pickN(verseLines, 4));
    lines.push('');
    lines.push('[Припев]');
    lines.push(...pickN(chorusLines, 4));
  }

  return lines.join('\n');
}

export default function AIStudioPage({ setPage }: { setPage?: (p: Page) => void }) {
  const { addXp } = useAuth();
  const [isRecording, setIsRecording] = useState(false);
  const [isPlaying, setIsPlaying] = useState(false);
  const [audioUrl, setAudioUrl] = useState<string | null>(null);
  const [detectedNotes, setDetectedNotes] = useState<string[]>([]);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [genre, setGenre] = useState('Хип-Хоп');
  const [selectedInstruments, setSelectedInstruments] = useState<string[]>(['Кик', 'Снейр', 'Хай-Хэт']);
  const [generatedBeat, setGeneratedBeat] = useState<boolean[]>([]);
  const [recordingTime, setRecordingTime] = useState(0);
  const [lyricTheme, setLyricTheme] = useState('Любовь');
  const [lyricStructure, setLyricStructure] = useState('Куплет + Припев');
  const [generatedLyrics, setGeneratedLyrics] = useState('');
  const [generatingLyrics, setGeneratingLyrics] = useState(false);

  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const audioChunksRef = useRef<Blob[]>([]);
  const audioStreamRef = useRef<MediaStream | null>(null);
  const audioCtxRef = useRef<AudioContext | null>(null);
  const analyserRef = useRef<AnalyserNode | null>(null);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const animationRef = useRef<number | null>(null);
  const recordingTimerRef = useRef<number | null>(null);

  const drawVisualizer = useCallback(() => {
    const canvas = canvasRef.current;
    const analyser = analyserRef.current;
    if (!canvas || !analyser) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const width = canvas.width;
    const height = canvas.height;
    const dataArray = new Uint8Array(analyser.frequencyBinCount);

    const draw = () => {
      animationRef.current = requestAnimationFrame(draw);
      analyser.getByteFrequencyData(dataArray);

      ctx.fillStyle = 'rgba(15, 23, 42, 0.3)';
      ctx.fillRect(0, 0, width, height);

      const barCount = 64;
      const barWidth = width / barCount;
      const gradient = ctx.createLinearGradient(0, 0, 0, height);
      gradient.addColorStop(0, '#06b6d4');
      gradient.addColorStop(0.5, '#10b981');
      gradient.addColorStop(1, '#0ea5e9');

      for (let i = 0; i < barCount; i++) {
        const value = dataArray[i * 2] / 255;
        const barHeight = value * height * 0.8;
        ctx.fillStyle = gradient;
        ctx.fillRect(i * barWidth + 1, height - barHeight, barWidth - 2, barHeight);
      }
    };
    draw();
  }, []);

  const startRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      audioStreamRef.current = stream;

      const audioCtx = new AudioContext();
      audioCtxRef.current = audioCtx;
      const source = audioCtx.createMediaStreamSource(stream);
      const analyser = audioCtx.createAnalyser();
      analyser.fftSize = 256;
      analyserRef.current = analyser;
      source.connect(analyser);

      const recorder = new MediaRecorder(stream);
      mediaRecorderRef.current = recorder;
      audioChunksRef.current = [];

      recorder.ondataavailable = (e) => {
        if (e.data.size > 0) audioChunksRef.current.push(e.data);
      };

      recorder.onstop = async () => {
        const blob = new Blob(audioChunksRef.current, { type: 'audio/webm' });
        const url = URL.createObjectURL(blob);
        setAudioUrl(url);
        await analyzeRecording(blob);
      };

      recorder.start();
      setIsRecording(true);
      setRecordingTime(0);
      recordingTimerRef.current = window.setInterval(() => {
        setRecordingTime((t) => t + 1);
      }, 1000);
      drawVisualizer();
    } catch {
      alert('Не удалось получить доступ к микрофону. Разрешите доступ к микрофону в настройках браузера.');
    }
  };

  const stopRecording = () => {
    if (mediaRecorderRef.current && mediaRecorderRef.current.state !== 'inactive') {
      mediaRecorderRef.current.stop();
    }
    if (audioStreamRef.current) {
      audioStreamRef.current.getTracks().forEach((t) => t.stop());
    }
    if (animationRef.current) {
      cancelAnimationFrame(animationRef.current);
    }
    if (recordingTimerRef.current) {
      clearInterval(recordingTimerRef.current);
    }
    setIsRecording(false);
  };

  const analyzeRecording = async (blob: Blob) => {
    setIsAnalyzing(true);
    try {
      const arrayBuffer = await blob.arrayBuffer();
      const audioCtx = new AudioContext();
      const audioBuffer = await audioCtx.decodeAudioData(arrayBuffer);
      const channelData = audioBuffer.getChannelData(0);
      const sampleRate = audioBuffer.sampleRate;

      const notes: string[] = [];
      const step = 512;
      for (let i = 0; i < channelData.length - 2048; i += step) {
        const chunk = channelData.slice(i, i + 2048);
        const freq = detectPitch(chunk, sampleRate);
        if (freq && freq > 50 && freq < 1000) {
          const note = freqToNote(freq);
          if (notes.length === 0 || notes[notes.length - 1] !== note) {
            notes.push(note);
          }
        }
      }

      setDetectedNotes(notes.slice(0, 30));
      audioCtx.close();
    } catch {
      setDetectedNotes([]);
    }
    setIsAnalyzing(false);
  };

  const generateBeat = () => {
    const pattern = Array(16).fill(false);
    const noteCount = Math.max(detectedNotes.length, 4);
    for (let i = 0; i < 16; i++) {
      if (selectedInstruments.includes('Кик') && i % 4 === 0) pattern[i] = true;
      if (selectedInstruments.includes('Снейр') && (i === 4 || i === 12)) pattern[i] = true;
      if (selectedInstruments.includes('Хай-Хэт') && i % 2 === 0) pattern[i] = true;
      if (selectedInstruments.includes('Бас') && i % noteCount === 0) pattern[i] = true;
    }
    setGeneratedBeat(pattern);
    addXp(30);
  };

  const toggleInstrument = (inst: string) => {
    setSelectedInstruments((prev) =>
      prev.includes(inst) ? prev.filter((i) => i !== inst) : [...prev, inst]
    );
  };

  useEffect(() => {
    return () => {
      if (animationRef.current) cancelAnimationFrame(animationRef.current);
      if (recordingTimerRef.current) clearInterval(recordingTimerRef.current);
      if (audioStreamRef.current) {
        audioStreamRef.current.getTracks().forEach((t) => t.stop());
      }
    };
  }, []);

  const formatTime = (s: number) => `${Math.floor(s / 60)}:${(s % 60).toString().padStart(2, '0')}`;

  const generateLyrics = () => {
    setGeneratingLyrics(true);
    setTimeout(() => {
      const lyrics = buildLyrics(lyricTheme, genre, lyricStructure);
      setGeneratedLyrics(lyrics);
      setGeneratingLyrics(false);
      addXp(15);
    }, 600);
  };

  const copyLyrics = () => {
    navigator.clipboard.writeText(generatedLyrics);
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-theme-text flex items-center gap-2">
          <Mic className="w-6 h-6 text-theme-accent" />
          ИИ Студия
        </h1>
        <p className="text-theme-muted text-sm mt-1">
          Запись аудио, визуализация волн, распознавание нот и генерация битов
        </p>
      </div>

      {/* Recording section */}
      <div className="bg-theme-surface/50 border border-theme-border rounded-2xl p-6 glass-surface">
        <div className="flex flex-col items-center gap-4">
          <button
            onClick={isRecording ? stopRecording : startRecording}
            className={`relative w-24 h-24 rounded-full flex items-center justify-center transition-all ${
              isRecording
                ? 'bg-theme-danger hover:bg-theme-danger/90 shadow-lg'
                : 'bg-gradient-to-br from-theme-primary to-theme-accent hover:scale-105 shadow-lg'
            }`}
          >
            {isRecording ? (
              <Square className="w-8 h-8 text-white" fill="white" />
            ) : (
              <Mic className="w-10 h-10 text-white" />
            )}
            {isRecording && (
              <span className="absolute -top-1 -right-1 w-6 h-6 bg-theme-danger rounded-full border-2 border-theme-surface animate-pulse" />
            )}
          </button>

          <div className="text-center">
            <p className="text-theme-text font-medium text-sm">
              {isRecording ? 'Запись...' : isAnalyzing ? 'Анализ...' : 'Готов к записи'}
            </p>
            {isRecording && (
              <p className="text-theme-danger text-2xl font-mono mt-1">{formatTime(recordingTime)}</p>
            )}
          </div>

          {/* Visualizer */}
          <div className="w-full">
            <canvas
              ref={canvasRef}
              width={800}
              height={120}
              className="w-full h-30 rounded-xl bg-theme-bg border border-theme-border"
            />
          </div>

          {/* Playback */}
          {audioUrl && (
            <div className="w-full flex items-center gap-3 p-3 bg-theme-surface2 rounded-xl">
              <button
                onClick={() => setIsPlaying(!isPlaying)}
                className="p-2 bg-theme-primary text-white rounded-lg hover:bg-theme-primary-hover transition-colors"
              >
                {isPlaying ? <Pause className="w-5 h-5" /> : <Play className="w-5 h-5" />}
              </button>
              <audio
                src={audioUrl}
                onPlay={() => setIsPlaying(true)}
                onPause={() => setIsPlaying(false)}
                onEnded={() => setIsPlaying(false)}
                controls
                className="flex-1 h-10"
              />
            </div>
          )}
        </div>
      </div>

      {/* Pitch detection results */}
      <div className="bg-theme-surface/50 border border-theme-border rounded-2xl p-6 glass-surface">
        <h3 className="text-sm font-medium text-theme-text mb-3 flex items-center gap-2">
          <Activity className="w-4 h-4 text-theme-primary" />
          Распознанные ноты
        </h3>
        {isAnalyzing ? (
          <p className="text-theme-muted text-sm">Анализ аудио...</p>
        ) : detectedNotes.length > 0 ? (
          <div className="flex flex-wrap gap-2">
            {detectedNotes.map((note, i) => (
              <span
                key={i}
                className="px-3 py-1.5 bg-theme-surface2 border border-theme-primary-border text-theme-primary-text rounded-lg text-sm font-mono"
              >
                {note}
              </span>
            ))}
          </div>
        ) : (
          <p className="text-theme-muted text-sm">
            Запишите аудио для распознавания нот. Ноты появятся здесь после записи.
          </p>
        )}
      </div>

      {/* Beat generator */}
      <div className="bg-theme-surface/50 border border-theme-border rounded-2xl p-6 glass-surface">
        <h3 className="text-sm font-medium text-theme-text mb-4 flex items-center gap-2">
          <Sparkles className="w-4 h-4 text-theme-accent" />
          Автогенерация бита
        </h3>

        <div className="space-y-4">
          <div>
            <label className="text-xs text-theme-muted uppercase tracking-wider mb-2 block">Жанр</label>
            <div className="flex flex-wrap gap-2">
              {GENRES.map((g) => (
                <button
                  key={g}
                  onClick={() => setGenre(g)}
                  className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${
                    genre === g
                      ? 'bg-theme-accent text-white'
                      : 'bg-theme-surface2 text-theme-muted hover:text-theme-text'
                  }`}
                >
                  {g}
                </button>
              ))}
            </div>
          </div>

          <div>
            <label className="text-xs text-theme-muted uppercase tracking-wider mb-2 block">Инструменты</label>
            <div className="flex flex-wrap gap-2">
              {INSTRUMENTS.map((inst) => (
                <button
                  key={inst}
                  onClick={() => toggleInstrument(inst)}
                  className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-all flex items-center gap-1.5 ${
                    selectedInstruments.includes(inst)
                      ? 'bg-theme-primary text-white'
                      : 'bg-theme-surface2 text-theme-muted hover:text-theme-text'
                  }`}
                >
                  <Music2 className="w-3 h-3" />
                  {inst}
                </button>
              ))}
            </div>
          </div>

          <button
            onClick={generateBeat}
            disabled={detectedNotes.length === 0}
            className="px-5 py-2.5 bg-gradient-to-r from-theme-accent to-theme-primary text-white rounded-xl text-sm font-medium hover:shadow-lg transition-all disabled:opacity-50 disabled:cursor-not-allowed"
          >
            Сгенерировать бит из записи
          </button>

          {generatedBeat.length > 0 && (
            <div className="mt-4">
              <p className="text-xs text-theme-muted mb-2">Сгенерированный паттерн ({genre}):</p>
              <div className="flex gap-1 flex-wrap">
                {generatedBeat.map((active, i) => (
                  <div
                    key={i}
                    className={`w-7 h-7 rounded-md ${
                      active
                        ? 'bg-gradient-to-br from-theme-accent to-theme-primary'
                        : 'bg-theme-surface2'
                    }`}
                  />
                ))}
              </div>
              {setPage && (
                <button
                  onClick={() => setPage('beat')}
                  className="mt-3 px-4 py-2 bg-theme-primary text-white rounded-lg text-xs font-medium hover:bg-theme-primary-hover transition-colors flex items-center gap-2"
                >
                  Перейти к Бит-Секвенсору <ArrowRight className="w-3.5 h-3.5" />
                </button>
              )}
            </div>
          )}
        </div>
      </div>

      {/* Lyric generator */}
      <div className="bg-theme-surface/50 border border-theme-border rounded-2xl p-6 glass-surface">
        <h3 className="text-sm font-medium text-theme-text mb-4 flex items-center gap-2">
          <PenLine className="w-4 h-4 text-theme-warning" />
          Генератор текста песен
        </h3>

        <div className="space-y-4">
          <div>
            <label className="text-xs text-theme-muted uppercase tracking-wider mb-2 block">Тема песни</label>
            <div className="flex flex-wrap gap-2">
              {LYRIC_THEMES.map((t) => (
                <button
                  key={t}
                  onClick={() => setLyricTheme(t)}
                  className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${
                    lyricTheme === t
                      ? 'bg-theme-warning text-white'
                      : 'bg-theme-surface2 text-theme-muted hover:text-theme-text'
                  }`}
                >
                  {t}
                </button>
              ))}
            </div>
          </div>

          <div>
            <label className="text-xs text-theme-muted uppercase tracking-wider mb-2 block">Структура</label>
            <div className="flex flex-wrap gap-2">
              {LYRIC_STRUCTURES.map((s) => (
                <button
                  key={s}
                  onClick={() => setLyricStructure(s)}
                  className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${
                    lyricStructure === s
                      ? 'bg-theme-accent text-white'
                      : 'bg-theme-surface2 text-theme-muted hover:text-theme-text'
                  }`}
                >
                  {s}
                </button>
              ))}
            </div>
          </div>

          <div className="flex items-center gap-2 text-xs text-theme-muted">
            <span>Жанр:</span>
            <span className="px-2 py-0.5 bg-theme-surface2 rounded text-theme-text font-medium">{genre}</span>
          </div>

          <button
            onClick={generateLyrics}
            disabled={generatingLyrics}
            className="px-5 py-2.5 bg-gradient-to-r from-theme-warning to-theme-primary text-white rounded-xl text-sm font-medium hover:shadow-lg transition-all disabled:opacity-50 flex items-center gap-2"
          >
            {generatingLyrics ? <Loader2 className="w-4 h-4 animate-spin" /> : <PenLine className="w-4 h-4" />}
            Сгенерировать текст
          </button>

          {generatedLyrics && (
            <div className="mt-4">
              <div className="flex items-center justify-between mb-2">
                <p className="text-xs text-theme-muted">Текст песни ({lyricTheme}, {genre}):</p>
                <button
                  onClick={copyLyrics}
                  className="p-1.5 text-theme-muted hover:text-theme-text transition-colors"
                  title="Скопировать"
                >
                  <Copy className="w-3.5 h-3.5" />
                </button>
              </div>
              <div className="p-4 bg-theme-surface2 rounded-xl border border-theme-border">
                <pre className="text-theme-text text-sm whitespace-pre-wrap font-sans leading-relaxed">{generatedLyrics}</pre>
              </div>
              {setPage && (
                <button
                  onClick={() => setPage('beat')}
                  className="mt-3 px-4 py-2 bg-theme-primary text-white rounded-lg text-xs font-medium hover:bg-theme-primary-hover transition-colors flex items-center gap-2"
                >
                  Открыть Бит-Секвенсор для создания музыки <ArrowRight className="w-3.5 h-3.5" />
                </button>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
