import { useState, useEffect, useCallback } from 'react';
import { useAuth } from '@/context/AuthContext';
import { supabase, type AvatarShopItem } from '@/lib/supabase';
import { Coins, Check, ShoppingBag, Sparkles, Loader2, Crown, Star, Lock } from 'lucide-react';

const RARITY_STYLES: Record<string, { border: string; glow: string; badge: string; label: string }> = {
  common: {
    border: 'border-theme-border',
    glow: '',
    badge: 'bg-theme-surface2 text-theme-muted',
    label: 'Обычный',
  },
  rare: {
    border: 'border-blue-500/50',
    glow: 'shadow-[0_0_15px_rgba(59,130,246,0.2)]',
    badge: 'bg-blue-500/20 text-blue-400',
    label: 'Редкий',
  },
  epic: {
    border: 'border-purple-500/50',
    glow: 'shadow-[0_0_15px_rgba(168,85,247,0.25)]',
    badge: 'bg-purple-500/20 text-purple-400',
    label: 'Эпический',
  },
  legendary: {
    border: 'border-amber-500/50',
    glow: 'shadow-[0_0_20px_rgba(245,158,11,0.3)]',
    badge: 'bg-amber-500/20 text-amber-400',
    label: 'Легендарный',
  },
};

// Gradient avatars as fallback if no image_url
const AVATAR_GRADIENTS: string[] = [
  'from-red-500 to-orange-500',
  'from-blue-500 to-cyan-500',
  'from-purple-500 to-pink-500',
  'from-green-500 to-emerald-500',
  'from-amber-500 to-yellow-500',
  'from-indigo-500 to-purple-500',
  'from-rose-500 to-pink-500',
  'from-teal-500 to-cyan-500',
];

export default function ShopPage() {
  const { profile, updateProfile, refreshProfile } = useAuth();
  const [items, setItems] = useState<AvatarShopItem[]>([]);
  const [ownedIds, setOwnedIds] = useState<string[]>([]);
  const [loading, setLoading] = useState(true);
  const [buying, setBuying] = useState<string | null>(null);
  const [equipping, setEquipping] = useState<string | null>(null);
  const [message, setMessage] = useState<string | null>(null);

  const fetchShopData = useCallback(async () => {
    if (!profile) return;
    setLoading(true);

    const [itemsRes, ownedRes] = await Promise.all([
      supabase.from('avatar_shop_items').select('*').order('price', { ascending: true }),
      supabase.from('user_avatars').select('item_id').eq('user_id', profile.id),
    ]);

    if (itemsRes.error) {
      console.error('Error fetching shop items:', itemsRes.error);
    } else {
      setItems(itemsRes.data || []);
    }

    if (ownedRes.error) {
      console.error('Error fetching owned avatars:', ownedRes.error);
    } else {
      setOwnedIds((ownedRes.data || []).map((r: { item_id: string }) => r.item_id));
    }

    setLoading(false);
  }, [profile]);

  useEffect(() => {
    fetchShopData();
  }, [fetchShopData]);

  const showMessage = (msg: string) => {
    setMessage(msg);
    setTimeout(() => setMessage(null), 3000);
  };

  const handleBuy = async (item: AvatarShopItem) => {
    if (!profile) return;
    if (ownedIds.includes(item.id)) return;
    if (profile.coins < item.price) {
      showMessage('Недостаточно монет для покупки');
      return;
    }

    setBuying(item.id);
    // Deduct coins
    await updateProfile({ coins: profile.coins - item.price });

    // Add to user_avatars
    const { error } = await supabase.from('user_avatars').insert({
      user_id: profile.id,
      item_id: item.id,
    });

    if (error) {
      console.error('Error adding avatar:', error);
      // Refund coins
      await updateProfile({ coins: profile.coins });
      showMessage('Ошибка при покупке');
    } else {
      setOwnedIds([...ownedIds, item.id]);
      showMessage(`Аватар «${item.name}» куплен!`);
    }

    setBuying(null);
  };

  const handleEquip = async (item: AvatarShopItem) => {
    if (!profile) return;
    if (!ownedIds.includes(item.id)) return;

    setEquipping(item.id);
    const avatarUrl = item.image_url || `gradient:${item.id}`;
    await updateProfile({ avatar_url: avatarUrl });
    await refreshProfile();
    setEquipping(null);
    showMessage(`Аватар «${item.name}» установлен!`);
  };

  const isEquipped = (item: AvatarShopItem): boolean => {
    if (!profile?.avatar_url) return false;
    const avatarUrl = item.image_url || `gradient:${item.id}`;
    return profile.avatar_url === avatarUrl;
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center py-20">
        <div className="w-8 h-8 border-2 border-theme-primary border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-theme-text flex items-center gap-2">
            <ShoppingBag className="w-6 h-6 text-theme-primary" />
            Магазин аватаров
          </h1>
          <p className="text-theme-muted text-sm mt-1">
            Купите уникальные аватары за монеты
          </p>
        </div>

        {/* Coin balance */}
        <div className="flex items-center gap-3 bg-theme-surface/50 border border-theme-border rounded-2xl px-5 py-3 glass-surface">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-theme-warning to-theme-accent flex items-center justify-center">
            <Coins className="w-5 h-5 text-white" />
          </div>
          <div>
            <p className="text-theme-muted text-xs uppercase tracking-wider">Ваш баланс</p>
            <p className="text-xl font-bold text-theme-text">{profile?.coins ?? 0} монет</p>
          </div>
        </div>
      </div>

      {/* Message */}
      {message && (
        <div className="bg-theme-primary-bg border border-theme-primary-border rounded-xl p-4 flex items-center gap-3">
          <Sparkles className="w-5 h-5 text-theme-primary" />
          <p className="text-theme-primary-text text-sm font-medium">{message}</p>
        </div>
      )}

      {/* Avatar grid */}
      {items.length === 0 ? (
        <div className="bg-theme-surface/50 border border-theme-border rounded-2xl p-8 text-center glass-surface">
          <ShoppingBag className="w-12 h-12 text-theme-muted mx-auto mb-3" />
          <p className="text-theme-muted">Магазин скоро будет пополнен</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
          {items.map((item, idx) => {
            const owned = ownedIds.includes(item.id);
            const equipped = isEquipped(item);
            const rarity = RARITY_STYLES[item.rarity] || RARITY_STYLES.common;
            const canAfford = (profile?.coins ?? 0) >= item.price;
            const gradient = AVATAR_GRADIENTS[idx % AVATAR_GRADIENTS.length];

            return (
              <div
                key={item.id}
                className={`bg-theme-surface/50 border-2 rounded-2xl overflow-hidden glass-surface transition-all ${rarity.border} ${rarity.glow} ${equipped ? 'ring-2 ring-theme-primary' : ''}`}
              >
                {/* Avatar image */}
                <div className="relative h-40 flex items-center justify-center overflow-hidden">
                  {item.image_url ? (
                    <img
                      src={item.image_url}
                      alt={item.name}
                      className="w-full h-full object-cover"
                    />
                  ) : (
                    <div className={`w-full h-full bg-gradient-to-br ${gradient} flex items-center justify-center`}>
                      <Crown className="w-16 h-16 text-white/80" />
                    </div>
                  )}

                  {/* Rarity badge */}
                  <div className={`absolute top-2 right-2 px-2 py-0.5 rounded-full text-xs font-bold ${rarity.badge} flex items-center gap-1`}>
                    {item.rarity === 'legendary' && <Star className="w-3 h-3" fill="currentColor" />}
                    {rarity.label}
                  </div>

                  {/* Equipped badge */}
                  {equipped && (
                    <div className="absolute top-2 left-2 px-2 py-0.5 bg-theme-primary text-white text-xs font-medium rounded-full flex items-center gap-1">
                      <Check className="w-3 h-3" />
                      Активен
                    </div>
                  )}
                </div>

                <div className="p-4">
                  <h3 className="text-theme-text font-bold text-base mb-1">{item.name}</h3>

                  <div className="flex items-center gap-1.5 mb-4">
                    <Coins className="w-4 h-4 text-theme-warning" />
                    <span className="text-theme-text font-bold">{item.price}</span>
                  </div>

                  {/* Actions */}
                  {owned ? (
                    equipped ? (
                      <div className="w-full py-2.5 bg-theme-success/20 text-theme-success rounded-xl text-sm font-medium text-center flex items-center justify-center gap-2">
                        <Check className="w-4 h-4" />
                        Установлен
                      </div>
                    ) : (
                      <button
                        onClick={() => handleEquip(item)}
                        disabled={equipping === item.id}
                        className="w-full py-2.5 bg-theme-primary text-white rounded-xl text-sm font-medium hover:bg-theme-primary-hover transition-colors disabled:opacity-50 flex items-center justify-center gap-2"
                      >
                        {equipping === item.id ? (
                          <Loader2 className="w-4 h-4 animate-spin" />
                        ) : (
                          <Sparkles className="w-4 h-4" />
                        )}
                        Установить
                      </button>
                    )
                  ) : (
                    <button
                      onClick={() => handleBuy(item)}
                      disabled={buying === item.id || !canAfford}
                      className={`w-full py-2.5 rounded-xl text-sm font-medium transition-all flex items-center justify-center gap-2 ${
                        canAfford
                          ? 'bg-gradient-to-r from-theme-warning to-theme-accent text-white hover:shadow-lg'
                          : 'bg-theme-surface2 text-theme-muted cursor-not-allowed'
                      } disabled:opacity-50`}
                    >
                      {buying === item.id ? (
                        <Loader2 className="w-4 h-4 animate-spin" />
                      ) : !canAfford ? (
                        <>
                          <Lock className="w-4 h-4" />
                          Не хватает монет
                        </>
                      ) : (
                        <>
                          <Coins className="w-4 h-4" />
                          Купить за {item.price}
                        </>
                      )}
                    </button>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
