import { useState, useEffect, useCallback } from 'react';
import { useAuth } from '@/context/AuthContext';
import { supabase, xpProgress, type Achievement, type Friendship, type Profile } from '@/lib/supabase';
import {
  User,
  Coins,
  Zap,
  Trophy,
  Users,
  Edit3,
  Save,
  X,
  Search,
  UserPlus,
  Check,
  Clock,
  ImageIcon,
  Circle,
} from 'lucide-react';

const AVATAR_OPTIONS = [
  '/avatar-cat.webp',
  '/avatar-robot.webp',
  '/avatar-astronaut.webp',
  '/avatar-music.webp',
  '/avatar-fox.webp',
  '/avatar-panda.webp',
  '/avatar-dragon.webp',
  '/avatar-ghost.webp',
];

export default function ProfilePage() {
  const { profile, session, updateProfile, addXp } = useAuth();
  const [editing, setEditing] = useState(false);
  const [username, setUsername] = useState('');
  const [bio, setBio] = useState('');
  const [avatarUrl, setAvatarUrl] = useState('');
  const [achievements, setAchievements] = useState<Achievement[]>([]);
  const [earnedIds, setEarnedIds] = useState<Set<string>>(new Set());
  const [friends, setFriends] = useState<Profile[]>([]);
  const [pendingRequests, setPendingRequests] = useState<Friendship[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [searchResults, setSearchResults] = useState<Profile[]>([]);
  const [gameScores, setGameScores] = useState<{ game_name: string; score: number }[]>([]);

  const loadData = useCallback(async () => {
    if (!profile) return;

    const [achRes, earnedRes, friendsRes, pendingRes, scoresRes] = await Promise.all([
      supabase.from('achievements').select('*'),
      supabase.from('user_achievements').select('achievement_id').eq('user_id', profile.id),
      supabase
        .from('friendships')
        .select('requester_id, addressee_id, status')
        .or(`requester_id.eq.${profile.id},addressee_id.eq.${profile.id}`)
        .eq('status', 'accepted'),
      supabase
        .from('friendships')
        .select('*')
        .eq('addressee_id', profile.id)
        .eq('status', 'pending'),
      supabase
        .from('game_scores')
        .select('game_name, score')
        .eq('user_id', profile.id)
        .order('score', { ascending: false }),
    ]);

    if (achRes.data) setAchievements(achRes.data);
    if (earnedRes.data) setEarnedIds(new Set(earnedRes.data.map((e) => e.achievement_id)));

    if (friendsRes.data) {
      const friendIds = friendsRes.data.map((f) =>
        f.requester_id === profile.id ? f.addressee_id : f.requester_id
      );
      if (friendIds.length > 0) {
        const { data: friendProfiles } = await supabase
          .from('profiles')
          .select('*')
          .in('id', friendIds);
        if (friendProfiles) setFriends(friendProfiles as Profile[]);
      }
    }

    if (pendingRes.data) setPendingRequests(pendingRes.data as Friendship[]);
    if (scoresRes.data) {
      const best: Record<string, number> = {};
      scoresRes.data.forEach((s) => {
        if (!best[s.game_name] || best[s.game_name] < s.score) {
          best[s.game_name] = s.score;
        }
      });
      setGameScores(Object.entries(best).map(([game_name, score]) => ({ game_name, score })));
    }
  }, [profile]);

  useEffect(() => {
    loadData();
  }, [loadData]);

  useEffect(() => {
    if (profile) {
      setUsername(profile.username);
      setBio(profile.bio || '');
      setAvatarUrl(profile.avatar_url || '');
    }
  }, [profile]);

  const handleSave = async () => {
    await updateProfile({ username, bio, avatar_url: avatarUrl || null });
    setEditing(false);
  };

  const searchUsers = async () => {
    if (!searchQuery.trim() || !profile) return;
    const { data } = await supabase
      .from('profiles')
      .select('*')
      .ilike('username', `%${searchQuery}%`)
      .neq('id', profile.id)
      .limit(10);
    if (data) setSearchResults(data as Profile[]);
  };

  const sendFriendRequest = async (addresseeId: string) => {
    if (!profile) return;
    await supabase.from('friendships').insert({
      requester_id: profile.id,
      addressee_id: addresseeId,
      status: 'pending',
    });
    setSearchResults((prev) => prev.filter((u) => u.id !== addresseeId));
  };

  const acceptFriend = async (requesterId: string) => {
    if (!profile) return;
    await supabase
      .from('friendships')
      .update({ status: 'accepted', accepted_at: new Date().toISOString() })
      .eq('requester_id', requesterId)
      .eq('addressee_id', profile.id);
    setPendingRequests((prev) => prev.filter((r) => r.requester_id !== requesterId));
    loadData();
    await addXp(20);
  };

  if (!profile) return null;

  const progress = xpProgress(profile.xp);

  return (
    <div className="space-y-6">
      {/* Profile header */}
      <div className="glass-surface bg-gradient-to-br from-theme-surface2 via-theme-surface to-theme-bg border border-theme-border rounded-2xl p-6 lg:p-8">
        <div className="flex flex-col sm:flex-row items-start gap-6">
          <div className="shrink-0">
            {profile.avatar_url ? (
              <img
                src={profile.avatar_url}
                alt=""
                className="w-24 h-24 rounded-2xl object-cover"
              />
            ) : (
              <div className="w-24 h-24 rounded-2xl bg-gradient-to-br from-theme-primary to-theme-accent flex items-center justify-center text-white text-3xl font-bold">
                {profile.username[0]?.toUpperCase()}
              </div>
            )}
          </div>
          <div className="flex-1 min-w-0">
            {editing ? (
              <div className="space-y-3">
                <input
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  className="px-3 py-2 bg-theme-surface2 border border-theme-border rounded-lg text-theme-text text-sm focus:outline-none focus:border-theme-primary w-full max-w-xs"
                  placeholder="Имя пользователя"
                />
                <div>
                  <label className="text-xs font-medium text-theme-muted mb-2 flex items-center gap-1.5">
                    <ImageIcon className="w-3.5 h-3.5" />
                    Выбрать аватар
                  </label>
                  <div className="grid grid-cols-4 sm:grid-cols-8 gap-2 mb-3">
                    {AVATAR_OPTIONS.map((av) => (
                      <button
                        key={av}
                        onClick={() => setAvatarUrl(av)}
                        className={`relative w-12 h-12 rounded-xl overflow-hidden border-2 transition-all ${
                          avatarUrl === av
                            ? 'border-theme-primary ring-2 ring-theme-primary/30 scale-105'
                            : 'border-theme-border hover:border-theme-muted'
                        }`}
                      >
                        <img src={av} alt="" className="w-full h-full object-cover" />
                      </button>
                    ))}
                  </div>
                  <input
                    value={avatarUrl}
                    onChange={(e) => setAvatarUrl(e.target.value)}
                    className="px-3 py-2 bg-theme-surface2 border border-theme-border rounded-lg text-theme-text text-sm focus:outline-none focus:border-theme-primary w-full max-w-xs"
                    placeholder="Или вставь ссылку на аватар"
                  />
                </div>
                <textarea
                  value={bio}
                  onChange={(e) => setBio(e.target.value)}
                  className="px-3 py-2 bg-theme-surface2 border border-theme-border rounded-lg text-theme-text text-sm focus:outline-none focus:border-theme-primary w-full max-w-md resize-none"
                  rows={2}
                  placeholder="О себе"
                />
                <div className="flex gap-2">
                  <button
                    onClick={handleSave}
                    className="px-4 py-2 bg-theme-primary text-white rounded-lg text-sm font-medium hover:bg-theme-primary-hover transition-colors flex items-center gap-2"
                  >
                    <Save className="w-4 h-4" /> Сохранить
                  </button>
                  <button
                    onClick={() => setEditing(false)}
                    className="px-4 py-2 bg-theme-surface2 text-theme-text rounded-lg text-sm font-medium hover:bg-theme-border transition-colors flex items-center gap-2"
                  >
                    <X className="w-4 h-4" /> Отмена
                  </button>
                </div>
              </div>
            ) : (
              <>
                <div className="flex items-center gap-3 flex-wrap">
                  <h1 className="text-2xl font-bold text-theme-text">{profile.username}</h1>
                  <div className="flex items-center gap-1.5 px-2 py-0.5 rounded-full bg-theme-surface2 border border-theme-border">
                    <Circle
                      className={`w-2.5 h-2.5 ${profile.is_online ? 'fill-theme-success text-theme-success' : 'fill-theme-muted text-theme-muted'}`}
                    />
                    <span className="text-xs text-theme-muted">
                      {profile.is_online ? 'В сети' : 'Не в сети'}
                    </span>
                  </div>
                  <button
                    onClick={() => setEditing(true)}
                    className="p-1.5 text-theme-muted hover:text-theme-primary transition-colors"
                  >
                    <Edit3 className="w-4 h-4" />
                  </button>
                </div>
                <p className="text-theme-muted text-sm mt-1">
                  {profile.bio || 'Описание отсутствует. Нажми на карандаш, чтобы добавить.'}
                </p>
                <div className="flex items-center gap-4 mt-4">
                  <div className="flex items-center gap-1.5 text-sm">
                    <Zap className="w-4 h-4 text-theme-primary" />
                    <span className="text-theme-text font-medium">{profile.xp}</span>
                    <span className="text-theme-muted text-xs">XP</span>
                  </div>
                  <div className="flex items-center gap-1.5 text-sm">
                    <User className="w-4 h-4 text-theme-success" />
                    <span className="text-theme-text font-medium">Уровень {profile.level}</span>
                  </div>
                  <div className="flex items-center gap-1.5 text-sm">
                    <Coins className="w-4 h-4 text-theme-warning" />
                    <span className="text-theme-text font-medium">{profile.coins}</span>
                    <span className="text-theme-muted text-xs">монет</span>
                  </div>
                </div>
                <div className="mt-4 max-w-md">
                  <div className="flex items-center justify-between text-xs mb-1">
                    <span className="text-theme-muted">Уровень {profile.level}</span>
                    <span className="text-theme-muted">
                      {progress.current}/{progress.needed} XP до следующего уровня
                    </span>
                  </div>
                  <div className="h-2 bg-theme-surface2 rounded-full overflow-hidden">
                    <div
                      className="h-full bg-gradient-to-r from-theme-primary to-theme-accent rounded-full transition-all duration-500"
                      style={{ width: `${progress.percent}%` }}
                    />
                  </div>
                </div>
              </>
            )}
          </div>
        </div>
      </div>

      {/* Pending friend requests */}
      {pendingRequests.length > 0 && (
        <div className="glass-surface bg-theme-surface/50 border border-theme-border rounded-2xl p-5">
          <h3 className="text-sm font-medium text-theme-text mb-3 flex items-center gap-2">
            <Clock className="w-4 h-4 text-theme-warning" />
            Заявки в друзья ({pendingRequests.length})
          </h3>
          <div className="space-y-2">
            {pendingRequests.map((req) => (
              <div key={req.id} className="flex items-center justify-between p-3 bg-theme-surface2 rounded-lg">
                <span className="text-sm text-theme-text">Заявка в друзья</span>
                <button
                  onClick={() => acceptFriend(req.requester_id)}
                  className="px-3 py-1.5 bg-theme-success text-white rounded-lg text-xs font-medium hover:bg-theme-success/90 transition-colors flex items-center gap-1.5"
                >
                  <Check className="w-3.5 h-3.5" /> Принять
                </button>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Friends + Search */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <div className="glass-surface bg-theme-surface/50 border border-theme-border rounded-2xl p-5">
          <h3 className="text-sm font-medium text-theme-text mb-3 flex items-center gap-2">
            <Users className="w-4 h-4 text-theme-primary" />
            Друзья ({friends.length})
          </h3>
          {friends.length === 0 ? (
            <p className="text-xs text-theme-muted">Друзей пока нет. Найди пользователей ниже, чтобы добавить.</p>
          ) : (
            <div className="space-y-2 max-h-48 overflow-y-auto">
              {friends.map((f) => (
                <div key={f.id} className="flex items-center gap-3 p-2 bg-theme-surface2 rounded-lg">
                  <div className="relative shrink-0">
                    {f.avatar_url ? (
                      <img src={f.avatar_url} alt="" className="w-8 h-8 rounded-full object-cover" />
                    ) : (
                      <div className="w-8 h-8 rounded-full bg-gradient-to-br from-theme-primary to-theme-accent flex items-center justify-center text-white text-xs font-bold">
                        {f.username[0]?.toUpperCase()}
                      </div>
                    )}
                    <Circle
                      className={`absolute -bottom-0.5 -right-0.5 w-3 h-3 ${f.is_online ? 'fill-theme-success text-theme-success' : 'fill-theme-muted text-theme-muted'} bg-theme-surface2 rounded-full`}
                    />
                  </div>
                  <div>
                    <p className="text-sm text-theme-text">{f.username}</p>
                    <p className="text-xs text-theme-muted">
                      {f.is_online ? 'В сети' : `Уровень ${f.level}`}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        <div className="glass-surface bg-theme-surface/50 border border-theme-border rounded-2xl p-5">
          <h3 className="text-sm font-medium text-theme-text mb-3 flex items-center gap-2">
            <Search className="w-4 h-4 text-theme-success" />
            Найти друзей
          </h3>
          <div className="flex gap-2 mb-3">
            <input
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && searchUsers()}
              placeholder="Поиск по имени..."
              className="flex-1 px-3 py-2 bg-theme-surface2 border border-theme-border rounded-lg text-theme-text text-sm focus:outline-none focus:border-theme-primary"
            />
            <button
              onClick={searchUsers}
              className="px-3 py-2 bg-theme-surface2 text-theme-text rounded-lg text-sm hover:bg-theme-border transition-colors"
            >
              <Search className="w-4 h-4" />
            </button>
          </div>
          {searchResults.length > 0 && (
            <div className="space-y-2 max-h-40 overflow-y-auto">
              {searchResults.map((u) => (
                <div key={u.id} className="flex items-center justify-between p-2 bg-theme-surface2 rounded-lg">
                  <div className="flex items-center gap-2">
                    {u.avatar_url ? (
                      <img src={u.avatar_url} alt="" className="w-7 h-7 rounded-full object-cover" />
                    ) : (
                      <div className="w-7 h-7 rounded-full bg-gradient-to-br from-theme-primary to-theme-accent flex items-center justify-center text-white text-xs font-bold">
                        {u.username[0]?.toUpperCase()}
                      </div>
                    )}
                    <span className="text-sm text-theme-text">{u.username}</span>
                  </div>
                  <button
                    onClick={() => sendFriendRequest(u.id)}
                    className="px-2.5 py-1 bg-theme-primary text-white rounded-lg text-xs font-medium hover:bg-theme-primary-hover transition-colors flex items-center gap-1"
                  >
                    <UserPlus className="w-3 h-3" /> Добавить
                  </button>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Achievements */}
      <div className="glass-surface bg-theme-surface/50 border border-theme-border rounded-2xl p-5">
        <h3 className="text-sm font-medium text-theme-text mb-4 flex items-center gap-2">
          <Trophy className="w-4 h-4 text-theme-warning" />
          Достижения ({earnedIds.size}/{achievements.length})
        </h3>
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3">
          {achievements.map((ach) => {
            const earned = earnedIds.has(ach.id);
            return (
              <div
                key={ach.id}
                className={`p-4 rounded-xl border text-center transition-all ${
                  earned
                    ? 'bg-gradient-to-br from-theme-warning/10 to-theme-primary/10 border-theme-warning'
                    : 'bg-theme-surface2/30 border-theme-border opacity-50'
                }`}
              >
                <div className={`text-2xl mb-2 ${earned ? '' : 'grayscale'}`}>
                  {earned ? '🏆' : '🔒'}
                </div>
                <p className="text-theme-text text-xs font-medium mb-1">{ach.name}</p>
                <p className="text-theme-muted text-[10px] leading-tight">{ach.description}</p>
                {earned && (
                  <p className="text-theme-warning text-[10px] mt-1">+{ach.xp_reward} XP</p>
                )}
              </div>
            );
          })}
        </div>
      </div>

      {/* Game scores */}
      {gameScores.length > 0 && (
        <div className="glass-surface bg-theme-surface/50 border border-theme-border rounded-2xl p-5">
          <h3 className="text-sm font-medium text-theme-text mb-3 flex items-center gap-2">
            <Trophy className="w-4 h-4 text-theme-accent" />
            Рекорды
          </h3>
          <div className="space-y-2">
            {gameScores.map((s, i) => (
              <div key={i} className="flex items-center justify-between p-2 bg-theme-surface2 rounded-lg">
                <span className="text-sm text-theme-text capitalize">{s.game_name}</span>
                <span className="text-sm text-theme-text font-mono">{s.score}</span>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
