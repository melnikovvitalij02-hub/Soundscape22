import { useState, useCallback, useRef } from 'react';
import { Search, Play, Youtube, Music2, Loader2, X, ExternalLink, Volume2, Pause } from 'lucide-react';

type Track = {
  id: string;
  title: string;
  artist: string;
  cover?: string;
  previewUrl?: string;
  youtubeId?: string;
};

export default function MusicSearchPage() {
  const [query, setQuery] = useState('');
  const [results, setResults] = useState<Track[]>([]);
  const [loading, setLoading] = useState(false);
  const [searched, setSearched] = useState(false);
  const [playingId, setPlayingId] = useState<string | null>(null);
  const audioRef = useRef<HTMLAudioElement | null>(null);

  const search = useCallback(async () => {
    if (!query.trim()) return;
    setLoading(true);
    setSearched(true);
    setPlayingId(null);

    try {
      const res = await fetch(
        `https://itunes.apple.com/search?term=${encodeURIComponent(query)}&media=music&limit=24`
      );
      const data = await res.json();
      const tracks: Track[] = (data.results || []).map((r: Record<string, unknown>) => ({
        id: String(r.trackId || r.collectionId || Math.random()),
        title: String(r.trackName || 'Без названия'),
        artist: String(r.artistName || 'Неизвестен'),
        cover: r.artworkUrl100 ? String(r.artworkUrl100).replace('100x100', '300x300') : undefined,
        previewUrl: r.previewUrl ? String(r.previewUrl) : undefined,
      }));
      setResults(tracks);
    } catch {
      setResults([]);
    }
    setLoading(false);
  }, [query]);

  const togglePreview = (track: Track) => {
    if (playingId === track.id) {
      audioRef.current?.pause();
      setPlayingId(null);
      return;
    }
    if (audioRef.current) {
      audioRef.current.pause();
    }
    const audio = new Audio(track.previewUrl);
    audio.play();
    audio.onended = () => setPlayingId(null);
    audioRef.current = audio;
    setPlayingId(track.id);
  };

  const openOnYoutube = (track: Track) => {
    window.open(
      `https://www.youtube.com/results?search_query=${encodeURIComponent(track.artist + ' ' + track.title)}`,
      '_blank'
    );
  };

  const formatTitle = (track: Track) => {
    return `${track.artist} - ${track.title}`;
  };

  const renderTrackCard = (track: Track) => (
    <div
      key={track.id}
      className="group text-left glass-surface bg-theme-surface/50 border border-theme-border rounded-2xl overflow-hidden hover:border-theme-warning transition-all"
    >
      <button
        onClick={() => togglePreview(track)}
        disabled={!track.previewUrl}
        className="block w-full text-left relative"
      >
        <div className="relative aspect-square bg-theme-surface2">
          {track.cover ? (
            <img
              src={track.cover}
              alt={track.title}
              className="w-full h-full object-cover group-hover:scale-105 transition-transform"
            />
          ) : (
            <div className="w-full h-full flex items-center justify-center">
              <Music2 className="w-12 h-12 text-theme-muted" />
            </div>
          )}
          <div className="absolute inset-0 bg-black/40 group-hover:bg-black/20 transition-colors flex items-center justify-center">
            <div className={`w-12 h-12 rounded-full ${track.previewUrl ? 'bg-theme-warning' : 'bg-theme-muted'} flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity`}>
              {playingId === track.id ? (
                <Pause className="w-5 h-5 text-white" fill="white" />
              ) : (
                <Play className="w-5 h-5 text-white" fill="white" />
              )}
            </div>
          </div>
          {playingId === track.id && (
            <div className="absolute bottom-2 left-2 flex items-center gap-1.5 px-2 py-1 bg-black/70 rounded-full">
              <Volume2 className="w-3 h-3 text-theme-warning animate-pulse" />
              <span className="text-xs text-white">Играет</span>
            </div>
          )}
        </div>
      </button>
      <div className="p-3">
        <p className="text-theme-text text-sm font-medium truncate">{track.title}</p>
        <p className="text-theme-muted text-xs truncate">{track.artist}</p>
      </div>
      <div className="px-3 pb-3 flex items-center gap-2">
        {track.previewUrl && (
          <button
            onClick={() => togglePreview(track)}
            className="flex-1 px-3 py-1.5 bg-theme-warning/20 text-theme-warning rounded-lg text-xs font-medium hover:bg-theme-warning/30 transition-colors flex items-center justify-center gap-1.5"
          >
            {playingId === track.id ? (
              <><Pause className="w-3.5 h-3.5" /> Стоп</>
            ) : (
              <><Play className="w-3.5 h-3.5" /> Превью 30с</>
            )}
          </button>
        )}
        <button
          onClick={() => openOnYoutube(track)}
          className="px-3 py-1.5 bg-theme-surface2 text-theme-muted rounded-lg text-xs font-medium hover:text-theme-danger transition-colors flex items-center gap-1.5"
          title="Найти на YouTube"
        >
          <Youtube className="w-3.5 h-3.5" />
        </button>
      </div>
    </div>
  );

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-theme-text flex items-center gap-2">
          <Search className="w-6 h-6 text-theme-warning" />
          Поиск Музыки
        </h1>
        <p className="text-theme-muted text-sm mt-1">
          Находи треки и исполнителей — слушай 30-секундные превью и открывай на YouTube
        </p>
      </div>

      <div className="flex gap-2">
        <div className="flex-1 relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-theme-muted" />
          <input
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && search()}
            placeholder="Введи название песни или исполнителя..."
            className="w-full pl-10 pr-4 py-3 bg-theme-surface2 border border-theme-border rounded-xl text-theme-text text-sm focus:outline-none focus:border-theme-warning focus:ring-1 focus:ring-theme-warning transition-colors"
          />
        </div>
        <button
          onClick={search}
          disabled={loading}
          className="px-6 py-3 bg-theme-warning text-white rounded-xl text-sm font-medium hover:bg-theme-warning/90 transition-colors disabled:opacity-50"
        >
          {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : 'Поиск'}
        </button>
      </div>

      {loading ? (
        <div className="flex items-center justify-center py-12">
          <Loader2 className="w-6 h-6 text-theme-warning animate-spin" />
        </div>
      ) : !searched ? (
        <div className="text-center py-12">
          <Music2 className="w-12 h-12 text-theme-muted mx-auto mb-3" />
          <p className="text-theme-muted text-sm">
            Введи название песни или имя исполнителя и нажми «Поиск»
          </p>
          <p className="text-theme-muted text-xs mt-1">
            Покажем до 24 треков с 30-секундными превью
          </p>
        </div>
      ) : results.length === 0 ? (
        <div className="text-center py-12">
          <Music2 className="w-12 h-12 text-theme-muted mx-auto mb-3" />
          <p className="text-theme-muted text-sm">Ничего не найдено по запросу «{query}»</p>
        </div>
      ) : (
        <>
          <p className="text-xs text-theme-muted">
            Найдено {results.length} {results.length < 5 ? 'трека' : results.length < 21 ? 'треков' : 'треков'}. Нажми на обложку для превью, на YouTube — для полного видео.
          </p>
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-6 gap-4">
            {results.map(renderTrackCard)}
          </div>
        </>
      )}
    </div>
  );
}
