import { useState, useRef, useEffect, useCallback } from 'react';
import { Play, ArrowLeft } from 'lucide-react';

type Point = { x: number; y: number };

const MAZE = [
  '###################',
  '#........#........#',
  '#o##.###.#.###.##o#',
  '#.................#',
  '#.##.#.#####.#.##.#',
  '#....#...#...#....#',
  '####.###.#.###.####',
  '   #.#.......#.#   ',
  '####.#.##-##.#.####',
  '    ...#...#...    ',
  '####.#.#####.#.####',
  '   #.#.......#.#   ',
  '####.###.#.###.####',
  '#........#........#',
  '#.##.###.#.###.##.#',
  '#o.#...........#.o#',
  '##.#.#.#####.#.#.##',
  '#....#...#...#....#',
  '#.######.#.######.#',
  '###################',
];

const COLS = 19;
const ROWS = 20;
const CELL = 24;

type CellType = 'wall' | 'dot' | 'power' | 'empty' | 'door';

function parseMaze(): CellType[][] {
  return MAZE.map((row) =>
    row.split('').map((ch): CellType => {
      if (ch === '#') return 'wall';
      if (ch === '.') return 'dot';
      if (ch === 'o') return 'power';
      if (ch === '-') return 'door';
      return 'empty';
    })
  );
}

type Ghost = {
  x: number;
  y: number;
  dir: Point;
  color: string;
  scared: number;
  eaten: boolean;
  homeX: number;
  homeY: number;
};

type Particle = { x: number; y: number; vx: number; vy: number; life: number; color: string };

export default function PacManGame({ onExit, onScore }: { onExit: () => void; onScore: (name: string, score: number) => void }) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [score, setScore] = useState(0);
  const [lives, setLives] = useState(3);
  const [gameOver, setGameOver] = useState(false);
  const [running, setRunning] = useState(false);
  const [won, setWon] = useState(false);

  const mazeRef = useRef<CellType[][]>(parseMaze());
  const pacmanRef = useRef<Point>({ x: 9, y: 15 });
  const pacDirRef = useRef<Point>({ x: 0, y: 0 });
  const nextDirRef = useRef<Point>({ x: 0, y: 0 });
  const ghostsRef = useRef<Ghost[]>([]);
  const dotsLeftRef = useRef(0);
  const livesRef = useRef(3);
  const scoreRef = useRef(0);
  const loopRef = useRef<number | null>(null);
  const frameRef = useRef(0);
  const powerTimerRef = useRef(0);

  // Visual effect refs
  const starsRef = useRef<Array<{ x: number; y: number; size: number; speed: number }>>([]);
  const shakeRef = useRef(0);
  const particlesRef = useRef<Particle[]>([]);

  const initGhosts = useCallback(() => {
    const colors = ['#ff006e', '#ffbe0b', '#8338ec', '#3a86ff'];
    ghostsRef.current = [
      { x: 9, y: 9, dir: { x: -1, y: 0 }, color: colors[0], scared: 0, eaten: false, homeX: 9, homeY: 9 },
      { x: 8, y: 9, dir: { x: 0, y: -1 }, color: colors[1], scared: 0, eaten: false, homeX: 8, homeY: 9 },
      { x: 10, y: 9, dir: { x: 0, y: 1 }, color: colors[2], scared: 0, eaten: false, homeX: 10, homeY: 9 },
      { x: 9, y: 8, dir: { x: 1, y: 0 }, color: colors[3], scared: 0, eaten: false, homeX: 9, homeY: 8 },
    ];
  }, []);

  const countDots = useCallback(() => {
    let count = 0;
    for (const row of mazeRef.current) {
      for (const cell of row) {
        if (cell === 'dot' || cell === 'power') count++;
      }
    }
    dotsLeftRef.current = count;
  }, []);

  const spawnParticles = useCallback((x: number, y: number, color: string, count: number) => {
    for (let i = 0; i < count; i++) {
      const angle = (Math.PI * 2 * i) / count + Math.random() * 0.3;
      particlesRef.current.push({
        x,
        y,
        vx: Math.cos(angle) * (Math.random() * 3 + 1),
        vy: Math.sin(angle) * (Math.random() * 3 + 1),
        life: 30,
        color,
      });
    }
  }, []);

  const draw = useCallback(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const shake = shakeRef.current;
    if (shake > 0) {
      ctx.save();
      ctx.translate(Math.random() * shake - shake / 2, Math.random() * shake - shake / 2);
      shakeRef.current -= 0.5;
    }

    // Gradient background
    const bgGrad = ctx.createLinearGradient(0, 0, 0, canvas.height);
    bgGrad.addColorStop(0, '#0a0a1a');
    bgGrad.addColorStop(0.5, '#0f0f2a');
    bgGrad.addColorStop(1, '#050510');
    ctx.fillStyle = bgGrad;
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    // Starfield
    ctx.fillStyle = 'rgba(255,255,255,0.3)';
    starsRef.current.forEach((s) => {
      ctx.beginPath();
      ctx.arc(s.x, s.y, s.size, 0, Math.PI * 2);
      ctx.fill();
      s.y += s.speed;
      if (s.y > canvas.height) {
        s.y = 0;
        s.x = Math.random() * canvas.width;
      }
    });

    const maze = mazeRef.current;

    for (let y = 0; y < ROWS; y++) {
      for (let x = 0; x < COLS; x++) {
        const cell = maze[y][x];
        const px = x * CELL;
        const py = y * CELL;

        if (cell === 'wall') {
          const grad = ctx.createLinearGradient(px, py, px + CELL, py + CELL);
          grad.addColorStop(0, '#1e3a8a');
          grad.addColorStop(1, '#1a1a6a');
          ctx.fillStyle = grad;
          ctx.fillRect(px + 1, py + 1, CELL - 2, CELL - 2);
          ctx.strokeStyle = '#3b82f6';
          ctx.lineWidth = 1;
          ctx.strokeRect(px + 1, py + 1, CELL - 2, CELL - 2);
        } else if (cell === 'dot') {
          ctx.font = '10px sans-serif';
          ctx.textAlign = 'center';
          ctx.textBaseline = 'middle';
          ctx.fillText('🍬', px + CELL / 2, py + CELL / 2);
        } else if (cell === 'power') {
          // Pulsing power pellet
          const pulse = 1 + Math.sin(frameRef.current * 0.15) * 0.3;
          ctx.save();
          ctx.translate(px + CELL / 2, py + CELL / 2);
          ctx.scale(pulse, pulse);
          ctx.font = '16px sans-serif';
          ctx.textAlign = 'center';
          ctx.textBaseline = 'middle';
          ctx.shadowColor = 'rgba(255, 200, 0, 0.8)';
          ctx.shadowBlur = 12;
          ctx.fillText('⭐', 0, 0);
          ctx.shadowBlur = 0;
          ctx.restore();
        } else if (cell === 'door') {
          ctx.fillStyle = '#ff6666';
          ctx.fillRect(px + 2, py + CELL / 2 - 2, CELL - 4, 4);
        }
      }
    }

    const pac = pacmanRef.current;
    const pacPx = pac.x * CELL + CELL / 2;
    const pacPy = pac.y * CELL + CELL / 2;
    ctx.font = `${CELL * 0.8}px sans-serif`;
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.shadowColor = 'rgba(255, 200, 0, 0.6)';
    ctx.shadowBlur = 10;
    ctx.fillText('😀', pacPx, pacPy);
    ctx.shadowBlur = 0;

    ghostsRef.current.forEach((g) => {
      const gx = g.x * CELL + CELL / 2;
      const gy = g.y * CELL + CELL / 2;

      ctx.font = `${CELL * 0.8}px sans-serif`;
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';

      if (g.eaten) {
        ctx.shadowColor = 'rgba(200, 200, 255, 0.5)';
        ctx.shadowBlur = 6;
        ctx.fillText('💀', gx, gy);
        ctx.shadowBlur = 0;
      } else if (g.scared > 0) {
        const blink = g.scared < 60 && frameRef.current % 10 < 5;
        ctx.shadowColor = 'rgba(100, 150, 255, 0.6)';
        ctx.shadowBlur = 8;
        ctx.fillText(blink ? '😱' : '👻', gx, gy);
        ctx.shadowBlur = 0;
      } else {
        ctx.shadowColor = g.color;
        ctx.shadowBlur = 8;
        ctx.fillText('👻', gx, gy);
        ctx.shadowBlur = 0;
      }
    });

    // Power mode overlay
    if (powerTimerRef.current > 0) {
      const pulse = 1 + Math.sin(frameRef.current * 0.2) * 0.15;
      ctx.save();
      ctx.translate(canvas.width / 2, 14);
      ctx.scale(pulse, pulse);
      ctx.font = 'bold 14px sans-serif';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.shadowColor = 'rgba(100, 200, 255, 0.8)';
      ctx.shadowBlur = 12;
      ctx.fillStyle = 'rgba(100, 200, 255, 0.9)';
      ctx.fillText('POWER MODE!', 0, 0);
      ctx.shadowBlur = 0;
      ctx.restore();
    }

    // Particles
    particlesRef.current = particlesRef.current.filter((p) => p.life > 0);
    particlesRef.current.forEach((p) => {
      ctx.fillStyle = p.color;
      ctx.globalAlpha = p.life / 30;
      ctx.beginPath();
      ctx.arc(p.x, p.y, 3, 0, Math.PI * 2);
      ctx.fill();
      p.x += p.vx;
      p.y += p.vy;
      p.vy += 0.1;
      p.life--;
    });
    ctx.globalAlpha = 1;

    if (shake > 0) ctx.restore();
  }, []);

  const canMove = useCallback((x: number, y: number, dir: Point): boolean => {
    const nx = x + dir.x;
    const ny = y + dir.y;
    if (nx < 0 || nx >= COLS || ny < 0 || ny >= ROWS) return false;
    const cell = mazeRef.current[ny][nx];
    return cell !== 'wall' && cell !== 'door';
  }, []);

  const wrap = useCallback((p: Point): Point => {
    let x = p.x;
    let y = p.y;
    if (x < 0) x = COLS - 1;
    if (x >= COLS) x = 0;
    return { x, y };
  }, []);

  const moveGhosts = useCallback(() => {
    const pac = pacmanRef.current;
    ghostsRef.current.forEach((g) => {
      if (g.eaten) {
        const dx = g.homeX - g.x;
        const dy = g.homeY - g.y;
        if (Math.abs(dx) <= 0.5 && Math.abs(dy) <= 0.5) {
          g.eaten = false;
          g.scared = 0;
          g.x = g.homeX;
          g.y = g.homeY;
        } else {
          const dirs = [
            { x: dx > 0 ? 1 : -1, y: 0 },
            { x: 0, y: dy > 0 ? 1 : -1 },
          ];
          for (const d of dirs) {
            if (canMove(Math.round(g.x), Math.round(g.y), d)) {
              g.x += d.x * 0.5;
              g.y += d.y * 0.5;
              break;
            }
          }
        }
        return;
      }

      const ix = Math.round(g.x);
      const iy = Math.round(g.y);
      if (Math.abs(g.x - ix) < 0.1 && Math.abs(g.y - iy) < 0.1) {
        g.x = ix;
        g.y = iy;

        const options: Point[] = [
          { x: 1, y: 0 },
          { x: -1, y: 0 },
          { x: 0, y: 1 },
          { x: 0, y: -1 },
        ].filter((d) => canMove(ix, iy, d) && !(d.x === -g.dir.x && d.y === -g.dir.y));

        if (options.length === 0) {
          g.dir = { x: -g.dir.x, y: -g.dir.y };
        } else if (options.length === 1) {
          g.dir = options[0];
        } else {
          let best = options[0];
          let bestDist = Infinity;
          for (const opt of options) {
            const nx = ix + opt.x;
            const ny = iy + opt.y;
            const dist = Math.hypot(nx - pac.x, ny - pac.y);
            const effectiveDist = g.scared > 0 ? -dist : dist;
            if (effectiveDist < bestDist) {
              bestDist = effectiveDist;
              best = opt;
            }
          }
          if (Math.random() < 0.2) {
            best = options[Math.floor(Math.random() * options.length)];
          }
          g.dir = best;
        }
      }

      const speed = g.scared > 0 ? 0.4 : 0.6;
      g.x += g.dir.x * speed;
      g.y += g.dir.y * speed;
      g.x = ((g.x % COLS) + COLS) % COLS;

      if (g.scared > 0) g.scared--;
    });
  }, [canMove]);

  const tick = useCallback(() => {
    frameRef.current++;

    if (frameRef.current % 2 === 0) {
      let pac = pacmanRef.current;

      if (canMove(pac.x, pac.y, nextDirRef.current)) {
        pacDirRef.current = nextDirRef.current;
      }

      if (canMove(pac.x, pac.y, pacDirRef.current)) {
        pac = { x: pac.x + pacDirRef.current.x, y: pac.y + pacDirRef.current.y };
        pac = wrap(pac);
        pacmanRef.current = pac;

        const cell = mazeRef.current[pac.y][pac.x];
        if (cell === 'dot') {
          mazeRef.current[pac.y][pac.x] = 'empty';
          scoreRef.current += 10;
          setScore(scoreRef.current);
          dotsLeftRef.current--;
          spawnParticles(pac.x * CELL + CELL / 2, pac.y * CELL + CELL / 2, 'rgba(255, 220, 100, 0.8)', 4);
        } else if (cell === 'power') {
          mazeRef.current[pac.y][pac.x] = 'empty';
          scoreRef.current += 50;
          setScore(scoreRef.current);
          dotsLeftRef.current--;
          powerTimerRef.current = 200;
          ghostsRef.current.forEach((g) => {
            if (!g.eaten) g.scared = 200;
          });
        }

        if (dotsLeftRef.current <= 0) {
          setWon(true);
          setRunning(false);
          if (loopRef.current) clearInterval(loopRef.current);
        }
      }

      if (powerTimerRef.current > 0) powerTimerRef.current--;
    }

    moveGhosts();

    const pac = pacmanRef.current;
    ghostsRef.current.forEach((g) => {
      if (g.eaten) return;
      const dist = Math.hypot(g.x - pac.x, g.y - pac.y);
      if (dist < 0.8) {
        if (g.scared > 0) {
          g.eaten = true;
          scoreRef.current += 200;
          setScore(scoreRef.current);
          spawnParticles(g.x * CELL + CELL / 2, g.y * CELL + CELL / 2, 'rgba(100, 150, 255, 0.9)', 12);
        } else {
          livesRef.current--;
          setLives(livesRef.current);
          shakeRef.current = 15;
          if (livesRef.current <= 0) {
            setGameOver(true);
            setRunning(false);
            if (loopRef.current) clearInterval(loopRef.current);
          } else {
            pacmanRef.current = { x: 9, y: 15 };
            pacDirRef.current = { x: 0, y: 0 };
            nextDirRef.current = { x: 0, y: 0 };
            initGhosts();
          }
        }
      }
    });

    draw();
  }, [canMove, wrap, moveGhosts, draw, initGhosts, spawnParticles]);

  const start = () => {
    mazeRef.current = parseMaze();
    pacmanRef.current = { x: 9, y: 15 };
    pacDirRef.current = { x: 0, y: 0 };
    nextDirRef.current = { x: 0, y: 0 };
    initGhosts();
    countDots();
    scoreRef.current = 0;
    livesRef.current = 3;
    powerTimerRef.current = 0;
    shakeRef.current = 0;
    particlesRef.current = [];
    const canvas = canvasRef.current;
    starsRef.current = Array.from({ length: 50 }, () => ({
      x: Math.random() * (canvas?.width ?? COLS * CELL),
      y: Math.random() * (canvas?.height ?? ROWS * CELL),
      size: Math.random() * 2 + 0.5,
      speed: Math.random() * 0.5 + 0.1,
    }));
    setScore(0);
    setLives(3);
    setGameOver(false);
    setWon(false);
    setRunning(true);
    draw();
    if (loopRef.current) clearInterval(loopRef.current);
    loopRef.current = window.setInterval(tick, 1000 / 30);
  };

  useEffect(() => {
    const handleKey = (e: KeyboardEvent) => {
      if (!running) return;
      switch (e.key) {
        case 'ArrowUp':
        case 'w':
        case 'W':
          nextDirRef.current = { x: 0, y: -1 };
          e.preventDefault();
          break;
        case 'ArrowDown':
        case 's':
        case 'S':
          nextDirRef.current = { x: 0, y: 1 };
          e.preventDefault();
          break;
        case 'ArrowLeft':
        case 'a':
        case 'A':
          nextDirRef.current = { x: -1, y: 0 };
          e.preventDefault();
          break;
        case 'ArrowRight':
        case 'd':
        case 'D':
          nextDirRef.current = { x: 1, y: 0 };
          e.preventDefault();
          break;
      }
    };
    window.addEventListener('keydown', handleKey);
    return () => {
      window.removeEventListener('keydown', handleKey);
      if (loopRef.current) clearInterval(loopRef.current);
    };
  }, [running]);

  useEffect(() => {
    if (gameOver) onScore('pacman', score);
    if (won) onScore('pacman', score + 500);
  }, [gameOver, won, score, onScore]);

  const touchStartRef = useRef<Point | null>(null);
  const handleTouchStart = (e: React.TouchEvent) => {
    touchStartRef.current = { x: e.touches[0].clientX, y: e.touches[0].clientY };
  };
  const handleTouchEnd = (e: React.TouchEvent) => {
    if (!touchStartRef.current || !running) return;
    const dx = e.changedTouches[0].clientX - touchStartRef.current.x;
    const dy = e.changedTouches[0].clientY - touchStartRef.current.y;
    if (Math.abs(dx) > Math.abs(dy)) {
      nextDirRef.current = { x: dx > 0 ? 1 : -1, y: 0 };
    } else {
      nextDirRef.current = { x: 0, y: dy > 0 ? 1 : -1 };
    }
    touchStartRef.current = null;
  };

  const handlePointerDown = (e: React.PointerEvent) => {
    touchStartRef.current = { x: e.clientX, y: e.clientY };
  };
  const handlePointerUp = (e: React.PointerEvent) => {
    if (!touchStartRef.current || !running) return;
    const dx = e.clientX - touchStartRef.current.x;
    const dy = e.clientY - touchStartRef.current.y;
    if (Math.abs(dx) > 5 || Math.abs(dy) > 5) {
      if (Math.abs(dx) > Math.abs(dy)) {
        nextDirRef.current = { x: dx > 0 ? 1 : -1, y: 0 };
      } else {
        nextDirRef.current = { x: 0, y: dy > 0 ? 1 : -1 };
      }
    }
    touchStartRef.current = null;
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <button
          onClick={onExit}
          className="flex items-center gap-2 text-theme-muted hover:text-theme-text text-sm transition-colors"
        >
          <ArrowLeft className="w-4 h-4" /> Назад к играм
        </button>
        <div className="flex items-center gap-4 text-theme-text text-sm">
          <span>Очки: <span className="font-bold text-theme-warning">{score}</span></span>
          <span>Жизни: <span className="text-theme-danger">{'\u2665'.repeat(lives)}</span></span>
        </div>
      </div>

      <div className="flex flex-col items-center gap-4">
        <canvas
          ref={canvasRef}
          width={COLS * CELL}
          height={ROWS * CELL}
          className="rounded-xl border border-theme-border max-w-full h-auto touch-none"
          style={{ touchAction: 'none' }}
          onContextMenu={(e) => e.preventDefault()}
          onTouchStart={handleTouchStart}
          onTouchEnd={handleTouchEnd}
          onPointerDown={handlePointerDown}
          onPointerUp={handlePointerUp}
        />
        {(gameOver || won) && (
          <div className="text-center">
            <p className={`font-medium text-sm mb-2 ${won ? 'text-theme-success' : 'text-theme-danger'}`}>
              {won ? 'Победа! Все точки собраны!' : 'Игра окончена!'} Финальный счёт: {score + (won ? 500 : 0)}
            </p>
          </div>
        )}
        <button
          onClick={start}
          className="px-6 py-2.5 bg-theme-warning text-white rounded-xl text-sm font-medium hover:bg-theme-warning/90 transition-colors flex items-center gap-2"
        >
          <Play className="w-4 h-4" /> {gameOver || won ? 'Играть снова' : 'Начать игру'}
        </button>

        <p className="text-xs text-theme-muted">Управление: водите пальцем по экрану (или мышью на ПК)</p>
      </div>
    </div>
  );
}
