import { useState, useRef, useEffect, useCallback } from 'react';
import { Play, ArrowLeft } from 'lucide-react';

type Bullet = { x: number; y: number; vy: number };
type Invader = { x: number; y: number; alive: boolean; type: number };
type Particle = { x: number; y: number; vx: number; vy: number; life: number; color: string };

const W = 480;
const H = 400;
const COLS = 8;
const ROWS = 4;
const INVADER_W = 32;
const INVADER_H = 24;
const GAP = 8;

const INVADER_EMOJI = ['👾', '👽', '🛸', '🎃'];

export default function SpaceInvadersGame({ onExit, onScore }: { onExit: () => void; onScore: (name: string, score: number) => void }) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [score, setScore] = useState(0);
  const [gameOver, setGameOver] = useState(false);
  const [won, setWon] = useState(false);
  const [running, setRunning] = useState(false);

  const playerRef = useRef({ x: W / 2, y: H - 40 });
  const bulletsRef = useRef<Bullet[]>([]);
  const enemyBulletsRef = useRef<Bullet[]>([]);
  const invadersRef = useRef<Invader[]>([]);
  const keysRef = useRef<Set<string>>(new Set());
  const loopRef = useRef<number | null>(null);
  const scoreRef = useRef(0);
  const frameRef = useRef(0);
  const invaderDirRef = useRef(1);
  const invaderOffsetRef = useRef(0);
  const invaderSpeedRef = useRef(0.5);

  // Visual effect refs
  const starsRef = useRef<Array<{ x: number; y: number; size: number; speed: number }>>([]);
  const shakeRef = useRef(0);
  const particlesRef = useRef<Particle[]>([]);
  const muzzleFlashRef = useRef(0);

  const initInvaders = useCallback(() => {
    invadersRef.current = [];
    for (let row = 0; row < ROWS; row++) {
      for (let col = 0; col < COLS; col++) {
        invadersRef.current.push({
          x: col * (INVADER_W + GAP) + 30,
          y: row * (INVADER_H + GAP) + 30,
          alive: true,
          type: row,
        });
      }
    }
  }, []);

  const spawnParticles = useCallback((x: number, y: number, color: string, count: number) => {
    for (let i = 0; i < count; i++) {
      const angle = (Math.PI * 2 * i) / count + Math.random() * 0.3;
      particlesRef.current.push({
        x,
        y,
        vx: Math.cos(angle) * (Math.random() * 3 + 1),
        vy: Math.sin(angle) * (Math.random() * 3 + 1),
        life: 30,
        color,
      });
    }
  }, []);

  const draw = useCallback(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const shake = shakeRef.current;
    if (shake > 0) {
      ctx.save();
      ctx.translate(Math.random() * shake - shake / 2, Math.random() * shake - shake / 2);
      shakeRef.current -= 0.5;
    }

    // Gradient background
    const bgGrad = ctx.createLinearGradient(0, 0, 0, H);
    bgGrad.addColorStop(0, '#0a0a1a');
    bgGrad.addColorStop(0.5, '#0f0f2a');
    bgGrad.addColorStop(1, '#050510');
    ctx.fillStyle = bgGrad;
    ctx.fillRect(0, 0, W, H);

    // Starfield (80 stars, faster)
    ctx.fillStyle = 'rgba(255,255,255,0.4)';
    starsRef.current.forEach((s) => {
      ctx.beginPath();
      ctx.arc(s.x, s.y, s.size, 0, Math.PI * 2);
      ctx.fill();
      s.y += s.speed;
      if (s.y > H) {
        s.y = 0;
        s.x = Math.random() * W;
      }
    });

    const p = playerRef.current;

    // Muzzle flash
    if (muzzleFlashRef.current > 0) {
      ctx.fillStyle = `rgba(255, 220, 100, ${muzzleFlashRef.current / 10})`;
      ctx.beginPath();
      ctx.arc(p.x, p.y - 14, 8, 0, Math.PI * 2);
      ctx.fill();
      muzzleFlashRef.current--;
    }

    // Player ship with green glow
    ctx.font = '24px sans-serif';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.shadowColor = 'rgba(0, 255, 100, 0.6)';
    ctx.shadowBlur = 10;
    ctx.fillText('🚀', p.x, p.y);
    ctx.shadowBlur = 0;

    // Bullets with glow
    ctx.font = '12px sans-serif';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.shadowColor = 'rgba(255, 220, 50, 0.6)';
    ctx.shadowBlur = 6;
    bulletsRef.current.forEach((b) => {
      ctx.fillText('⚡', b.x, b.y);
    });
    ctx.shadowColor = 'rgba(255, 80, 50, 0.6)';
    enemyBulletsRef.current.forEach((b) => {
      ctx.fillText('💥', b.x, b.y);
    });
    ctx.shadowBlur = 0;

    // Invaders with wave animation and glow
    const offset = invaderOffsetRef.current;
    const waveOffset = Math.sin(frameRef.current * 0.05) * 3;
    ctx.font = '20px sans-serif';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    const invaderGlowColors = ['rgba(180, 80, 255, 0.6)', 'rgba(255, 80, 80, 0.6)', 'rgba(200, 100, 255, 0.6)', 'rgba(255, 120, 50, 0.6)'];
    invadersRef.current.forEach((inv) => {
      if (!inv.alive) return;
      const ix = inv.x + offset + INVADER_W / 2;
      const iy = inv.y + INVADER_H / 2 + waveOffset;
      ctx.shadowColor = invaderGlowColors[inv.type % invaderGlowColors.length];
      ctx.shadowBlur = 8;
      ctx.fillText(INVADER_EMOJI[inv.type % INVADER_EMOJI.length], ix, iy);
    });
    ctx.shadowBlur = 0;

    // Particles
    particlesRef.current = particlesRef.current.filter((pp) => pp.life > 0);
    particlesRef.current.forEach((pp) => {
      ctx.fillStyle = pp.color;
      ctx.globalAlpha = pp.life / 30;
      ctx.beginPath();
      ctx.arc(pp.x, pp.y, 3, 0, Math.PI * 2);
      ctx.fill();
      pp.x += pp.vx;
      pp.y += pp.vy;
      pp.vy += 0.1;
      pp.life--;
    });
    ctx.globalAlpha = 1;

    if (shake > 0) ctx.restore();
  }, []);

  const tick = useCallback(() => {
    frameRef.current++;
    const p = playerRef.current;
    const keys = keysRef.current;

    if (keys.has('ArrowLeft') || keys.has('a') || keys.has('A')) p.x -= 4;
    if (keys.has('ArrowRight') || keys.has('d') || keys.has('D')) p.x += 4;
    p.x = Math.max(20, Math.min(W - 20, p.x));

    if (keys.has(' ') && frameRef.current % 15 === 0) {
      bulletsRef.current.push({ x: p.x, y: p.y - 10, vy: -7 });
      muzzleFlashRef.current = 8;
      spawnParticles(p.x, p.y - 14, 'rgba(255, 220, 100, 0.8)', 4);
    }

    bulletsRef.current = bulletsRef.current.filter((b) => {
      b.y += b.vy;
      return b.y > -10;
    });
    enemyBulletsRef.current = enemyBulletsRef.current.filter((b) => {
      b.y += 5;
      return b.y < H + 10;
    });

    const aliveInvaders = invadersRef.current.filter((i) => i.alive);
    if (aliveInvaders.length === 0) {
      setWon(true);
      setRunning(false);
      if (loopRef.current) clearInterval(loopRef.current);
      return;
    }

    const speed = invaderSpeedRef.current;
    let hitEdge = false;
    aliveInvaders.forEach((inv) => {
      const newX = inv.x + invaderOffsetRef.current + invaderDirRef.current * speed;
      if (newX < 5 || newX + INVADER_W > W - 5) hitEdge = true;
    });

    if (hitEdge) {
      invaderDirRef.current *= -1;
      invadersRef.current.forEach((inv) => {
        inv.y += 15;
      });
    } else {
      invaderOffsetRef.current += invaderDirRef.current * speed;
    }

    if (frameRef.current % 60 === 0 && aliveInvaders.length > 0) {
      const shooter = aliveInvaders[Math.floor(Math.random() * aliveInvaders.length)];
      enemyBulletsRef.current.push({
        x: shooter.x + invaderOffsetRef.current + INVADER_W / 2,
        y: shooter.y + INVADER_H,
        vy: 5,
      });
    }

    bulletsRef.current = bulletsRef.current.filter((b) => {
      for (const inv of invadersRef.current) {
        if (!inv.alive) continue;
        const ix = inv.x + invaderOffsetRef.current;
        if (b.x >= ix && b.x <= ix + INVADER_W && b.y >= inv.y && b.y <= inv.y + INVADER_H) {
          inv.alive = false;
          scoreRef.current += (4 - inv.type) * 10;
          setScore(scoreRef.current);
          const aliveCount = invadersRef.current.filter((i) => i.alive).length;
          invaderSpeedRef.current = 0.5 + (COLS * ROWS - aliveCount) * 0.05;
          spawnParticles(ix + INVADER_W / 2, inv.y + INVADER_H / 2, 'rgba(255, 140, 50, 0.9)', 8);
          return false;
        }
      }
      return true;
    });

    enemyBulletsRef.current = enemyBulletsRef.current.filter((b) => {
      if (b.x >= p.x - 15 && b.x <= p.x + 15 && b.y >= p.y - 6 && b.y <= p.y + 10) {
        setGameOver(true);
        setRunning(false);
        shakeRef.current = 12;
        if (loopRef.current) clearInterval(loopRef.current);
        return false;
      }
      return true;
    });

    for (const inv of invadersRef.current) {
      if (inv.alive && inv.y + INVADER_H >= p.y) {
        setGameOver(true);
        setRunning(false);
        if (loopRef.current) clearInterval(loopRef.current);
        break;
      }
    }

    draw();
  }, [draw, spawnParticles]);

  const start = () => {
    playerRef.current = { x: W / 2, y: H - 40 };
    bulletsRef.current = [];
    enemyBulletsRef.current = [];
    initInvaders();
    invaderDirRef.current = 1;
    invaderOffsetRef.current = 0;
    invaderSpeedRef.current = 0.5;
    scoreRef.current = 0;
    frameRef.current = 0;
    shakeRef.current = 0;
    particlesRef.current = [];
    muzzleFlashRef.current = 0;
    starsRef.current = Array.from({ length: 80 }, () => ({
      x: Math.random() * W,
      y: Math.random() * H,
      size: Math.random() * 2 + 0.5,
      speed: Math.random() * 1 + 0.3,
    }));
    setScore(0);
    setGameOver(false);
    setWon(false);
    setRunning(true);
    draw();
    if (loopRef.current) clearInterval(loopRef.current);
    loopRef.current = window.setInterval(tick, 1000 / 30);
  };

  useEffect(() => {
    const handleKey = (e: KeyboardEvent) => {
      if (running) {
        keysRef.current.add(e.key);
        if (['ArrowLeft', 'ArrowRight', ' ', 'a', 'd', 'A', 'D'].includes(e.key)) e.preventDefault();
      }
    };
    const handleKeyUp = (e: KeyboardEvent) => {
      keysRef.current.delete(e.key);
    };
    window.addEventListener('keydown', handleKey);
    window.addEventListener('keyup', handleKeyUp);
    return () => {
      window.removeEventListener('keydown', handleKey);
      window.removeEventListener('keyup', handleKeyUp);
      if (loopRef.current) clearInterval(loopRef.current);
    };
  }, [running]);

  useEffect(() => {
    if (gameOver) onScore('invaders', score);
    if (won) onScore('invaders', score + 300);
  }, [gameOver, won, score, onScore]);

  const handleTouch = (e: React.TouchEvent) => {
    if (!running) return;
    const canvas = canvasRef.current;
    if (!canvas) return;
    const rect = canvas.getBoundingClientRect();
    const scale = W / rect.width;
    playerRef.current.x = (e.touches[0].clientX - rect.left) * scale;
  };

  const handlePointerMove = (e: React.PointerEvent) => {
    if (!running) return;
    const canvas = canvasRef.current;
    if (!canvas) return;
    const rect = canvas.getBoundingClientRect();
    const scale = W / rect.width;
    playerRef.current.x = (e.clientX - rect.left) * scale;
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <button
          onClick={onExit}
          className="flex items-center gap-2 text-theme-muted hover:text-theme-text text-sm transition-colors"
        >
          <ArrowLeft className="w-4 h-4" /> Назад к играм
        </button>
        <div className="text-theme-text text-sm">
          Очки: <span className="font-bold text-theme-success">{score}</span>
        </div>
      </div>

      <div className="flex flex-col items-center gap-4">
        <canvas
          ref={canvasRef}
          width={W}
          height={H}
          className="rounded-xl border border-theme-border max-w-full h-auto touch-none"
          style={{ touchAction: 'none' }}
          onContextMenu={(e) => e.preventDefault()}
          onTouchMove={handleTouch}
          onTouchStart={handleTouch}
          onPointerMove={handlePointerMove}
          onPointerDown={handlePointerMove}
        />
        {(gameOver || won) && (
          <p className={`font-medium text-sm ${won ? 'text-theme-success' : 'text-theme-danger'}`}>
            {won ? 'Победа!' : 'Игра окончена!'} Финальный счёт: {score + (won ? 300 : 0)}
          </p>
        )}
        <button
          onClick={start}
          className="px-6 py-2.5 bg-theme-accent text-white rounded-xl text-sm font-medium hover:bg-theme-accent-hover transition-colors flex items-center gap-2"
        >
          <Play className="w-4 h-4" /> {gameOver || won ? 'Играть снова' : 'Начать игру'}
        </button>

        <p className="text-xs text-theme-muted">Управление: водите пальцем по экрану (или мышью на ПК)</p>
      </div>
    </div>
  );
}
