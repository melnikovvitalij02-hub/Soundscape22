import { useState, useRef, useEffect, useCallback } from 'react';
import { Play, ArrowLeft } from 'lucide-react';

type Bullet = { x: number; y: number; vy: number };
type Enemy = { x: number; y: number; vy: number; w: number; h: number };
type Star = { x: number; y: number; speed: number; size: number };
type Particle = { x: number; y: number; vx: number; vy: number; life: number; color: string };

const W = 400;
const H = 500;

export default function SpaceShooterGame({ onExit, onScore }: { onExit: () => void; onScore: (name: string, score: number) => void }) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [score, setScore] = useState(0);
  const [gameOver, setGameOver] = useState(false);
  const [running, setRunning] = useState(false);

  const playerRef = useRef({ x: W / 2, y: H - 60 });
  const bulletsRef = useRef<Bullet[]>([]);
  const enemiesRef = useRef<Enemy[]>([]);
  const starsRef = useRef<Star[]>([]);
  const keysRef = useRef<Set<string>>(new Set());
  const loopRef = useRef<number | null>(null);
  const scoreRef = useRef(0);
  const spawnTimerRef = useRef(0);
  const frameRef = useRef(0);

  // Visual effect refs
  const shakeRef = useRef(0);
  const particlesRef = useRef<Particle[]>([]);
  const trailRef = useRef<Particle[]>([]);

  const initStars = useCallback(() => {
    starsRef.current = Array.from({ length: 100 }, () => ({
      x: Math.random() * W,
      y: Math.random() * H,
      speed: Math.random() * 3 + 0.3,
      size: Math.random() * 2 + 0.5,
    }));
  }, []);

  const spawnParticles = useCallback((x: number, y: number, color: string, count: number) => {
    for (let i = 0; i < count; i++) {
      const angle = (Math.PI * 2 * i) / count + Math.random() * 0.3;
      particlesRef.current.push({
        x,
        y,
        vx: Math.cos(angle) * (Math.random() * 3 + 1),
        vy: Math.sin(angle) * (Math.random() * 3 + 1),
        life: 30,
        color,
      });
    }
  }, []);

  const draw = useCallback(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const shake = shakeRef.current;
    if (shake > 0) {
      ctx.save();
      ctx.translate(Math.random() * shake - shake / 2, Math.random() * shake - shake / 2);
      shakeRef.current -= 0.5;
    }

    // Darker gradient background
    const bgGrad = ctx.createLinearGradient(0, 0, 0, H);
    bgGrad.addColorStop(0, '#05050f');
    bgGrad.addColorStop(0.5, '#0a0a1e');
    bgGrad.addColorStop(1, '#020208');
    ctx.fillStyle = bgGrad;
    ctx.fillRect(0, 0, W, H);

    // Starfield with parallax (100 stars, varied speeds)
    starsRef.current.forEach((s) => {
      ctx.fillStyle = `rgba(255,255,255,${Math.min(1, s.size / 2.5)})`;
      ctx.fillRect(s.x, s.y, s.size, s.size);
      s.y += s.speed;
      if (s.y > H) {
        s.y = 0;
        s.x = Math.random() * W;
      }
    });

    // Engine trail particles
    trailRef.current = trailRef.current.filter((t) => t.life > 0);
    trailRef.current.forEach((t) => {
      ctx.fillStyle = t.color;
      ctx.globalAlpha = t.life / 20;
      ctx.beginPath();
      ctx.arc(t.x, t.y, 2.5, 0, Math.PI * 2);
      ctx.fill();
      t.x += t.vx;
      t.y += t.vy;
      t.life--;
    });
    ctx.globalAlpha = 1;

    const p = playerRef.current;

    // Player ship with pulsing cyan glow
    const pulse = 0.6 + Math.sin(frameRef.current * 0.1) * 0.2;
    ctx.font = '28px sans-serif';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.shadowColor = `rgba(0, 220, 255, ${pulse})`;
    ctx.shadowBlur = 12;
    ctx.fillText('🚀', p.x, p.y);
    ctx.shadowBlur = 0;

    // Bullets with yellow glow
    ctx.font = '12px sans-serif';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.shadowColor = 'rgba(255, 220, 50, 0.7)';
    ctx.shadowBlur = 8;
    bulletsRef.current.forEach((b) => {
      ctx.fillText('⭐', b.x, b.y);
    });
    ctx.shadowBlur = 0;

    // Enemies with orange glow
    ctx.font = '20px sans-serif';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.shadowColor = 'rgba(255, 120, 30, 0.7)';
    ctx.shadowBlur = 10;
    enemiesRef.current.forEach((e) => {
      ctx.fillText('🔥', e.x + e.w / 2, e.y + e.h / 2);
    });
    ctx.shadowBlur = 0;

    // Particles
    particlesRef.current = particlesRef.current.filter((pp) => pp.life > 0);
    particlesRef.current.forEach((pp) => {
      ctx.fillStyle = pp.color;
      ctx.globalAlpha = pp.life / 30;
      ctx.beginPath();
      ctx.arc(pp.x, pp.y, 3, 0, Math.PI * 2);
      ctx.fill();
      pp.x += pp.vx;
      pp.y += pp.vy;
      pp.vy += 0.1;
      pp.life--;
    });
    ctx.globalAlpha = 1;

    if (shake > 0) ctx.restore();
  }, []);

  const tick = useCallback(() => {
    frameRef.current++;
    const p = playerRef.current;
    const keys = keysRef.current;

    if (keys.has('ArrowLeft') || keys.has('a') || keys.has('A')) p.x -= 5;
    if (keys.has('ArrowRight') || keys.has('d') || keys.has('D')) p.x += 5;
    p.x = Math.max(15, Math.min(W - 15, p.x));

    // Engine trail particles
    trailRef.current.push({
      x: p.x + (Math.random() - 0.5) * 8,
      y: p.y + 14,
      vx: (Math.random() - 0.5) * 0.5,
      vy: Math.random() * 2 + 1,
      life: 20,
      color: 'rgba(0, 220, 255, 0.6)',
    });

    if (frameRef.current % 12 === 0) {
      bulletsRef.current.push({ x: p.x, y: p.y - 15, vy: -8 });
    }

    bulletsRef.current = bulletsRef.current.filter((b) => {
      b.y += b.vy;
      return b.y > -10;
    });

    spawnTimerRef.current++;
    if (spawnTimerRef.current > 40) {
      spawnTimerRef.current = 0;
      enemiesRef.current.push({
        x: Math.random() * (W - 30),
        y: -25,
        vy: 1.5 + scoreRef.current / 500,
        w: 24,
        h: 20,
      });
    }

    enemiesRef.current = enemiesRef.current.filter((e) => {
      e.y += e.vy;
      return e.y < H + 30;
    });

    const remainingEnemies: Enemy[] = [];
    enemiesRef.current.forEach((e) => {
      let hit = false;
      bulletsRef.current = bulletsRef.current.filter((b) => {
        if (b.x >= e.x && b.x <= e.x + e.w && b.y >= e.y && b.y <= e.y + e.h) {
          hit = true;
          return false;
        }
        return true;
      });
      if (hit) {
        scoreRef.current += 10;
        setScore(scoreRef.current);
        spawnParticles(e.x + e.w / 2, e.y + e.h / 2, 'rgba(255, 100, 30, 0.9)', 10);
      } else {
        remainingEnemies.push(e);
      }
    });
    enemiesRef.current = remainingEnemies;

    for (const e of enemiesRef.current) {
      if (p.x >= e.x - 12 && p.x <= e.x + e.w + 12 && p.y >= e.y - 10 && p.y <= e.y + e.h + 10) {
        setGameOver(true);
        setRunning(false);
        shakeRef.current = 10;
        spawnParticles(p.x, p.y, 'rgba(255, 80, 30, 0.9)', 12);
        if (loopRef.current) clearInterval(loopRef.current);
        break;
      }
    }

    draw();
  }, [draw, spawnParticles]);

  const start = () => {
    playerRef.current = { x: W / 2, y: H - 60 };
    bulletsRef.current = [];
    enemiesRef.current = [];
    initStars();
    scoreRef.current = 0;
    spawnTimerRef.current = 0;
    frameRef.current = 0;
    shakeRef.current = 0;
    particlesRef.current = [];
    trailRef.current = [];
    setScore(0);
    setGameOver(false);
    setRunning(true);
    draw();
    if (loopRef.current) clearInterval(loopRef.current);
    loopRef.current = window.setInterval(tick, 1000 / 30);
  };

  useEffect(() => {
    const handleKey = (e: KeyboardEvent) => {
      if (running) {
        keysRef.current.add(e.key);
        if (['ArrowLeft', 'ArrowRight', 'a', 'd', 'A', 'D'].includes(e.key)) e.preventDefault();
      }
    };
    const handleKeyUp = (e: KeyboardEvent) => {
      keysRef.current.delete(e.key);
    };
    window.addEventListener('keydown', handleKey);
    window.addEventListener('keyup', handleKeyUp);
    return () => {
      window.removeEventListener('keydown', handleKey);
      window.removeEventListener('keyup', handleKeyUp);
      if (loopRef.current) clearInterval(loopRef.current);
    };
  }, [running]);

  useEffect(() => {
    if (gameOver) onScore('shooter', score);
  }, [gameOver, score, onScore]);

  const handleTouch = (e: React.TouchEvent) => {
    if (!running) return;
    const canvas = canvasRef.current;
    if (!canvas) return;
    const rect = canvas.getBoundingClientRect();
    const scale = W / rect.width;
    playerRef.current.x = (e.touches[0].clientX - rect.left) * scale;
  };

  const handlePointerMove = (e: React.PointerEvent) => {
    if (!running) return;
    const canvas = canvasRef.current;
    if (!canvas) return;
    const rect = canvas.getBoundingClientRect();
    const scale = W / rect.width;
    playerRef.current.x = (e.clientX - rect.left) * scale;
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <button
          onClick={onExit}
          className="flex items-center gap-2 text-theme-muted hover:text-theme-text text-sm transition-colors"
        >
          <ArrowLeft className="w-4 h-4" /> Назад к играм
        </button>
        <div className="text-theme-text text-sm">
          Очки: <span className="font-bold text-theme-success">{score}</span>
        </div>
      </div>

      <div className="flex flex-col items-center gap-4">
        <canvas
          ref={canvasRef}
          width={W}
          height={H}
          className="rounded-xl border border-theme-border max-w-full h-auto touch-none"
          style={{ touchAction: 'none' }}
          onContextMenu={(e) => e.preventDefault()}
          onTouchMove={handleTouch}
          onTouchStart={handleTouch}
          onPointerMove={handlePointerMove}
          onPointerDown={handlePointerMove}
        />
        {gameOver && (
          <p className="text-theme-danger font-medium text-sm">Игра окончена! Финальный счёт: {score}</p>
        )}
        <button
          onClick={start}
          className="px-6 py-2.5 bg-theme-success text-white rounded-xl text-sm font-medium hover:bg-theme-success/90 transition-colors flex items-center gap-2"
        >
          <Play className="w-4 h-4" /> {gameOver ? 'Играть снова' : 'Начать игру'}
        </button>

        <p className="text-xs text-theme-muted">Управление: водите пальцем по экрану (или мышью на ПК)</p>
      </div>
    </div>
  );
}
