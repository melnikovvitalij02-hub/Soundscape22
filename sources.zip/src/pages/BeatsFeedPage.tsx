import { useState, useRef, useEffect, useCallback, useMemo } from 'react';
import { useAuth } from '@/context/AuthContext';
import { supabase } from '@/lib/supabase';
import type { Page } from '@/components/Sidebar';
import {
  Heart,
  MessageCircle,
  Mic,
  Coins,
  GitFork,
  Play,
  Pause,
  Send,
  Loader2,
  X,
  Music,
  TrendingUp,
} from 'lucide-react';

type TrackType = 'kick' | 'snare' | 'hihat' | 'openhat' | 'clap' | 'tom' | 'bass' | 'synth' | 'pad';

type Beat = {
  id: string;
  user_id: string;
  title: string;
  genre: string;
  bpm: number;
  audio_url: string | null;
  cover_url: string | null;
  play_count: number;
  created_at: string;
  creator?: {
    username: string;
    avatar_url: string | null;
  } | null;
};

type BeatComment = {
  id: string;
  beat_id: string;
  user_id: string;
  username: string;
  avatar_url: string | null;
  content: string;
  created_at: string;
};

type VoiceComment = {
  id: string;
  beat_id: string;
  user_id: string;
  username: string;
  avatar_url: string | null;
  audio_url: string;
  duration: number;
  created_at: string;
};

const PAGE_SIZE = 5;

const FAKE_REVIEWS: { user: string; text: string; avatar: string }[] = [
  { user: 'ДимаБит', text: 'Огонь! Бас качает, прямо в душу. Слушаю на репите весь день.', avatar: 'Д' },
  { user: 'МашаСаунд', text: 'Очень крутой вайб, добавила в избранное. Жду новых релизов!', avatar: 'М' },
  { user: 'Гость_228', text: 'Норм, но снейр можно погромче. В остальном — топ.', avatar: 'Г' },
  { user: 'LunaBeat', text: 'Атмосфера просто космос. Под такой бит пишется текст сам собой.', avatar: 'L' },
  { user: 'ProMaker', text: 'Чисто, плотно, профессионально. Респект автору за работу.', avatar: 'P' },
];

// Reuse makeSound approach from BeatComposerPage
function makeSound(ctx: AudioContext, type: TrackType, time: number, volume: number) {
  const gain = ctx.createGain();
  gain.connect(ctx.destination);
  gain.gain.value = volume;

  switch (type) {
    case 'kick': {
      const osc = ctx.createOscillator();
      osc.frequency.setValueAtTime(150, time);
      osc.frequency.exponentialRampToValueAtTime(0.01, time + 0.5);
      gain.gain.setValueAtTime(volume, time);
      gain.gain.exponentialRampToValueAtTime(0.01, time + 0.5);
      osc.connect(gain);
      osc.start(time);
      osc.stop(time + 0.5);
      break;
    }
    case 'snare': {
      const noise = ctx.createBufferSource();
      const buffer = ctx.createBuffer(1, 4410, 44100);
      const data = buffer.getChannelData(0);
      for (let i = 0; i < 4410; i++) data[i] = Math.random() * 2 - 1;
      noise.buffer = buffer;
      const filter = ctx.createBiquadFilter();
      filter.type = 'highpass';
      filter.frequency.value = 1000;
      noise.connect(filter);
      filter.connect(gain);
      gain.gain.setValueAtTime(volume, time);
      gain.gain.exponentialRampToValueAtTime(0.01, time + 0.2);
      noise.start(time);
      noise.stop(time + 0.2);
      break;
    }
    case 'hihat': {
      const noise = ctx.createBufferSource();
      const buffer = ctx.createBuffer(1, 2205, 44100);
      const data = buffer.getChannelData(0);
      for (let i = 0; i < 2205; i++) data[i] = Math.random() * 2 - 1;
      noise.buffer = buffer;
      const filter = ctx.createBiquadFilter();
      filter.type = 'highpass';
      filter.frequency.value = 7000;
      noise.connect(filter);
      filter.connect(gain);
      gain.gain.setValueAtTime(volume, time);
      gain.gain.exponentialRampToValueAtTime(0.01, time + 0.05);
      noise.start(time);
      noise.stop(time + 0.05);
      break;
    }
    case 'openhat': {
      const noise = ctx.createBufferSource();
      const buffer = ctx.createBuffer(1, 22050, 44100);
      const data = buffer.getChannelData(0);
      for (let i = 0; i < 22050; i++) data[i] = Math.random() * 2 - 1;
      noise.buffer = buffer;
      const filter = ctx.createBiquadFilter();
      filter.type = 'highpass';
      filter.frequency.value = 7000;
      noise.connect(filter);
      filter.connect(gain);
      gain.gain.setValueAtTime(volume, time);
      gain.gain.exponentialRampToValueAtTime(0.01, time + 0.3);
      noise.start(time);
      noise.stop(time + 0.3);
      break;
    }
    case 'clap': {
      for (let i = 0; i < 3; i++) {
        const noise = ctx.createBufferSource();
        const buffer = ctx.createBuffer(1, 2205, 44100);
        const data = buffer.getChannelData(0);
        for (let j = 0; j < 2205; j++) data[j] = Math.random() * 2 - 1;
        noise.buffer = buffer;
        const filter = ctx.createBiquadFilter();
        filter.type = 'bandpass';
        filter.frequency.value = 1500;
        noise.connect(filter);
        filter.connect(gain);
        gain.gain.setValueAtTime(volume, time + i * 0.01);
        gain.gain.exponentialRampToValueAtTime(0.01, time + i * 0.01 + 0.1);
        noise.start(time + i * 0.01);
        noise.stop(time + i * 0.01 + 0.1);
      }
      break;
    }
    case 'tom': {
      const osc = ctx.createOscillator();
      osc.frequency.setValueAtTime(200, time);
      osc.frequency.exponentialRampToValueAtTime(80, time + 0.3);
      gain.gain.setValueAtTime(volume, time);
      gain.gain.exponentialRampToValueAtTime(0.01, time + 0.3);
      osc.connect(gain);
      osc.start(time);
      osc.stop(time + 0.3);
      break;
    }
    case 'bass': {
      const osc = ctx.createOscillator();
      osc.type = 'sawtooth';
      osc.frequency.setValueAtTime(80, time);
      const filter = ctx.createBiquadFilter();
      filter.type = 'lowpass';
      filter.frequency.value = 500;
      osc.connect(filter);
      filter.connect(gain);
      gain.gain.setValueAtTime(volume, time);
      gain.gain.exponentialRampToValueAtTime(0.01, time + 0.3);
      osc.start(time);
      osc.stop(time + 0.3);
      break;
    }
    case 'synth': {
      const osc = ctx.createOscillator();
      osc.type = 'square';
      osc.frequency.setValueAtTime(440, time);
      const filter = ctx.createBiquadFilter();
      filter.type = 'lowpass';
      filter.frequency.value = 2000;
      osc.connect(filter);
      filter.connect(gain);
      gain.gain.setValueAtTime(volume * 0.3, time);
      gain.gain.exponentialRampToValueAtTime(0.01, time + 0.2);
      osc.start(time);
      osc.stop(time + 0.2);
      break;
    }
    case 'pad': {
      const osc = ctx.createOscillator();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(220, time);
      gain.gain.setValueAtTime(volume * 0.2, time);
      gain.gain.linearRampToValueAtTime(volume * 0.2, time + 0.1);
      gain.gain.exponentialRampToValueAtTime(0.01, time + 0.5);
      osc.connect(gain);
      osc.start(time);
      osc.stop(time + 0.5);
      break;
    }
  }
}

// Simple generated beat pattern based on genre/bpm for playback
function buildPattern(genre: string): (TrackType | false)[][] {
  const patterns: Record<string, (TrackType | false)[][]> = {
    'Хип-Хоп': [
      ['kick', false, false, false, 'kick', false, false, false, 'kick', false, false, false, 'kick', false, false, false],
      ['snare', false, false, false, 'snare', false, false, false, 'snare', false, false, false, 'snare', false, false, false],
      ['hihat', false, 'hihat', false, 'hihat', false, 'hihat', false, 'hihat', false, 'hihat', false, 'hihat', false, 'hihat', false],
    ],
    Трэп: [
      ['kick', false, false, false, false, false, 'kick', false, 'kick', false, false, false, false, false, false, false],
      ['snare', false, false, false, 'snare', false, false, false, 'snare', false, false, false, 'snare', false, false, false],
      ['hihat', 'hihat', 'hihat', 'hihat', 'hihat', 'hihat', 'hihat', 'hihat', 'hihat', 'hihat', 'hihat', 'hihat', 'hihat', 'hihat', 'hihat', 'hihat'],
    ],
    House: [
      ['kick', false, false, false, 'kick', false, false, false, 'kick', false, false, false, 'kick', false, false, false],
      ['hihat', false, 'hihat', false, 'hihat', false, 'hihat', false, 'hihat', false, 'hihat', false, 'hihat', false, 'hihat', false],
      ['bass', false, false, false, 'bass', false, false, false, 'bass', false, false, false, 'bass', false, false, false],
    ],
  };
  return patterns[genre] || patterns['Хип-Хоп'];
}

export default function BeatsFeedPage({ setPage }: { setPage: (p: Page) => void }) {
  const { profile, addCoins, addXp, refreshProfile } = useAuth();
  const [beats, setBeats] = useState<Beat[]>([]);
  const [loading, setLoading] = useState(false);
  const [hasMore, setHasMore] = useState(true);
  const [page, setPageNum] = useState(0);
  const [playingId, setPlayingId] = useState<string | null>(null);
  const [likedBeats, setLikedBeats] = useState<Set<string>>(new Set());
  const [likeCounts, setLikeCounts] = useState<Record<string, number>>({});
  const [expandedComments, setExpandedComments] = useState<Set<string>>(new Set());
  const [commentsByBeat, setCommentsByBeat] = useState<Record<string, BeatComment[]>>({});
  const [voiceCommentsByBeat, setVoiceCommentsByBeat] = useState<Record<string, VoiceComment[]>>({});
  const [commentInputs, setCommentInputs] = useState<Record<string, string>>({});
  const [recordingBeatId, setRecordingBeatId] = useState<string | null>(null);
  const [recordSecs, setRecordSecs] = useState(0);
  const [supportMsg, setSupportMsg] = useState<Record<string, string>>({});
  const [showRemixFor, setShowRemixFor] = useState<string | null>(null);
  const [remixTitle, setRemixTitle] = useState('');
  const [remixUrl, setRemixUrl] = useState('');
  const [status, setStatus] = useState<string | null>(null);

  const audioCtxRef = useRef<AudioContext | null>(null);
  const intervalRef = useRef<number | null>(null);
  const stepRef = useRef(0);
  const playingPatternRef = useRef<{ pattern: (TrackType | false)[][]; bpm: number } | null>(null);
  const sentinelRef = useRef<HTMLDivElement | null>(null);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const audioChunksRef = useRef<Blob[]>([]);
  const recordTimerRef = useRef<number | null>(null);

  const getCtx = useCallback(() => {
    if (!audioCtxRef.current) audioCtxRef.current = new AudioContext();
    return audioCtxRef.current;
  }, []);

  const stopPlayback = useCallback(() => {
    if (intervalRef.current) {
      clearInterval(intervalRef.current);
      intervalRef.current = null;
    }
    setPlayingId(null);
    stepRef.current = 0;
    playingPatternRef.current = null;
  }, []);

  const playBeat = useCallback((beat: Beat) => {
    if (playingId === beat.id) {
      stopPlayback();
      return;
    }
    if (intervalRef.current) {
      clearInterval(intervalRef.current);
      intervalRef.current = null;
    }
    const ctx = getCtx();
    if (ctx.state === 'suspended') ctx.resume();
    const pattern = buildPattern(beat.genre);
    playingPatternRef.current = { pattern, bpm: beat.bpm || 120 };
    stepRef.current = 0;
    setPlayingId(beat.id);

    const stepDuration = 60000 / (beat.bpm || 120) / 4;
    const tick = () => {
      const step = stepRef.current;
      const time = ctx.currentTime;
      pattern.forEach((track) => {
        const hit = track[step];
        if (typeof hit === 'string') {
          makeSound(ctx, hit as TrackType, time, 0.5);
        }
      });
      stepRef.current = (step + 1) % 16;
    };
    tick();
    intervalRef.current = window.setInterval(tick, stepDuration);

    // increment play count
    supabase
      .from('beats')
      .update({ play_count: (beat.play_count || 0) + 1 })
      .eq('id', beat.id)
      .then(() => {
        setBeats((prev) =>
          prev.map((b) => (b.id === beat.id ? { ...b, play_count: (b.play_count || 0) + 1 } : b))
        );
      });
    addXp(2);
  }, [playingId, getCtx, stopPlayback, addXp]);

  const fetchBeats = useCallback(async (pageNum: number): Promise<Beat[]> => {
    const from = pageNum * PAGE_SIZE;
    const to = from + PAGE_SIZE - 1;
    const { data, error } = await supabase
      .from('beats')
      .select(
        `id, user_id, title, genre, bpm, audio_url, cover_url, play_count, created_at, creator:profiles!beats_user_id_fkey(username, avatar_url)`
      )
      .order('created_at', { ascending: false })
      .range(from, to);
    if (error) {
      console.error('fetchBeats error', error);
      return [];
    }
    return (data || []) as unknown as Beat[];
  }, []);

  const loadMore = useCallback(async () => {
    if (loading || !hasMore) return;
    setLoading(true);
    const next = page + 1;
    const newBeats = await fetchBeats(next);
    if (newBeats.length === 0) {
      setHasMore(false);
    } else {
      setBeats((prev) => [...prev, ...newBeats]);
      setPageNum(next);
    }
    setLoading(false);
  }, [loading, hasMore, page, fetchBeats]);

  // initial load
  useEffect(() => {
    let active = true;
    (async () => {
      setLoading(true);
      const initial = await fetchBeats(0);
      if (active) {
        setBeats(initial);
        setPageNum(0);
        setHasMore(initial.length === PAGE_SIZE);
        setLoading(false);
      }
    })();
    return () => {
      active = false;
    };
  }, [fetchBeats]);

  // load likes for current beats
  useEffect(() => {
    if (!profile || beats.length === 0) return;
    const beatIds = beats.map((b) => b.id);
    (async () => {
      const { data: myLikes } = await supabase
        .from('beat_likes')
        .select('beat_id')
        .eq('user_id', profile.id)
        .in('beat_id', beatIds);
      if (myLikes) {
        setLikedBeats((prev) => {
          const next = new Set(prev);
          myLikes.forEach((l) => next.add(l.beat_id));
          return next;
        });
      }
      const { data: counts } = await supabase
        .from('beat_likes')
        .select('beat_id')
        .in('beat_id', beatIds);
      if (counts) {
        const map: Record<string, number> = {};
        counts.forEach((c) => {
          map[c.beat_id] = (map[c.beat_id] || 0) + 1;
        });
        setLikeCounts((prev) => ({ ...prev, ...map }));
      }
    })();
  }, [profile, beats]);

  // infinite scroll observer
  useEffect(() => {
    const node = sentinelRef.current;
    if (!node) return;
    const observer = new IntersectionObserver(
      (entries) => {
        if (entries[0].isIntersecting) loadMore();
      },
      { rootMargin: '200px' }
    );
    observer.observe(node);
    return () => observer.disconnect();
  }, [loadMore]);

  useEffect(() => () => stopPlayback(), [stopPlayback]);

  const toggleLike = async (beat: Beat) => {
    if (!profile) return;
    const isLiked = likedBeats.has(beat.id);
    if (isLiked) {
      await supabase.from('beat_likes').delete().eq('beat_id', beat.id).eq('user_id', profile.id);
      setLikedBeats((prev) => {
        const next = new Set(prev);
        next.delete(beat.id);
        return next;
      });
      setLikeCounts((prev) => ({ ...prev, [beat.id]: Math.max(0, (prev[beat.id] || 0) - 1) }));
    } else {
      await supabase.from('beat_likes').insert({ beat_id: beat.id, user_id: profile.id });
      setLikedBeats((prev) => new Set(prev).add(beat.id));
      setLikeCounts((prev) => ({ ...prev, [beat.id]: (prev[beat.id] || 0) + 1 }));
      addXp(1);
    }
  };

  const toggleComments = async (beatId: string) => {
    if (expandedComments.has(beatId)) {
      setExpandedComments((prev) => {
        const next = new Set(prev);
        next.delete(beatId);
        return next;
      });
      return;
    }
    setExpandedComments((prev) => new Set(prev).add(beatId));
    const [textRes, voiceRes] = await Promise.all([
      supabase
        .from('beat_comments')
        .select('*')
        .eq('beat_id', beatId)
        .order('created_at', { ascending: false }),
      supabase
        .from('voice_comments')
        .select('*')
        .eq('beat_id', beatId)
        .order('created_at', { ascending: false }),
    ]);
    if (textRes.data) setCommentsByBeat((prev) => ({ ...prev, [beatId]: textRes.data as BeatComment[] }));
    if (voiceRes.data) setVoiceCommentsByBeat((prev) => ({ ...prev, [beatId]: voiceRes.data as VoiceComment[] }));
  };

  const submitComment = async (beatId: string) => {
    if (!profile) return;
    const content = (commentInputs[beatId] || '').trim();
    if (!content) return;
    const { data, error } = await supabase
      .from('beat_comments')
      .insert({
        beat_id: beatId,
        user_id: profile.id,
        username: profile.username,
        avatar_url: profile.avatar_url,
        content,
      })
      .select('*')
      .maybeSingle();
    if (error) {
      setStatus('Ошибка при отправке комментария');
      return;
    }
    if (data) {
      setCommentsByBeat((prev) => ({
        ...prev,
        [beatId]: [data as BeatComment, ...(prev[beatId] || [])],
      }));
    }
    setCommentInputs((prev) => ({ ...prev, [beatId]: '' }));
    addXp(2);
  };

  const startRecording = async (beatId: string) => {
    if (!profile) return;
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const recorder = new MediaRecorder(stream);
      audioChunksRef.current = [];
      recorder.ondataavailable = (e: BlobEvent) => {
        if (e.data.size > 0) audioChunksRef.current.push(e.data);
      };
      recorder.onstop = async () => {
        stream.getTracks().forEach((t) => t.stop());
        const blob = new Blob(audioChunksRef.current, { type: 'audio/webm' });
        const duration = recordSecs;
        const fileName = `voice_${profile.id}_${Date.now()}.webm`;
        const { error: upErr } = await supabase.storage
          .from('voice-comments')
          .upload(fileName, blob, { contentType: 'audio/webm' });
        if (upErr) {
          setStatus('Ошибка загрузки голосового комментария');
          return;
        }
        const { data: pub } = supabase.storage.from('voice-comments').getPublicUrl(fileName);
        const { error: insErr } = await supabase.from('voice_comments').insert({
          beat_id: beatId,
          user_id: profile.id,
          username: profile.username,
          avatar_url: profile.avatar_url,
          audio_url: pub.publicUrl,
          duration,
        });
        if (insErr) {
          setStatus('Ошибка сохранения голосового комментария');
          return;
        }
        // refresh voice comments
        const { data: vc } = await supabase
          .from('voice_comments')
          .select('*')
          .eq('beat_id', beatId)
          .order('created_at', { ascending: false });
        if (vc) setVoiceCommentsByBeat((prev) => ({ ...prev, [beatId]: vc as VoiceComment[] }));
        addXp(5);
        setStatus('Голосовой комментарий добавлен');
      };
      recorder.start();
      mediaRecorderRef.current = recorder;
      setRecordingBeatId(beatId);
      setRecordSecs(0);
      recordTimerRef.current = window.setInterval(() => {
        setRecordSecs((s) => s + 1);
      }, 1000);
    } catch {
      setStatus('Нет доступа к микрофону');
    }
  };

  const stopRecording = () => {
    if (mediaRecorderRef.current && mediaRecorderRef.current.state !== 'inactive') {
      mediaRecorderRef.current.stop();
    }
    mediaRecorderRef.current = null;
    setRecordingBeatId(null);
    if (recordTimerRef.current) {
      clearInterval(recordTimerRef.current);
      recordTimerRef.current = null;
    }
  };

  const support = async (beat: Beat) => {
    if (!profile) return;
    if ((profile.coins || 0) < 10) {
      setStatus('Недостаточно монет для поддержки');
      return;
    }
    const msg = (supportMsg[beat.id] || '').trim();
    const { error } = await supabase.from('support_donations').insert({
      supporter_id: profile.id,
      creator_id: beat.user_id,
      amount: 10,
      message: msg,
    });
    if (error) {
      setStatus('Ошибка при поддержке');
      return;
    }
    await addCoins(-10);
    await refreshProfile();
    setSupportMsg((prev) => ({ ...prev, [beat.id]: '' }));
    setStatus('Поддержка отправлена! Автор получил 10 монет');
    setTimeout(() => setStatus(null), 2500);
  };

  const submitRemix = async (beat: Beat) => {
    if (!profile) return;
    if (!remixTitle.trim() || !remixUrl.trim()) {
      setStatus('Заполните название и ссылку на ремикс');
      return;
    }
    const { error } = await supabase.from('remixes').insert({
      original_beat_id: beat.id,
      remixer_id: profile.id,
      title: remixTitle.trim(),
      audio_url: remixUrl.trim(),
    });
    if (error) {
      setStatus('Ошибка при создании ремикса');
      return;
    }
    setShowRemixFor(null);
    setRemixTitle('');
    setRemixUrl('');
    await addXp(20);
    setStatus('Ремикс создан! +20 XP');
    setTimeout(() => setStatus(null), 2500);
  };

  const coverFor = (b: Beat) => b.cover_url || '/cover-igotu.webp';

  const formatTime = (s: number) => {
    const m = Math.floor(s / 60);
    const sec = Math.floor(s % 60);
    return `${m}:${sec.toString().padStart(2, '0')}`;
  };

  const playingBeat = useMemo(() => beats.find((b) => b.id === playingId) || null, [beats, playingId]);

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-theme-text flex items-center gap-2">
            <Music className="w-6 h-6 text-theme-primary" />
            Лента битов
          </h1>
          <p className="text-theme-muted text-sm mt-1">
            Свежие биты от сообщества — слушай, комментируй, поддерживай
          </p>
        </div>
        <button
          onClick={() => setPage('beat')}
          className="px-4 py-2 bg-theme-primary text-white rounded-lg text-sm font-medium hover:bg-theme-primary-hover transition-colors flex items-center gap-2"
        >
          <TrendingUp className="w-4 h-4" /> Создать бит
        </button>
      </div>

      {status && (
        <div className="px-4 py-2 rounded-lg bg-theme-primary-bg border border-theme-primary-border text-theme-primary-text text-sm">
          {status}
        </div>
      )}

      {beats.length === 0 && !loading && (
        <div className="glass-surface bg-theme-surface/50 border border-theme-border rounded-2xl p-8 text-center">
          <p className="text-theme-muted">Пока нет битов. Будь первым!</p>
        </div>
      )}

      <div className="space-y-4">
        {beats.map((beat) => {
          const isLiked = likedBeats.has(beat.id);
          const likeCount = likeCounts[beat.id] || 0;
          const commentsOpen = expandedComments.has(beat.id);
          const comments = commentsByBeat[beat.id] || [];
          const voiceComments = voiceCommentsByBeat[beat.id] || [];
          const isPlaying = playingId === beat.id;
          return (
            <div
              key={beat.id}
              className="glass-surface bg-theme-surface/60 border border-theme-border rounded-2xl overflow-hidden"
            >
              <div className="flex gap-4 p-4">
                {/* Cover + play */}
                <div className="relative w-28 h-28 rounded-xl overflow-hidden shrink-0 bg-theme-surface2">
                  <img src={coverFor(beat)} alt={beat.title} className="w-full h-full object-cover" />
                  <button
                    onClick={() => playBeat(beat)}
                    className="absolute inset-0 bg-black/40 flex items-center justify-center opacity-0 hover:opacity-100 transition-opacity"
                  >
                    {isPlaying ? (
                      <Pause className="w-8 h-8 text-white" />
                    ) : (
                      <Play className="w-8 h-8 text-white" fill="white" />
                    )}
                  </button>
                  {isPlaying && (
                    <div className="absolute bottom-2 right-2 flex gap-0.5 items-end h-4">
                      <div className="w-1 bg-theme-primary rounded-full animate-pulse" style={{ height: '60%' }} />
                      <div className="w-1 bg-theme-primary rounded-full animate-pulse" style={{ height: '100%', animationDelay: '0.1s' }} />
                      <div className="w-1 bg-theme-primary rounded-full animate-pulse" style={{ height: '40%', animationDelay: '0.2s' }} />
                    </div>
                  )}
                </div>

                {/* Info */}
                <div className="flex-1 min-w-0">
                  <div className="flex items-start justify-between gap-2">
                    <div className="min-w-0">
                      <h3 className="text-theme-text font-semibold truncate">{beat.title}</h3>
                      <div className="flex items-center gap-2 mt-1">
                        {beat.creator?.avatar_url ? (
                          <img src={beat.creator.avatar_url} alt="" className="w-5 h-5 rounded-full object-cover" />
                        ) : (
                          <div className="w-5 h-5 rounded-full bg-gradient-to-br from-theme-primary to-theme-accent flex items-center justify-center text-white text-[10px] font-bold">
                            {beat.creator?.username?.[0]?.toUpperCase() || '?'}
                          </div>
                        )}
                        <span className="text-xs text-theme-muted truncate">{beat.creator?.username || 'Аноним'}</span>
                      </div>
                    </div>
                    <div className="flex items-center gap-2 shrink-0 text-xs text-theme-muted">
                      <span className="px-2 py-0.5 rounded-md bg-theme-surface2">{beat.genre}</span>
                      <span className="font-mono">{beat.bpm} BPM</span>
                      <span>· {beat.play_count || 0} ▶</span>
                    </div>
                  </div>

                  {/* Actions */}
                  <div className="flex flex-wrap items-center gap-2 mt-3">
                    <button
                      onClick={() => toggleLike(beat)}
                      className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium transition-colors ${
                        isLiked
                          ? 'bg-theme-danger/15 text-theme-danger'
                          : 'bg-theme-surface2 text-theme-muted hover:text-theme-text'
                      }`}
                    >
                      <Heart className="w-4 h-4" fill={isLiked ? 'currentColor' : 'none'} />
                      {likeCount}
                    </button>
                    <button
                      onClick={() => toggleComments(beat.id)}
                      className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium bg-theme-surface2 text-theme-muted hover:text-theme-text transition-colors"
                    >
                      <MessageCircle className="w-4 h-4" />
                      {comments.length + voiceComments.length}
                    </button>
                    <button
                      onClick={() => startRecording(beat.id)}
                      disabled={recordingBeatId !== null}
                      className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium bg-theme-surface2 text-theme-muted hover:text-theme-text transition-colors disabled:opacity-50"
                    >
                      <Mic className="w-4 h-4" />
                      {recordingBeatId === beat.id ? `Запись ${formatTime(recordSecs)}` : 'Голос'}
                    </button>
                    <button
                      onClick={() => support(beat)}
                      className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium bg-theme-surface2 text-theme-muted hover:text-theme-warning transition-colors"
                    >
                      <Coins className="w-4 h-4" />
                      Поддержать
                    </button>
                    <button
                      onClick={() => setShowRemixFor(beat.id)}
                      className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium bg-theme-surface2 text-theme-muted hover:text-theme-primary transition-colors"
                    >
                      <GitFork className="w-4 h-4" />
                      Ремикс
                    </button>
                    {isPlaying && (
                      <button
                        onClick={stopPlayback}
                        className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium bg-theme-danger text-white transition-colors"
                      >
                        <Pause className="w-4 h-4" /> Стоп
                      </button>
                    )}
                  </div>

                  {/* Support message input */}
                  <input
                    value={supportMsg[beat.id] || ''}
                    onChange={(e) => setSupportMsg((prev) => ({ ...prev, [beat.id]: e.target.value }))}
                    onKeyDown={(e) => {
                      if (e.key === 'Enter') support(beat);
                    }}
                    placeholder="Сообщение автору (10 монет)..."
                    className="mt-2 w-full px-3 py-1.5 bg-theme-surface2 border border-theme-border rounded-lg text-theme-text text-xs focus:outline-none focus:border-theme-primary"
                  />
                </div>
              </div>

              {/* Recording controls */}
              {recordingBeatId === beat.id && (
                <div className="px-4 pb-3 flex items-center gap-3">
                  <div className="flex items-center gap-2 text-xs text-theme-danger">
                    <span className="w-2 h-2 rounded-full bg-theme-danger animate-pulse" />
                    Запись... {formatTime(recordSecs)}
                  </div>
                  <button
                    onClick={stopRecording}
                    className="px-3 py-1.5 bg-theme-danger text-white rounded-lg text-xs font-medium"
                  >
                    Остановить
                  </button>
                </div>
              )}

              {/* Comments */}
              {commentsOpen && (
                <div className="px-4 pb-4 border-t border-theme-border pt-3 space-y-3">
                  {/* Add comment */}
                  <div className="flex items-center gap-2">
                    <input
                      value={commentInputs[beat.id] || ''}
                      onChange={(e) => setCommentInputs((prev) => ({ ...prev, [beat.id]: e.target.value }))}
                      onKeyDown={(e) => {
                        if (e.key === 'Enter') submitComment(beat.id);
                      }}
                      placeholder="Написать комментарий..."
                      className="flex-1 px-3 py-2 bg-theme-surface2 border border-theme-border rounded-lg text-theme-text text-sm focus:outline-none focus:border-theme-primary"
                    />
                    <button
                      onClick={() => submitComment(beat.id)}
                      className="p-2 bg-theme-primary text-white rounded-lg hover:bg-theme-primary-hover transition-colors"
                    >
                      <Send className="w-4 h-4" />
                    </button>
                  </div>

                  {/* Voice comments */}
                  {voiceComments.length > 0 && (
                    <div className="space-y-2">
                      <p className="text-xs text-theme-muted uppercase tracking-wider">Голосовые комментарии</p>
                      {voiceComments.map((vc) => (
                        <div key={vc.id} className="flex items-center gap-2 p-2 bg-theme-surface2 rounded-lg">
                          {vc.avatar_url ? (
                            <img src={vc.avatar_url} alt="" className="w-6 h-6 rounded-full object-cover" />
                          ) : (
                            <div className="w-6 h-6 rounded-full bg-gradient-to-br from-theme-primary to-theme-accent flex items-center justify-center text-white text-[10px] font-bold">
                              {vc.username?.[0]?.toUpperCase() || '?'}
                            </div>
                          )}
                          <span className="text-xs text-theme-muted">{vc.username}</span>
                          <audio controls src={vc.audio_url} className="h-7 flex-1" />
                          <span className="text-xs text-theme-muted font-mono">{formatTime(vc.duration)}</span>
                        </div>
                      ))}
                    </div>
                  )}

                  {/* Text comments */}
                  {comments.length > 0 ? (
                    <div className="space-y-2">
                      {comments.map((c) => (
                        <div key={c.id} className="flex gap-2 p-2 bg-theme-surface2 rounded-lg">
                          {c.avatar_url ? (
                            <img src={c.avatar_url} alt="" className="w-6 h-6 rounded-full object-cover shrink-0" />
                          ) : (
                            <div className="w-6 h-6 rounded-full bg-gradient-to-br from-theme-primary to-theme-accent flex items-center justify-center text-white text-[10px] font-bold shrink-0">
                              {c.username?.[0]?.toUpperCase() || '?'}
                            </div>
                          )}
                          <div className="min-w-0">
                            <p className="text-xs text-theme-muted">{c.username}</p>
                            <p className="text-sm text-theme-text break-words">{c.content}</p>
                          </div>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <p className="text-xs text-theme-muted">Нет комментариев. Будь первым!</p>
                  )}
                </div>
              )}
            </div>
          );
        })}
      </div>

      {/* Infinite scroll sentinel */}
      <div ref={sentinelRef} className="h-10 flex items-center justify-center">
        {loading && <Loader2 className="w-5 h-5 text-theme-muted animate-spin" />}
        {!hasMore && beats.length > 0 && (
          <p className="text-xs text-theme-muted">Это все биты на сегодня</p>
        )}
      </div>

      {/* Fake reviews */}
      <div className="glass-surface bg-theme-surface/50 border border-theme-border rounded-2xl p-4">
        <h3 className="text-sm font-medium text-theme-text mb-3 flex items-center gap-2">
          <MessageCircle className="w-4 h-4 text-theme-primary" />
          Отзывы слушателей
        </h3>
        <div className="space-y-3">
          {FAKE_REVIEWS.map((r, i) => (
            <div key={i} className="flex gap-3">
              <div className="w-8 h-8 rounded-full bg-gradient-to-br from-theme-primary to-theme-accent flex items-center justify-center text-white text-xs font-bold shrink-0">
                {r.avatar}
              </div>
              <div>
                <p className="text-xs text-theme-muted">{r.user}</p>
                <p className="text-sm text-theme-text">{r.text}</p>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Remix modal */}
      {showRemixFor && (
        <div
          className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4"
          onClick={() => setShowRemixFor(null)}
        >
          <div
            className="glass-surface bg-theme-surface border border-theme-border rounded-2xl p-6 w-full max-w-md space-y-4"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between">
              <h3 className="text-theme-text font-semibold flex items-center gap-2">
                <GitFork className="w-5 h-5 text-theme-primary" /> Создать ремикс
              </h3>
              <button onClick={() => setShowRemixFor(null)} className="text-theme-muted hover:text-theme-text">
                <X className="w-5 h-5" />
              </button>
            </div>
            <div className="space-y-3">
              <input
                value={remixTitle}
                onChange={(e) => setRemixTitle(e.target.value)}
                placeholder="Название ремикса"
                className="w-full px-3 py-2 bg-theme-surface2 border border-theme-border rounded-lg text-theme-text text-sm focus:outline-none focus:border-theme-primary"
              />
              <input
                value={remixUrl}
                onChange={(e) => setRemixUrl(e.target.value)}
                placeholder="Ссылка на аудио (URL)"
                className="w-full px-3 py-2 bg-theme-surface2 border border-theme-border rounded-lg text-theme-text text-sm focus:outline-none focus:border-theme-primary"
              />
            </div>
            <button
              onClick={() => {
                const beat = beats.find((b) => b.id === showRemixFor);
                if (beat) submitRemix(beat);
              }}
              className="w-full px-4 py-2 bg-theme-primary text-white rounded-lg text-sm font-medium hover:bg-theme-primary-hover transition-colors"
            >
              Опубликовать ремикс
            </button>
          </div>
        </div>
      )}

      {playingBeat && (
        <div className="fixed bottom-4 right-4 z-40 glass-surface bg-theme-surface/90 border border-theme-border rounded-xl px-4 py-2 flex items-center gap-3">
          <Music className="w-4 h-4 text-theme-primary animate-pulse" />
          <span className="text-sm text-theme-text truncate max-w-[160px]">Играет: {playingBeat.title}</span>
          <button onClick={stopPlayback} className="text-theme-muted hover:text-theme-danger">
            <Pause className="w-4 h-4" />
          </button>
        </div>
      )}
    </div>
  );
}
