import { useState, useEffect, useCallback } from 'react';
import { useAuth } from '@/context/AuthContext';
import { supabase, type Subscription } from '@/lib/supabase';
import { Crown, Check, X, CreditCard, Sparkles, Shield, Zap, Headphones, Palette, Bot, Star, Loader2, XCircle } from 'lucide-react';

const PREMIUM_FEATURES = [
  { icon: X, label: 'Без рекламы' },
  { icon: Palette, label: 'Эксклюзивные аватары' },
  { icon: Zap, label: '2x XP ускорение' },
  { icon: Bot, label: 'AI генерация обложек' },
  { icon: Headphones, label: 'HD качество стриминга' },
  { icon: Shield, label: 'Приоритетная поддержка' },
];

const COMPARISON: { feature: string; free: string | boolean; premium: string | boolean }[] = [
  { feature: 'Реклама', free: 'Есть', premium: false },
  { feature: 'Качество звука', free: '128 kbps', premium: 'HD 320 kbps' },
  { feature: 'XP множитель', free: '1x', premium: '2x' },
  { feature: 'Аватары', free: 'Базовые', premium: 'Эксклюзивные' },
  { feature: 'AI обложки', free: false, premium: true },
  { feature: 'Поддержка', free: 'Обычная', premium: 'Приоритет' },
  { feature: 'Ежедневные бонусы', free: 'Стандарт', premium: 'Удвоенные' },
];

export default function SubscriptionPage() {
  const { profile } = useAuth();
  const [subscription, setSubscription] = useState<Subscription | null>(null);
  const [loading, setLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);
  const [processing, setProcessing] = useState(false);
  const [cardNumber, setCardNumber] = useState('');
  const [expiry, setExpiry] = useState('');
  const [cvc, setCvc] = useState('');
  const [error, setError] = useState<string | null>(null);

  const fetchSubscription = useCallback(async () => {
    if (!profile) return;
    setLoading(true);
    const { data, error } = await supabase
      .from('subscriptions')
      .select('*')
      .eq('user_id', profile.id)
      .maybeSingle();
    if (error) {
      console.error('Error fetching subscription:', error);
    } else {
      setSubscription(data as Subscription | null);
    }
    setLoading(false);
  }, [profile]);

  useEffect(() => {
    fetchSubscription();
  }, [fetchSubscription]);

  const isActive = subscription?.status === 'active' && subscription?.expires_at && new Date(subscription.expires_at) > new Date();

  const formatCardNumber = (val: string): string => {
    const digits = val.replace(/\D/g, '').slice(0, 16);
    return digits.replace(/(.{4})/g, '$1 ').trim();
  };

  const formatExpiry = (val: string): string => {
    const digits = val.replace(/\D/g, '').slice(0, 4);
    if (digits.length >= 3) return `${digits.slice(0, 2)}/${digits.slice(2)}`;
    return digits;
  };

  const handlePayment = async () => {
    setError(null);
    const digits = cardNumber.replace(/\s/g, '');
    if (digits.length < 16) {
      setError('Введите полный номер карты');
      return;
    }
    if (expiry.length < 5) {
      setError('Введите срок действия');
      return;
    }
    if (cvc.length < 3) {
      setError('Введите CVC код');
      return;
    }

    setProcessing(true);
    // Simulate payment processing
    await new Promise((resolve) => setTimeout(resolve, 2500));

    if (!profile) {
      setProcessing(false);
      return;
    }

    const expiresAt = new Date();
    expiresAt.setDate(expiresAt.getDate() + 30);

    if (subscription) {
      const { error } = await supabase
        .from('subscriptions')
        .update({
          status: 'active',
          plan: 'premium',
          started_at: new Date().toISOString(),
          expires_at: expiresAt.toISOString(),
        })
        .eq('id', subscription.id);
      if (error) {
        setError('Ошибка при активации подписки');
      }
    } else {
      const { error } = await supabase
        .from('subscriptions')
        .insert({
          user_id: profile.id,
          status: 'active',
          plan: 'premium',
          started_at: new Date().toISOString(),
          expires_at: expiresAt.toISOString(),
        });
      if (error) {
        setError('Ошибка при создании подписки');
      }
    }

    setProcessing(false);
    setShowModal(false);
    setCardNumber('');
    setExpiry('');
    setCvc('');
    await fetchSubscription();
  };

  const cancelSubscription = async () => {
    if (!subscription) return;
    const { error } = await supabase
      .from('subscriptions')
      .update({ status: 'cancelled' })
      .eq('id', subscription.id);
    if (error) {
      console.error('Error cancelling subscription:', error);
      return;
    }
    await fetchSubscription();
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center py-20">
        <div className="w-8 h-8 border-2 border-theme-primary border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-theme-text flex items-center gap-2">
          <Crown className="w-6 h-6 text-theme-warning" />
          Premium подписка
        </h1>
        <p className="text-theme-muted text-sm mt-1">
          Откройте все возможности Soundscape Pro
        </p>
      </div>

      {/* Active subscription banner */}
      {isActive && (
        <div className="bg-gradient-to-r from-theme-warning/20 via-theme-primary/20 to-theme-accent/20 border border-theme-warning/30 rounded-2xl p-5 flex items-center gap-4">
          <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-theme-warning to-theme-primary flex items-center justify-center shrink-0">
            <Crown className="w-6 h-6 text-white" />
          </div>
          <div className="flex-1">
            <p className="text-theme-text font-medium">Premium активна</p>
            <p className="text-theme-muted text-sm">
              Действует до: {new Date(subscription!.expires_at!).toLocaleDateString('ru-RU')}
            </p>
          </div>
          <button
            onClick={cancelSubscription}
            className="px-4 py-2 bg-theme-surface2 text-theme-muted hover:text-theme-danger border border-theme-border rounded-lg text-sm transition-colors flex items-center gap-2"
          >
            <XCircle className="w-4 h-4" />
            Отменить
          </button>
        </div>
      )}

      {/* Premium pricing card */}
      <div className="relative max-w-2xl mx-auto">
        {/* Glow effect */}
        <div className="absolute -inset-1 bg-gradient-to-r from-theme-warning via-theme-primary to-theme-accent rounded-3xl blur-lg opacity-30 animate-pulse" />

        <div className="relative bg-gradient-to-br from-theme-surface to-theme-surface2 border border-theme-primary-border rounded-3xl p-8 glass-surface">
          <div className="text-center mb-6">
            <div className="inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-gradient-to-br from-theme-warning to-theme-primary mb-4 shadow-lg">
              <Crown className="w-8 h-8 text-white" />
            </div>
            <h2 className="text-2xl font-bold text-theme-text">Soundscape Pro</h2>
            <p className="text-theme-muted text-sm mt-1">Максимальные возможности для меломана</p>
          </div>

          <div className="text-center mb-6">
            <span className="text-5xl font-bold text-theme-text">299</span>
            <span className="text-theme-muted text-lg ml-1">₽ / мес</span>
          </div>

          {/* Features list */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mb-6">
            {PREMIUM_FEATURES.map((feat) => (
              <div key={feat.label} className="flex items-center gap-3">
                <div className="w-8 h-8 rounded-lg bg-theme-primary-bg flex items-center justify-center shrink-0">
                  <feat.icon className="w-4 h-4 text-theme-primary" />
                </div>
                <span className="text-sm text-theme-text">{feat.label}</span>
              </div>
            ))}
          </div>

          {!isActive ? (
            <button
              onClick={() => setShowModal(true)}
              className="w-full py-3.5 bg-gradient-to-r from-theme-warning via-theme-primary to-theme-accent text-white rounded-xl font-medium hover:shadow-xl transition-all flex items-center justify-center gap-2"
            >
              <Sparkles className="w-5 h-5" />
              Оформить подписку
            </button>
          ) : (
            <div className="w-full py-3.5 bg-theme-success/20 text-theme-success rounded-xl font-medium text-center flex items-center justify-center gap-2">
              <Check className="w-5 h-5" />
              Подписка активна
            </div>
          )}
        </div>
      </div>

      {/* Free vs Premium comparison */}
      <div className="bg-theme-surface/50 border border-theme-border rounded-2xl overflow-hidden glass-surface">
        <h3 className="text-sm font-medium text-theme-text p-4 border-b border-theme-border flex items-center gap-2">
          <Star className="w-4 h-4 text-theme-warning" />
          Сравнение планов
        </h3>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-theme-border">
                <th className="text-left p-4 text-xs text-theme-muted uppercase tracking-wider font-medium">Возможность</th>
                <th className="text-center p-4 text-xs text-theme-muted uppercase tracking-wider font-medium">Бесплатно</th>
                <th className="text-center p-4 text-xs text-theme-primary uppercase tracking-wider font-medium">
                  <span className="flex items-center justify-center gap-1">
                    <Crown className="w-3.5 h-3.5" /> Premium
                  </span>
                </th>
              </tr>
            </thead>
            <tbody>
              {COMPARISON.map((row, i) => (
                <tr key={row.feature} className={i % 2 === 0 ? 'bg-theme-surface2/30' : ''}>
                  <td className="p-4 text-sm text-theme-text">{row.feature}</td>
                  <td className="p-4 text-center">
                    {row.free === false ? (
                      <X className="w-4 h-4 text-theme-danger mx-auto" />
                    ) : (
                      <span className="text-sm text-theme-muted">{row.free}</span>
                    )}
                  </td>
                  <td className="p-4 text-center">
                    {row.premium === true ? (
                      <Check className="w-4 h-4 text-theme-success mx-auto" />
                    ) : row.premium === false ? (
                      <X className="w-4 h-4 text-theme-danger mx-auto" />
                    ) : (
                      <span className="text-sm text-theme-primary font-medium">{row.premium}</span>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Payment modal */}
      {showModal && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-50 p-4">
          <div className="bg-theme-surface border border-theme-border rounded-2xl p-6 max-w-md w-full shadow-2xl">
            <div className="flex items-center justify-between mb-5">
              <h3 className="text-lg font-bold text-theme-text flex items-center gap-2">
                <CreditCard className="w-5 h-5 text-theme-primary" />
                Оплата Yookassa
              </h3>
              <button
                onClick={() => !processing && setShowModal(false)}
                className="text-theme-muted hover:text-theme-text transition-colors"
                disabled={processing}
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="bg-theme-surface2 rounded-xl p-3 mb-5 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Crown className="w-5 h-5 text-theme-warning" />
                <span className="text-sm text-theme-text font-medium">Soundscape Pro</span>
              </div>
              <span className="text-lg font-bold text-theme-text">299 ₽</span>
            </div>

            <div className="space-y-4">
              <div>
                <label className="text-xs text-theme-muted uppercase tracking-wider mb-1.5 block">Номер карты</label>
                <input
                  type="text"
                  value={cardNumber}
                  onChange={(e) => setCardNumber(formatCardNumber(e.target.value))}
                  placeholder="0000 0000 0000 0000"
                  className="w-full px-4 py-2.5 bg-theme-surface2 border border-theme-border rounded-lg text-theme-text text-sm focus:outline-none focus:border-theme-primary font-mono"
                  disabled={processing}
                />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs text-theme-muted uppercase tracking-wider mb-1.5 block">Срок</label>
                  <input
                    type="text"
                    value={expiry}
                    onChange={(e) => setExpiry(formatExpiry(e.target.value))}
                    placeholder="ММ/ГГ"
                    className="w-full px-4 py-2.5 bg-theme-surface2 border border-theme-border rounded-lg text-theme-text text-sm focus:outline-none focus:border-theme-primary font-mono"
                    disabled={processing}
                  />
                </div>
                <div>
                  <label className="text-xs text-theme-muted uppercase tracking-wider mb-1.5 block">CVC</label>
                  <input
                    type="text"
                    value={cvc}
                    onChange={(e) => setCvc(e.target.value.replace(/\D/g, '').slice(0, 3))}
                    placeholder="000"
                    className="w-full px-4 py-2.5 bg-theme-surface2 border border-theme-border rounded-lg text-theme-text text-sm focus:outline-none focus:border-theme-primary font-mono"
                    disabled={processing}
                  />
                </div>
              </div>

              {error && (
                <p className="text-sm text-theme-danger">{error}</p>
              )}

              <button
                onClick={handlePayment}
                disabled={processing}
                className="w-full py-3 bg-gradient-to-r from-theme-primary to-theme-accent text-white rounded-xl font-medium hover:shadow-lg transition-all disabled:opacity-50 flex items-center justify-center gap-2"
              >
                {processing ? (
                  <>
                    <Loader2 className="w-5 h-5 animate-spin" />
                    Обработка платежа...
                  </>
                ) : (
                  <>
                    <Shield className="w-5 h-5" />
                    Оплатить 299 ₽
                  </>
                )}
              </button>

              <p className="text-xs text-theme-muted text-center flex items-center justify-center gap-1.5">
                <Shield className="w-3 h-3" />
                Защищённый платёж Yookassa
              </p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
