import { useState, useRef, useCallback, useEffect } from 'react';
import { useAuth } from '@/context/AuthContext';
import { supabase } from '@/lib/supabase';
import { Play, Pause, Save, Trash2, Plus, Volume2, Disc3 } from 'lucide-react';

type TrackType = 'kick' | 'snare' | 'hihat' | 'openhat' | 'clap' | 'tom' | 'bass' | 'synth' | 'pad' | 'crash' | 'rim' | 'perc' | 'lead' | 'piano';

type Track = {
  id: string;
  name: string;
  type: TrackType;
  steps: boolean[];
  volume: number;
  muted: boolean;
  color: string;
};

const TRACK_PRESETS: Omit<Track, 'id' | 'steps' | 'muted'>[] = [
  { name: 'Кик', type: 'kick', volume: 0.8, color: 'bg-red-500' },
  { name: 'Снейр', type: 'snare', volume: 0.7, color: 'bg-orange-500' },
  { name: 'Хай-Хэт', type: 'hihat', volume: 0.5, color: 'bg-amber-500' },
  { name: 'Открытый хэт', type: 'openhat', volume: 0.5, color: 'bg-yellow-500' },
  { name: 'Хлопок', type: 'clap', volume: 0.6, color: 'bg-lime-500' },
  { name: 'Том', type: 'tom', volume: 0.7, color: 'bg-green-500' },
  { name: 'Бас', type: 'bass', volume: 0.7, color: 'bg-emerald-500' },
  { name: 'Синт', type: 'synth', volume: 0.5, color: 'bg-cyan-500' },
  { name: 'Пэд', type: 'pad', volume: 0.4, color: 'bg-blue-500' },
  { name: 'Крэш', type: 'crash', volume: 0.5, color: 'bg-purple-500' },
  { name: 'Рим', type: 'rim', volume: 0.6, color: 'bg-pink-500' },
  { name: 'Перкуссия', type: 'perc', volume: 0.5, color: 'bg-teal-500' },
  { name: 'Лид', type: 'lead', volume: 0.5, color: 'bg-indigo-500' },
  { name: 'Пианино', type: 'piano', volume: 0.6, color: 'bg-rose-500' },
];

const GENRES = ['Хип-Хоп', 'Трэп', 'House', 'Техно', 'Lo-Fi', 'Драм-н-Бейс', 'Дабстеп', 'Рэгги', 'Рок', 'Поп', 'R&B', 'Фонк'];
const STEPS = 16;

function createTrack(preset: Omit<Track, 'id' | 'steps' | 'muted'>): Track {
  return {
    ...preset,
    id: crypto.randomUUID(),
    steps: Array(STEPS).fill(false),
    muted: false,
  };
}

function makeSound(ctx: AudioContext, type: TrackType, time: number, volume: number) {
  const gain = ctx.createGain();
  gain.connect(ctx.destination);
  gain.gain.value = volume;

  switch (type) {
    case 'kick': {
      // Subtle click at the start for attack transient
      const click = ctx.createOscillator();
      click.type = 'square';
      click.frequency.setValueAtTime(1200, time);
      click.frequency.exponentialRampToValueAtTime(40, time + 0.02);
      const clickGain = ctx.createGain();
      clickGain.gain.setValueAtTime(volume * 0.4, time);
      clickGain.gain.exponentialRampToValueAtTime(0.001, time + 0.03);
      click.connect(clickGain);
      clickGain.connect(gain);
      click.start(time);
      click.stop(time + 0.03);

      // Main body with frequency sweep from 150 to 30Hz + slight pitch envelope
      const osc = ctx.createOscillator();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(150, time);
      osc.frequency.exponentialRampToValueAtTime(30, time + 0.08);
      osc.frequency.exponentialRampToValueAtTime(30, time + 0.5);
      const oscGain = ctx.createGain();
      oscGain.gain.setValueAtTime(volume, time);
      oscGain.gain.exponentialRampToValueAtTime(0.01, time + 0.5);
      osc.connect(oscGain);
      oscGain.connect(gain);
      osc.start(time);
      osc.stop(time + 0.5);
      break;
    }
    case 'snare': {
      // Noise path through highpass
      const noise = ctx.createBufferSource();
      const buffer = ctx.createBuffer(1, 4410, 44100);
      const data = buffer.getChannelData(0);
      for (let i = 0; i < 4410; i++) data[i] = Math.random() * 2 - 1;
      noise.buffer = buffer;
      const noiseFilter = ctx.createBiquadFilter();
      noiseFilter.type = 'highpass';
      noiseFilter.frequency.value = 1000;
      const noiseGain = ctx.createGain();
      noiseGain.gain.setValueAtTime(volume * 0.7, time);
      noiseGain.gain.exponentialRampToValueAtTime(0.01, time + 0.2);
      noise.connect(noiseFilter);
      noiseFilter.connect(noiseGain);
      noiseGain.connect(gain);
      noise.start(time);
      noise.stop(time + 0.2);

      // Tonal component: triangle wave at 200Hz through bandpass
      const tone = ctx.createOscillator();
      tone.type = 'triangle';
      tone.frequency.setValueAtTime(200, time);
      const toneFilter = ctx.createBiquadFilter();
      toneFilter.type = 'bandpass';
      toneFilter.frequency.value = 200;
      toneFilter.Q.value = 2;
      const toneGain = ctx.createGain();
      toneGain.gain.setValueAtTime(volume * 0.4, time);
      toneGain.gain.exponentialRampToValueAtTime(0.01, time + 0.15);
      tone.connect(toneFilter);
      toneFilter.connect(toneGain);
      toneGain.connect(gain);
      tone.start(time);
      tone.stop(time + 0.15);
      break;
    }
    case 'hihat': {
      // Square wave through highpass at 10kHz for clean digital hat
      const osc = ctx.createOscillator();
      osc.type = 'square';
      osc.frequency.setValueAtTime(10000, time);
      const filter = ctx.createBiquadFilter();
      filter.type = 'highpass';
      filter.frequency.value = 10000;
      const oscGain = ctx.createGain();
      oscGain.gain.setValueAtTime(volume * 0.3, time);
      oscGain.gain.exponentialRampToValueAtTime(0.001, time + 0.03);
      osc.connect(filter);
      filter.connect(oscGain);
      oscGain.connect(gain);
      osc.start(time);
      osc.stop(time + 0.03);
      break;
    }
    case 'openhat': {
      const noise = ctx.createBufferSource();
      const buffer = ctx.createBuffer(1, 22050, 44100);
      const data = buffer.getChannelData(0);
      for (let i = 0; i < 22050; i++) data[i] = Math.random() * 2 - 1;
      noise.buffer = buffer;
      const filter = ctx.createBiquadFilter();
      filter.type = 'highpass';
      filter.frequency.value = 7000;
      noise.connect(filter);
      filter.connect(gain);
      gain.gain.setValueAtTime(volume, time);
      gain.gain.exponentialRampToValueAtTime(0.01, time + 0.3);
      noise.start(time);
      noise.stop(time + 0.3);
      break;
    }
    case 'clap': {
      for (let i = 0; i < 3; i++) {
        const noise = ctx.createBufferSource();
        const buffer = ctx.createBuffer(1, 2205, 44100);
        const data = buffer.getChannelData(0);
        for (let j = 0; j < 2205; j++) data[j] = Math.random() * 2 - 1;
        noise.buffer = buffer;
        const filter = ctx.createBiquadFilter();
        filter.type = 'bandpass';
        filter.frequency.value = 1500;
        noise.connect(filter);
        filter.connect(gain);
        gain.gain.setValueAtTime(volume, time + i * 0.01);
        gain.gain.exponentialRampToValueAtTime(0.01, time + i * 0.01 + 0.1);
        noise.start(time + i * 0.01);
        noise.stop(time + i * 0.01 + 0.1);
      }
      break;
    }
    case 'tom': {
      const osc = ctx.createOscillator();
      osc.frequency.setValueAtTime(200, time);
      osc.frequency.exponentialRampToValueAtTime(80, time + 0.3);
      gain.gain.setValueAtTime(volume, time);
      gain.gain.exponentialRampToValueAtTime(0.01, time + 0.3);
      osc.connect(gain);
      osc.start(time);
      osc.stop(time + 0.3);
      break;
    }
    case 'bass': {
      // Two detuned sawtooth oscillators through resonant lowpass with filter sweep
      const filter = ctx.createBiquadFilter();
      filter.type = 'lowpass';
      filter.Q.value = 8;
      filter.frequency.setValueAtTime(200, time);
      filter.frequency.exponentialRampToValueAtTime(800, time + 0.1);
      filter.frequency.exponentialRampToValueAtTime(200, time + 0.3);
      filter.connect(gain);

      const osc1 = ctx.createOscillator();
      osc1.type = 'sawtooth';
      osc1.frequency.setValueAtTime(80, time);
      const osc2 = ctx.createOscillator();
      osc2.type = 'sawtooth';
      osc2.frequency.setValueAtTime(80.5, time);
      osc1.connect(filter);
      osc2.connect(filter);

      // Sub-oscillator sine one octave below
      const sub = ctx.createOscillator();
      sub.type = 'sine';
      sub.frequency.setValueAtTime(40, time);
      const subGain = ctx.createGain();
      subGain.gain.value = 0.5;
      sub.connect(subGain);
      subGain.connect(gain);

      gain.gain.setValueAtTime(volume, time);
      gain.gain.exponentialRampToValueAtTime(0.01, time + 0.3);
      osc1.start(time);
      osc1.stop(time + 0.3);
      osc2.start(time);
      osc2.stop(time + 0.3);
      sub.start(time);
      sub.stop(time + 0.3);
      break;
    }
    case 'synth': {
      // Detuned sawtooth pair through lowpass with envelope
      const filter = ctx.createBiquadFilter();
      filter.type = 'lowpass';
      filter.frequency.setValueAtTime(3000, time);
      filter.frequency.exponentialRampToValueAtTime(800, time + 0.2);
      filter.Q.value = 2;
      filter.connect(gain);

      const osc1 = ctx.createOscillator();
      osc1.type = 'sawtooth';
      osc1.frequency.setValueAtTime(440, time);
      const osc2 = ctx.createOscillator();
      osc2.type = 'sawtooth';
      osc2.frequency.setValueAtTime(442, time);
      osc1.connect(filter);
      osc2.connect(filter);

      gain.gain.setValueAtTime(volume * 0.25, time);
      gain.gain.exponentialRampToValueAtTime(0.01, time + 0.2);
      osc1.start(time);
      osc1.stop(time + 0.2);
      osc2.start(time);
      osc2.stop(time + 0.2);
      break;
    }
    case 'pad': {
      // 3 detuned sine/triangle oscillators with slow attack and long release
      const padGain = ctx.createGain();
      padGain.gain.setValueAtTime(0.0001, time);
      padGain.gain.linearRampToValueAtTime(volume * 0.2, time + 0.2);
      padGain.gain.exponentialRampToValueAtTime(0.01, time + 1.0);
      padGain.connect(gain);

      const freqs = [220, 220.5, 277];
      const types: OscillatorType[] = ['sine', 'triangle', 'sine'];
      const oscs = freqs.map((f, i) => {
        const o = ctx.createOscillator();
        o.type = types[i];
        o.frequency.setValueAtTime(f, time);
        o.connect(padGain);
        o.start(time);
        o.stop(time + 1.0);
        return o;
      });
      void oscs;
      break;
    }
    case 'crash': {
      // Long white noise with slow decay through highpass at 5000Hz
      const noise = ctx.createBufferSource();
      const buffer = ctx.createBuffer(1, 35280, 44100);
      const data = buffer.getChannelData(0);
      for (let i = 0; i < 35280; i++) data[i] = Math.random() * 2 - 1;
      noise.buffer = buffer;
      const filter = ctx.createBiquadFilter();
      filter.type = 'highpass';
      filter.frequency.value = 5000;
      noise.connect(filter);
      filter.connect(gain);
      gain.gain.setValueAtTime(volume, time);
      gain.gain.exponentialRampToValueAtTime(0.01, time + 0.8);
      noise.start(time);
      noise.stop(time + 0.8);
      break;
    }
    case 'rim': {
      // Short click — high frequency square wave at 800Hz, 0.05s decay
      const osc = ctx.createOscillator();
      osc.type = 'square';
      osc.frequency.setValueAtTime(800, time);
      const oscGain = ctx.createGain();
      oscGain.gain.setValueAtTime(volume * 0.5, time);
      oscGain.gain.exponentialRampToValueAtTime(0.001, time + 0.05);
      osc.connect(oscGain);
      oscGain.connect(gain);
      osc.start(time);
      osc.stop(time + 0.05);
      break;
    }
    case 'perc': {
      // Mid-frequency noise burst through bandpass at 2500Hz, 0.1s
      const noise = ctx.createBufferSource();
      const buffer = ctx.createBuffer(1, 4410, 44100);
      const data = buffer.getChannelData(0);
      for (let i = 0; i < 4410; i++) data[i] = Math.random() * 2 - 1;
      noise.buffer = buffer;
      const filter = ctx.createBiquadFilter();
      filter.type = 'bandpass';
      filter.frequency.value = 2500;
      filter.Q.value = 2;
      noise.connect(filter);
      filter.connect(gain);
      gain.gain.setValueAtTime(volume, time);
      gain.gain.exponentialRampToValueAtTime(0.01, time + 0.1);
      noise.start(time);
      noise.stop(time + 0.1);
      break;
    }
    case 'lead': {
      // Detuned sawtooth oscillators through lowpass filter, 0.3s
      const filter = ctx.createBiquadFilter();
      filter.type = 'lowpass';
      filter.frequency.setValueAtTime(4000, time);
      filter.frequency.exponentialRampToValueAtTime(1000, time + 0.3);
      filter.Q.value = 3;
      filter.connect(gain);

      const osc1 = ctx.createOscillator();
      osc1.type = 'sawtooth';
      osc1.frequency.setValueAtTime(660, time);
      const osc2 = ctx.createOscillator();
      osc2.type = 'sawtooth';
      osc2.frequency.setValueAtTime(663, time);
      osc1.connect(filter);
      osc2.connect(filter);

      gain.gain.setValueAtTime(volume * 0.3, time);
      gain.gain.exponentialRampToValueAtTime(0.01, time + 0.3);
      osc1.start(time);
      osc1.stop(time + 0.3);
      osc2.start(time);
      osc2.stop(time + 0.3);
      break;
    }
    case 'piano': {
      // Multiple sine waves at harmonic frequencies with fast attack and gradual decay
      const fundamental = 440;
      const harmonics = [
        { freq: fundamental, gain: 0.6 },
        { freq: fundamental * 2, gain: 0.3 },
        { freq: fundamental * 3, gain: 0.15 },
      ];
      const pianoGain = ctx.createGain();
      pianoGain.gain.setValueAtTime(0.0001, time);
      pianoGain.gain.linearRampToValueAtTime(volume, time + 0.005);
      pianoGain.gain.exponentialRampToValueAtTime(0.01, time + 0.5);
      pianoGain.connect(gain);

      harmonics.forEach((h) => {
        const osc = ctx.createOscillator();
        osc.type = 'sine';
        osc.frequency.setValueAtTime(h.freq, time);
        const hGain = ctx.createGain();
        hGain.gain.value = h.gain;
        osc.connect(hGain);
        hGain.connect(pianoGain);
        osc.start(time);
        osc.stop(time + 0.5);
      });
      break;
    }
  }
}

export default function BeatComposerPage() {
  const { profile, addXp, addCoins } = useAuth();
  const [tracks, setTracks] = useState<Track[]>(() =>
    TRACK_PRESETS.slice(0, 4).map(createTrack)
  );
  const [bpm, setBpm] = useState(120);
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentStep, setCurrentStep] = useState(-1);
  const [genre, setGenre] = useState('Хип-Хоп');
  const [projectName, setProjectName] = useState('Без названия');
  const [saveStatus, setSaveStatus] = useState<string | null>(null);
  const [savedProjects, setSavedProjects] = useState<{ id: string; name: string }[]>([]);

  const audioCtxRef = useRef<AudioContext | null>(null);
  const intervalRef = useRef<number | null>(null);
  const stepRef = useRef(0);
  const tracksRef = useRef(tracks);
  const bpmRef = useRef(bpm);

  useEffect(() => {
    tracksRef.current = tracks;
  }, [tracks]);
  useEffect(() => {
    bpmRef.current = bpm;
  }, [bpm]);

  const getCtx = useCallback(() => {
    if (!audioCtxRef.current) {
      audioCtxRef.current = new AudioContext();
    }
    return audioCtxRef.current;
  }, []);

  const stop = useCallback(() => {
    if (intervalRef.current) {
      clearInterval(intervalRef.current);
      intervalRef.current = null;
    }
    setIsPlaying(false);
    setCurrentStep(-1);
    stepRef.current = 0;
  }, []);

  const play = useCallback(() => {
    const ctx = getCtx();
    if (ctx.state === 'suspended') ctx.resume();

    const stepDuration = 60000 / bpmRef.current / 4;
    stepRef.current = 0;
    setIsPlaying(true);

    const tick = () => {
      const step = stepRef.current;
      setCurrentStep(step);
      const time = ctx.currentTime;
      tracksRef.current.forEach((track) => {
        if (!track.muted && track.steps[step]) {
          makeSound(ctx, track.type, time, track.volume);
        }
      });
      stepRef.current = (step + 1) % STEPS;
    };

    tick();
    intervalRef.current = window.setInterval(tick, stepDuration);
  }, [getCtx]);

  const toggleStep = (trackId: string, step: number) => {
    setTracks((prev) =>
      prev.map((t) =>
        t.id === trackId
          ? { ...t, steps: t.steps.map((s, i) => (i === step ? !s : s)) }
          : t
      )
    );
  };

  const addTrack = () => {
    if (tracks.length >= 15) return;
    const used = tracks.map((t) => t.type);
    const preset = TRACK_PRESETS.find((p) => !used.includes(p.type));
    if (preset) setTracks([...tracks, createTrack(preset)]);
  };

  const removeTrack = (id: string) => {
    setTracks(tracks.filter((t) => t.id !== id));
  };

  const toggleMute = (id: string) => {
    setTracks(tracks.map((t) => (t.id === id ? { ...t, muted: !t.muted } : t)));
  };

  const setTrackVolume = (id: string, vol: number) => {
    setTracks(tracks.map((t) => (t.id === id ? { ...t, volume: vol } : t)));
  };

  const clearAll = () => {
    setTracks(tracks.map((t) => ({ ...t, steps: Array(STEPS).fill(false) })));
  };

  const loadDemoBeat = (g: string) => {
    setGenre(g);
    const patterns: Record<string, boolean[][]> = {
      'Хип-Хоп': [
        [true, false, false, false, true, false, false, false, true, false, false, false, true, false, false, false],
        [false, false, false, false, true, false, false, false, false, false, false, false, true, false, false, false],
        [true, false, true, false, true, false, true, false, true, false, true, false, true, false, true, false],
        [true, false, false, true, false, false, true, false, true, false, false, true, false, false, true, false],
      ],
      Трэп: [
        [true, false, false, false, false, false, true, false, true, false, false, false, false, false, false, false],
        [false, false, false, false, true, false, false, false, false, false, false, false, true, false, false, false],
        [true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true],
        [false, false, true, false, false, false, true, false, false, false, true, false, false, false, true, false],
      ],
      House: [
        [true, false, false, false, true, false, false, false, true, false, false, false, true, false, false, false],
        [false, false, false, false, true, false, false, false, false, false, false, false, true, false, false, false],
        [false, false, true, false, false, false, true, false, false, false, true, false, false, false, true, false],
        [true, false, false, false, true, false, false, false, true, false, false, false, true, false, false, false],
      ],
      Техно: [
        [true, false, false, false, true, false, false, false, true, false, false, false, true, false, false, false],
        [false, false, false, false, true, false, false, false, false, false, false, false, true, false, false, false],
        [true, false, true, false, true, false, true, false, true, false, true, false, true, false, true, false],
        [false, false, true, false, false, false, true, false, false, false, true, false, false, false, true, false],
      ],
      'Lo-Fi': [
        [true, false, false, false, false, false, false, false, true, false, false, false, false, false, false, false],
        [false, false, false, false, true, false, false, false, false, false, false, false, true, false, false, false],
        [false, false, true, false, false, false, true, false, false, false, true, false, false, false, true, false],
        [true, false, false, false, false, false, false, false, true, false, false, false, false, false, false, false],
      ],
      'Драм-н-Бейс': [
        [true, false, false, false, false, true, false, false, true, false, false, true, false, false, true, false],
        [false, false, false, false, true, false, false, false, false, false, false, false, true, false, false, false],
        [true, false, true, true, false, true, true, false, true, true, false, true, true, false, true, true],
        [false, false, true, false, false, true, false, false, false, false, true, false, false, true, false, false],
      ],
      Дабстеп: [
        [true, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false],
        [false, false, false, false, false, false, false, false, true, false, false, false, false, false, false, false],
        [true, false, true, false, true, false, true, false, true, false, true, false, true, false, true, false],
        [false, false, false, false, true, false, false, true, false, false, false, false, true, false, true, false],
      ],
      Рэгги: [
        [true, false, false, false, false, false, false, false, true, false, false, false, false, false, false, false],
        [false, false, false, false, true, false, false, false, false, false, false, false, true, false, false, false],
        [false, true, false, true, false, true, false, true, false, true, false, true, false, true, false, true],
        [false, false, true, false, false, false, true, false, false, false, true, false, false, false, true, false],
      ],
      Рок: [
        [true, false, false, false, true, false, false, false, true, false, false, false, true, false, false, false],
        [false, false, false, false, true, false, false, false, false, false, false, false, true, false, false, false],
        [true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true],
        [false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false],
      ],
      Поп: [
        [true, false, false, false, true, false, false, false, true, false, false, false, true, false, false, false],
        [false, false, false, false, true, false, false, false, false, false, false, false, true, false, false, false],
        [false, false, true, false, false, false, true, false, false, false, true, false, false, false, true, false],
        [false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false],
      ],
      'R&B': [
        [true, false, false, false, false, true, false, false, true, false, false, false, false, false, true, false],
        [false, false, false, false, false, false, false, false, true, false, false, false, false, false, false, false],
        [false, false, true, false, false, false, true, false, false, false, true, false, false, false, true, false],
        [false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false],
      ],
      Фонк: [
        [true, false, false, true, true, false, false, true, true, false, true, false, true, false, false, true],
        [false, false, false, false, false, false, false, false, true, false, false, false, false, false, false, false],
        [true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true],
        [false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false],
      ],
    };
    const pattern = patterns[g] || patterns['Хип-Хоп'];
    setTracks((prev) =>
      prev.map((t, i) => ({
        ...t,
        steps: pattern[i] ? [...pattern[i]] : t.steps,
      }))
    );
  };

  const saveProject = async () => {
    if (!profile) return;
    setSaveStatus('Сохранение...');
    const { error } = await supabase.from('projects').insert({
      user_id: profile.id,
      name: projectName,
      data: { tracks, bpm, genre },
      genre,
      bpm,
    });
    if (error) {
      setSaveStatus('Ошибка при сохранении');
      return;
    }
    setSaveStatus('Проект сохранён!');
    await addXp(50);
    await addCoins(10);
    loadProjects();
    setTimeout(() => setSaveStatus(null), 2000);
  };

  const loadProjects = useCallback(async () => {
    if (!profile) return;
    const { data } = await supabase
      .from('projects')
      .select('id, name')
      .eq('user_id', profile.id)
      .order('created_at', { ascending: false })
      .limit(10);
    if (data) setSavedProjects(data);
  }, [profile]);

  useEffect(() => {
    loadProjects();
  }, [loadProjects]);

  useEffect(() => {
    return () => stop();
  }, [stop]);

  return (
    <div className="space-y-6">
      <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-theme-text flex items-center gap-2">
            <Disc3 className="w-6 h-6 text-theme-primary" />
            Бит-Секвенсор Pro
          </h1>
          <p className="text-theme-muted text-sm mt-1">
            15-дорожечный секвенсор с {STEPS} шагами
          </p>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <input
            value={projectName}
            onChange={(e) => setProjectName(e.target.value)}
            className="px-3 py-2 bg-theme-surface2 border border-theme-border rounded-lg text-theme-text text-sm focus:outline-none focus:border-theme-primary"
            placeholder="Название проекта"
          />
          <button
            onClick={saveProject}
            className="px-4 py-2 bg-theme-primary text-white rounded-lg text-sm font-medium hover:bg-theme-primary-hover transition-colors flex items-center gap-2"
          >
            <Save className="w-4 h-4" /> Сохранить
          </button>
          {saveStatus && (
            <span className="text-xs text-theme-muted">{saveStatus}</span>
          )}
        </div>
      </div>

      {/* Transport controls */}
      <div className="bg-theme-surface/50 border border-theme-border rounded-2xl p-4 flex flex-wrap items-center gap-4 glass-surface">
        <button
          onClick={isPlaying ? stop : play}
          className={`px-5 py-2.5 rounded-xl text-sm font-medium flex items-center gap-2 transition-all ${
            isPlaying
              ? 'bg-theme-danger text-white'
              : 'bg-theme-success text-white hover:bg-theme-success/90'
          }`}
        >
          {isPlaying ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
          {isPlaying ? 'Стоп' : 'Играть'}
        </button>

        <div className="flex items-center gap-2">
          <label className="text-xs text-theme-muted uppercase tracking-wider">Темп</label>
          <input
            type="range"
            min={40}
            max={300}
            value={bpm}
            onChange={(e) => setBpm(Number(e.target.value))}
            className="w-24 accent-theme-primary"
          />
          <span className="text-theme-text text-sm font-mono w-10">{bpm}</span>
        </div>

        <div className="flex items-center gap-2">
          <label className="text-xs text-theme-muted uppercase tracking-wider">Жанр</label>
          <div className="flex flex-wrap gap-1">
            {GENRES.map((g) => (
              <button
                key={g}
                onClick={() => loadDemoBeat(g)}
                className={`px-3 py-1 rounded-lg text-xs font-medium transition-all ${
                  genre === g
                    ? 'bg-theme-primary text-white'
                    : 'bg-theme-surface2 text-theme-muted hover:text-theme-text'
                }`}
              >
                {g}
              </button>
            ))}
          </div>
        </div>

        <button
          onClick={clearAll}
          className="px-3 py-2 bg-theme-surface2 text-theme-muted rounded-lg text-sm hover:text-theme-danger transition-colors flex items-center gap-2"
        >
          <Trash2 className="w-4 h-4" /> Очистить
        </button>
      </div>

      {/* Track grid */}
      <div className="bg-theme-surface/50 border border-theme-border rounded-2xl p-4 overflow-x-auto glass-surface">
        <div className="min-w-[640px] space-y-2">
          {/* Step indicators */}
          <div className="flex items-center gap-2 mb-2">
            <div className="w-32 shrink-0" />
            <div className="flex gap-1">
              {Array.from({ length: STEPS }).map((_, i) => (
                <div
                  key={i}
                  className={`w-8 h-5 rounded flex items-center justify-center text-[10px] font-mono ${
                    i % 4 === 0 ? 'text-theme-primary' : 'text-theme-muted'
                  } ${currentStep === i ? 'bg-theme-primary-bg' : ''}`}
                >
                  {i + 1}
                </div>
              ))}
            </div>
            <div className="w-20 shrink-0" />
          </div>

          {/* Tracks */}
          {tracks.map((track) => (
            <div key={track.id} className="flex items-center gap-2 group">
              <div className="w-32 shrink-0 flex items-center gap-1">
                <button
                  onClick={() => toggleMute(track.id)}
                  className={`p-1 rounded ${track.muted ? 'text-theme-muted' : 'text-theme-text'}`}
                  title={track.muted ? 'Включить звук' : 'Выключить звук'}
                >
                  <Volume2 className="w-3.5 h-3.5" />
                </button>
                <span
                  className={`text-xs font-medium truncate ${track.muted ? 'text-theme-muted line-through' : 'text-theme-text'}`}
                >
                  {track.name}
                </span>
                <button
                  onClick={() => removeTrack(track.id)}
                  className="opacity-0 group-hover:opacity-100 text-theme-muted hover:text-theme-danger transition-opacity"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
              <div className="flex gap-1">
                {track.steps.map((active, i) => (
                  <button
                    key={i}
                    onClick={() => toggleStep(track.id, i)}
                    className={`w-8 h-8 rounded-md transition-all ${
                      active
                        ? `${track.color} shadow-lg`
                        : i % 4 === 0
                        ? 'bg-theme-surface2 hover:bg-theme-border'
                        : 'bg-theme-surface hover:bg-theme-surface2'
                    } ${currentStep === i && active ? 'ring-2 ring-white/50' : ''}`}
                  />
                ))}
              </div>
              <div className="w-20 shrink-0 flex items-center gap-1">
                <input
                  type="range"
                  min={0}
                  max={1}
                  step={0.1}
                  value={track.volume}
                  onChange={(e) => setTrackVolume(track.id, Number(e.target.value))}
                  className="w-16 accent-theme-primary"
                />
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Add track + saved projects */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <div className="bg-theme-surface/50 border border-theme-border rounded-2xl p-4 glass-surface">
          <h3 className="text-sm font-medium text-theme-text mb-3">Добавить дорожку</h3>
          <div className="flex flex-wrap gap-2">
            {TRACK_PRESETS.map((p) => {
              const used = tracks.some((t) => t.type === p.type);
              return (
                <button
                  key={p.type}
                  onClick={addTrack}
                  disabled={used || tracks.length >= 15}
                  className={`px-3 py-1.5 rounded-lg text-xs font-medium flex items-center gap-1.5 transition-all ${
                    used
                      ? 'bg-theme-surface2 text-theme-muted cursor-not-allowed'
                      : 'bg-theme-surface2 text-theme-text hover:bg-theme-border'
                  }`}
                >
                  <Plus className="w-3 h-3" />
                  {p.name}
                </button>
              );
            })}
          </div>
          <p className="text-xs text-theme-muted mt-3">{tracks.length}/15 дорожек</p>
        </div>

        <div className="bg-theme-surface/50 border border-theme-border rounded-2xl p-4 glass-surface">
          <h3 className="text-sm font-medium text-theme-text mb-3">Сохранённые проекты</h3>
          {savedProjects.length === 0 ? (
            <p className="text-xs text-theme-muted">Нет сохранённых проектов. Сохрани бит, чтобы он появился здесь.</p>
          ) : (
            <div className="space-y-2 max-h-48 overflow-y-auto">
              {savedProjects.map((p) => (
                <div
                  key={p.id}
                  className="flex items-center justify-between px-3 py-2 bg-theme-surface2 rounded-lg"
                >
                  <span className="text-sm text-theme-text truncate">{p.name}</span>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
