import { useState, useRef, useEffect } from 'react';
import { useAuth } from '@/context/AuthContext';
import { BarChart3, Play, Pause, SkipBack, SkipForward, Volume2, Heart, Loader2 } from 'lucide-react';

type ChartTrack = {
  id: number;
  title: string;
  artist: string;
  url: string;
  cover: string;
  duration?: string;
};

const CHART_TRACKS: ChartTrack[] = [
  {
    id: 1,
    title: 'I GOT U',
    artist: 'Toxi',
    url: 'https://cdn13.deliciousoranges.com/s3/get/music/20240608/Toxi_-_I_GOT_U_77936633.mp3',
    cover: '/cover-igotu.webp',
  duration: '2:48',
  },
  {
    id: 2,
    title: 'Мало',
    artist: 'EGOR KRID',
    url: 'https://cdn15.deliciousoranges.com/s1/get/music/20260703/EGOR_KRID_-_Malo_20_81826468.mp3',
    cover: '/cover-malo.webp',
    duration: '2:35',
  },
  {
    id: 3,
    title: 'Тону',
    artist: 'HOLLYFLAME',
    url: 'https://cdn1.deliciousoranges.com/s1/get/music/20260206/HOLLYFLAME_-_Tonu_80790537.mp3',
    cover: '/cover-tonu.webp',
    duration: '3:12',
  },
  {
    id: 4,
    title: 'Малиновая Лада',
    artist: 'GAYAZOV BROTHER',
    url: 'https://cdn14.deliciousoranges.com/s3/get/music/20211024/GAYAZOV_BROTHER_-_MALINOVAYA_LADA_73214200.mp3',
    cover: '/cover-lada.webp',
    duration: '2:22',
  },
  {
    id: 5,
    title: 'По барам',
    artist: 'ANNA ASTI',
    url: 'https://cdn1.deliciousoranges.com/s3/get/music/20220603/ANNA_ASTI_-_Po_baram_74376135.mp3',
    cover: '/cover-baram.webp',
    duration: '2:58',
  },
];

export default function ChartsPage() {
  const { addXp } = useAuth();
  const [currentTrack, setCurrentTrack] = useState<ChartTrack | null>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [loading, setLoading] = useState(false);
  const [progress, setProgress] = useState(0);
  const [duration, setDuration] = useState(0);
  const [volume, setVolume] = useState(0.7);
  const [favorites, setFavorites] = useState<Set<number>>(new Set());

  const audioRef = useRef<HTMLAudioElement | null>(null);

  useEffect(() => {
    const saved = localStorage.getItem('soundscape-favorites');
    if (saved) {
      try {
        setFavorites(new Set(JSON.parse(saved)));
      } catch {
        // ignore
      }
    }
  }, []);

  const toggleFavorite = (trackId: number) => {
    setFavorites((prev) => {
      const next = new Set(prev);
      if (next.has(trackId)) {
        next.delete(trackId);
      } else {
        next.add(trackId);
      }
      localStorage.setItem('soundscape-favorites', JSON.stringify([...next]));
      return next;
    });
  };

  const playTrack = (track: ChartTrack) => {
    if (currentTrack?.id === track.id && isPlaying) {
      audioRef.current?.pause();
      return;
    }
    setLoading(true);
    setCurrentTrack(track);
    setProgress(0);
    setDuration(0);
    if (audioRef.current) {
      audioRef.current.src = track.url;
      audioRef.current.volume = volume;
      audioRef.current.play().then(() => {
        setIsPlaying(true);
        setLoading(false);
        addXp(5);
      }).catch(() => {
        setLoading(false);
      });
    }
  };

  const togglePlay = () => {
    if (!audioRef.current || !currentTrack) return;
    if (isPlaying) {
      audioRef.current.pause();
    } else {
      audioRef.current.play().catch(() => {});
    }
  };

  const playNext = () => {
    if (!currentTrack) return;
    const idx = CHART_TRACKS.findIndex((t) => t.id === currentTrack.id);
    const next = CHART_TRACKS[(idx + 1) % CHART_TRACKS.length];
    playTrack(next);
  };

  const playPrev = () => {
    if (!currentTrack) return;
    const idx = CHART_TRACKS.findIndex((t) => t.id === currentTrack.id);
    const prev = CHART_TRACKS[(idx - 1 + CHART_TRACKS.length) % CHART_TRACKS.length];
    playTrack(prev);
  };

  const handleTimeUpdate = () => {
    if (audioRef.current) {
      setProgress(audioRef.current.currentTime);
      setDuration(audioRef.current.duration || 0);
    }
  };

  const handleSeek = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = Number(e.target.value);
    setProgress(val);
    if (audioRef.current) audioRef.current.currentTime = val;
  };

  const handleVolume = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = Number(e.target.value);
    setVolume(val);
    if (audioRef.current) audioRef.current.volume = val;
  };

  const formatTime = (s: number) => {
    if (!s || isNaN(s)) return '0:00';
    const m = Math.floor(s / 60);
    const sec = Math.floor(s % 60);
    return `${m}:${sec.toString().padStart(2, '0')}`;
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-theme-text flex items-center gap-2">
          <BarChart3 className="w-6 h-6 text-theme-primary" />
          Чарты
        </h1>
        <p className="text-theme-muted text-sm mt-1">
          Топ-чарт музыки — слушай прямо в браузере
        </p>
      </div>

      {/* Hidden audio element */}
      <audio
        ref={audioRef}
        onTimeUpdate={handleTimeUpdate}
        onPlay={() => setIsPlaying(true)}
        onPause={() => setIsPlaying(false)}
        onEnded={playNext}
        onLoadedMetadata={handleTimeUpdate}
      />

      {/* Now Playing bar */}
      {currentTrack && (
        <div className="glass-surface bg-theme-surface/80 border border-theme-border rounded-2xl p-4 sticky top-4 z-10">
          <div className="flex items-center gap-4">
            <div className="relative w-14 h-14 rounded-xl overflow-hidden shrink-0 bg-theme-surface2">
              <img
                src={currentTrack.cover}
                alt={currentTrack.title}
                className="w-full h-full object-cover"
              />
              {loading && (
                <div className="absolute inset-0 bg-black/50 flex items-center justify-center">
                  <Loader2 className="w-5 h-5 text-white animate-spin" />
                </div>
              )}
            </div>

            <div className="flex-1 min-w-0">
              <p className="text-theme-text text-sm font-medium truncate">{currentTrack.title}</p>
              <p className="text-theme-muted text-xs truncate">{currentTrack.artist}</p>
              <div className="flex items-center gap-2 mt-1.5">
                <span className="text-xs text-theme-muted font-mono">{formatTime(progress)}</span>
                <input
                  type="range"
                  min={0}
                  max={duration || 0}
                  value={progress}
                  onChange={handleSeek}
                  className="flex-1 accent-theme-primary"
                />
                <span className="text-xs text-theme-muted font-mono">{formatTime(duration)}</span>
              </div>
            </div>

            <div className="flex items-center gap-2 shrink-0">
              <button
                onClick={() => toggleFavorite(currentTrack.id)}
                className="p-2 text-theme-muted hover:text-theme-danger transition-colors"
              >
                <Heart className="w-5 h-5" fill={favorites.has(currentTrack.id) ? 'currentColor' : 'none'} />
              </button>
              <button
                onClick={playPrev}
                className="p-2 text-theme-muted hover:text-theme-text transition-colors"
              >
                <SkipBack className="w-5 h-5" />
              </button>
              <button
                onClick={togglePlay}
                className="p-3 bg-theme-primary text-white rounded-full hover:bg-theme-primary-hover transition-colors"
              >
                {isPlaying ? <Pause className="w-5 h-5" /> : <Play className="w-5 h-5" />}
              </button>
              <button
                onClick={playNext}
                className="p-2 text-theme-muted hover:text-theme-text transition-colors"
              >
                <SkipForward className="w-5 h-5" />
              </button>
            </div>

            <div className="hidden sm:flex items-center gap-2 shrink-0">
              <Volume2 className="w-4 h-4 text-theme-muted" />
              <input
                type="range"
                min={0}
                max={1}
                step={0.05}
                value={volume}
                onChange={handleVolume}
                className="w-16 accent-theme-primary"
              />
            </div>
          </div>
        </div>
      )}

      {/* Track list */}
      <div className="space-y-2">
        {CHART_TRACKS.map((track, i) => {
          const isActive = currentTrack?.id === track.id;
          const isFav = favorites.has(track.id);
          return (
            <div
              key={track.id}
              className={`glass-surface flex items-center gap-4 p-3 rounded-xl border transition-all cursor-pointer ${
                isActive
                  ? 'bg-theme-primary-bg border-theme-primary-border'
                  : 'bg-theme-surface/50 border-theme-border hover:border-theme-primary'
              }`}
              onClick={() => playTrack(track)}
            >
              {/* Rank */}
              <div className={`w-8 text-center font-bold text-lg shrink-0 ${i < 3 ? 'text-theme-warning' : 'text-theme-muted'}`}>
                {i + 1}
              </div>

              {/* Cover */}
              <div className="relative w-12 h-12 rounded-lg overflow-hidden shrink-0 bg-theme-surface2">
                <img src={track.cover} alt={track.title} className="w-full h-full object-cover" />
                {isActive && isPlaying && (
                  <div className="absolute inset-0 bg-black/40 flex items-center justify-center">
                    <div className="flex gap-0.5 items-end h-4">
                      <div className="w-1 bg-theme-primary rounded-full animate-pulse" style={{ height: '60%' }} />
                      <div className="w-1 bg-theme-primary rounded-full animate-pulse" style={{ height: '100%', animationDelay: '0.1s' }} />
                      <div className="w-1 bg-theme-primary rounded-full animate-pulse" style={{ height: '40%', animationDelay: '0.2s' }} />
                    </div>
                  </div>
                )}
              </div>

              {/* Title/Artist */}
              <div className="flex-1 min-w-0">
                <p className={`text-sm font-medium truncate ${isActive ? 'text-theme-primary-text' : 'text-theme-text'}`}>
                  {track.title}
                </p>
                <p className="text-xs text-theme-muted truncate">{track.artist}</p>
              </div>

              {/* Favorite */}
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  toggleFavorite(track.id);
                }}
                className={`p-1.5 transition-colors shrink-0 ${isFav ? 'text-theme-danger' : 'text-theme-muted hover:text-theme-text'}`}
              >
                <Heart className="w-4 h-4" fill={isFav ? 'currentColor' : 'none'} />
              </button>

              {/* Duration */}
              <span className="text-xs text-theme-muted font-mono shrink-0 hidden sm:block">
                {track.duration}
              </span>

              {/* Play button */}
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  playTrack(track);
                }}
                className={`p-2 rounded-full transition-colors shrink-0 ${
                  isActive
                    ? 'bg-theme-primary text-white'
                    : 'text-theme-muted hover:text-theme-text hover:bg-theme-surface2'
                }`}
              >
                {isActive && isPlaying ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
              </button>
            </div>
          );
        })}
      </div>

      <p className="text-xs text-theme-muted text-center">
        Стриминг MP3 работает напрямую из браузера. Нажми на трек, чтобы начать слушать.
      </p>
    </div>
  );
}
