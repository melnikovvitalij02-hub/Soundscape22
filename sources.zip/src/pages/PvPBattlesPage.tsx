import { useState, useEffect, useCallback } from 'react';
import { useAuth } from '@/context/AuthContext';
import { supabase } from '@/lib/supabase';
import {
  Swords,
  Plus,
  X,
  Loader2,
  Trophy,
  Vote,
  Zap,
  Crown,
} from 'lucide-react';

type Beat = {
  id: string;
  user_id: string;
  title: string;
  genre: string;
  bpm: number;
  cover_url: string | null;
};

type Battle = {
  id: string;
  beat_a_id: string;
  beat_b_id: string;
  creator_a_id: string;
  creator_b_id: string;
  votes_a: number;
  votes_b: number;
  status: 'active' | 'completed';
  winner_id: string | null;
  created_at: string;
  ends_at: string;
};

type BattleWithBeats = Battle & {
  beatA: Beat | null;
  beatB: Beat | null;
  myVote: 'a' | 'b' | null;
};

export default function PvPBattlesPage() {
  const { profile, addXp } = useAuth();
  const [battles, setBattles] = useState<BattleWithBeats[]>([]);
  const [loading, setLoading] = useState(true);
  const [showCreate, setShowCreate] = useState(false);
  const [myBeats, setMyBeats] = useState<Beat[]>([]);
  const [selectedA, setSelectedA] = useState<string | null>(null);
  const [selectedB, setSelectedB] = useState<string | null>(null);
  const [status, setStatus] = useState<string | null>(null);
  const [voting, setVoting] = useState<string | null>(null);

  const fetchBattleBeats = useCallback(async (battlesRaw: Battle[]): Promise<BattleWithBeats[]> => {
    const beatIds = new Set<string>();
    battlesRaw.forEach((b) => {
      beatIds.add(b.beat_a_id);
      beatIds.add(b.beat_b_id);
    });
    let beatsMap: Record<string, Beat> = {};
    if (beatIds.size > 0) {
      const { data: beats } = await supabase
        .from('beats')
        .select('id, user_id, title, genre, bpm, cover_url')
        .in('id', [...beatIds]);
      (beats || []).forEach((b) => {
        beatsMap[b.id] = b as Beat;
      });
    }
    let myVotes: Record<string, 'a' | 'b'> = {};
    if (profile && battlesRaw.length > 0) {
      const { data: votes } = await supabase
        .from('pvp_votes')
        .select('battle_id, choice')
        .eq('user_id', profile.id)
        .in('battle_id', battlesRaw.map((b) => b.id));
      (votes || []).forEach((v) => {
        myVotes[v.battle_id] = v.choice as 'a' | 'b';
      });
    }
    return battlesRaw.map((b) => ({
      ...b,
      beatA: beatsMap[b.beat_a_id] || null,
      beatB: beatsMap[b.beat_b_id] || null,
      myVote: myVotes[b.id] || null,
    }));
  }, [profile]);

  const fetchBattles = useCallback(async () => {
    setLoading(true);
    const { data, error } = await supabase
      .from('pvp_battles')
      .select('*')
      .order('created_at', { ascending: false })
      .limit(30);
    if (error) {
      console.error('fetchBattles', error);
      setLoading(false);
      return;
    }
    const enriched = await fetchBattleBeats((data || []) as Battle[]);
    setBattles(enriched);
    setLoading(false);
  }, [fetchBattleBeats]);

  useEffect(() => {
    fetchBattles();
  }, [fetchBattles]);

  // Realtime subscription
  useEffect(() => {
    const channel = supabase
      .channel('pvp-battles-realtime')
      .on(
        'postgres_changes',
        { event: '*', schema: 'public', table: 'pvp_battles' },
        () => {
          fetchBattles();
        }
      )
      .on(
        'postgres_changes',
        { event: 'INSERT', schema: 'public', table: 'pvp_votes' },
        () => {
          fetchBattles();
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [fetchBattles]);

  const loadMyBeats = useCallback(async () => {
    if (!profile) return;
    const { data } = await supabase
      .from('beats')
      .select('id, user_id, title, genre, bpm, cover_url')
      .eq('user_id', profile.id)
      .order('created_at', { ascending: false });
    if (data) setMyBeats(data as Beat[]);
  }, [profile]);

  useEffect(() => {
    if (showCreate) loadMyBeats();
  }, [showCreate, loadMyBeats]);

  const createBattle = async () => {
    if (!profile) return;
    if (!selectedA || !selectedB || selectedA === selectedB) {
      setStatus('Выбери два разных бита');
      return;
    }
    const endsAt = new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString();
    const { error } = await supabase.from('pvp_battles').insert({
      beat_a_id: selectedA,
      beat_b_id: selectedB,
      creator_a_id: profile.id,
      creator_b_id: profile.id,
      votes_a: 0,
      votes_b: 0,
      status: 'active',
      ends_at: endsAt,
    });
    if (error) {
      setStatus('Ошибка при создании битвы');
      return;
    }
    setShowCreate(false);
    setSelectedA(null);
    setSelectedB(null);
    setStatus('Битва создана!');
    setTimeout(() => setStatus(null), 2500);
    fetchBattles();
  };

  const vote = async (battle: BattleWithBeats, choice: 'a' | 'b') => {
    if (!profile) return;
    if (battle.myVote) return;
    setVoting(battle.id + choice);
    const { error: voteErr } = await supabase.from('pvp_votes').insert({
      battle_id: battle.id,
      user_id: profile.id,
      choice,
    });
    if (voteErr) {
      setStatus('Ошибка при голосовании');
      setVoting(null);
      return;
    }
    // update vote counts
    const update = choice === 'a'
      ? { votes_a: battle.votes_a + 1 }
      : { votes_b: battle.votes_b + 1 };
    await supabase.from('pvp_battles').update(update).eq('id', battle.id);
    setVoting(null);
    await addXp(5);
    fetchBattles();
  };

  // check for ended battles and award winner
  useEffect(() => {
    if (!profile) return;
    battles.forEach(async (b) => {
      if (b.status === 'active' && new Date(b.ends_at) < new Date()) {
        let winnerId: string | null = null;
        if (b.votes_a > b.votes_b) winnerId = b.creator_a_id;
        else if (b.votes_b > b.votes_a) winnerId = b.creator_b_id;
        await supabase
          .from('pvp_battles')
          .update({ status: 'completed', winner_id: winnerId })
          .eq('id', b.id);
        // award double XP to winner (200 = 2x of 100)
        if (winnerId === profile.id) {
          await addXp(200);
        }
        fetchBattles();
      }
    });
  }, [battles, profile, addXp, fetchBattles]);

  const coverFor = (b: Beat | null) => b?.cover_url || '/cover-igotu.webp';

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-theme-text flex items-center gap-2">
            <Swords className="w-6 h-6 text-theme-primary" />
            PvP Битвы
          </h1>
          <p className="text-theme-muted text-sm mt-1">
            Битвы битов — выбирай лучший и зарабатывай XP
          </p>
        </div>
        <button
          onClick={() => setShowCreate(true)}
          className="px-4 py-2 bg-theme-primary text-white rounded-lg text-sm font-medium hover:bg-theme-primary-hover transition-colors flex items-center gap-2"
        >
          <Plus className="w-4 h-4" /> Создать битву
        </button>
      </div>

      {status && (
        <div className="px-4 py-2 rounded-lg bg-theme-primary-bg border border-theme-primary-border text-theme-primary-text text-sm">
          {status}
        </div>
      )}

      {loading ? (
        <div className="flex items-center justify-center py-12">
          <Loader2 className="w-6 h-6 text-theme-muted animate-spin" />
        </div>
      ) : battles.length === 0 ? (
        <div className="glass-surface bg-theme-surface/50 border border-theme-border rounded-2xl p-8 text-center">
          <Swords className="w-12 h-12 text-theme-muted mx-auto mb-3" />
          <p className="text-theme-muted">Активных битв пока нет. Создай первую!</p>
        </div>
      ) : (
        <div className="space-y-4">
          {battles.map((battle) => {
            const totalVotes = battle.votes_a + battle.votes_b;
            const pctA = totalVotes > 0 ? (battle.votes_a / totalVotes) * 100 : 50;
            const pctB = totalVotes > 0 ? (battle.votes_b / totalVotes) * 100 : 50;
            const isCompleted = battle.status === 'completed';
            const iWon = battle.winner_id === profile?.id;
            return (
              <div
                key={battle.id}
                className="glass-surface bg-theme-surface/60 border border-theme-border rounded-2xl p-4"
              >
                <div className="flex items-center justify-between mb-3">
                  <span className={`px-2 py-0.5 rounded-md text-xs font-medium ${
                    isCompleted ? 'bg-theme-surface2 text-theme-muted' : 'bg-theme-success/15 text-theme-success'
                  }`}>
                    {isCompleted ? 'Завершено' : 'Активно'}
                  </span>
                  <span className="text-xs text-theme-muted">{totalVotes} голосов</span>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  {/* Beat A */}
                  <button
                    onClick={() => !isCompleted && vote(battle, 'a')}
                    disabled={isCompleted || battle.myVote !== null || voting !== null}
                    className={`relative rounded-xl border p-3 transition-all text-left disabled:cursor-default ${
                      battle.myVote === 'a'
                        ? 'border-theme-primary bg-theme-primary-bg'
                        : isCompleted && battle.winner_id === battle.creator_a_id
                        ? 'border-theme-warning bg-theme-warning/10'
                        : 'border-theme-border bg-theme-surface2 hover:border-theme-primary'
                    }`}
                  >
                    {isCompleted && battle.winner_id === battle.creator_a_id && (
                      <div className="absolute -top-2 -right-2 px-2 py-0.5 rounded-full bg-theme-warning text-white text-[10px] font-bold flex items-center gap-1">
                        <Crown className="w-3 h-3" /> Победитель
                      </div>
                    )}
                    <img src={coverFor(battle.beatA)} alt="" className="w-full h-20 rounded-lg object-cover mb-2" />
                    <p className="text-sm text-theme-text font-medium truncate">{battle.beatA?.title || 'Бит A'}</p>
                    <p className="text-xs text-theme-muted">{battle.beatA?.genre || '—'}</p>
                    <div className="mt-2 h-1.5 bg-theme-surface rounded-full overflow-hidden">
                      <div className="h-full bg-theme-primary rounded-full transition-all" style={{ width: `${pctA}%` }} />
                    </div>
                    <p className="text-xs text-theme-muted mt-1">{Math.round(pctA)}% · {battle.votes_a} голосов</p>
                    {battle.myVote === 'a' && (
                      <p className="text-xs text-theme-primary mt-1 flex items-center gap-1">
                        <Vote className="w-3 h-3" /> Твой голос
                      </p>
                    )}
                  </button>

                  {/* Beat B */}
                  <button
                    onClick={() => !isCompleted && vote(battle, 'b')}
                    disabled={isCompleted || battle.myVote !== null || voting !== null}
                    className={`relative rounded-xl border p-3 transition-all text-left disabled:cursor-default ${
                      battle.myVote === 'b'
                        ? 'border-theme-accent bg-theme-primary-bg'
                        : isCompleted && battle.winner_id === battle.creator_b_id
                        ? 'border-theme-warning bg-theme-warning/10'
                        : 'border-theme-border bg-theme-surface2 hover:border-theme-accent'
                    }`}
                  >
                    {isCompleted && battle.winner_id === battle.creator_b_id && (
                      <div className="absolute -top-2 -right-2 px-2 py-0.5 rounded-full bg-theme-warning text-white text-[10px] font-bold flex items-center gap-1">
                        <Crown className="w-3 h-3" /> Победитель
                      </div>
                    )}
                    <img src={coverFor(battle.beatB)} alt="" className="w-full h-20 rounded-lg object-cover mb-2" />
                    <p className="text-sm text-theme-text font-medium truncate">{battle.beatB?.title || 'Бит B'}</p>
                    <p className="text-xs text-theme-muted">{battle.beatB?.genre || '—'}</p>
                    <div className="mt-2 h-1.5 bg-theme-surface rounded-full overflow-hidden">
                      <div className="h-full bg-theme-accent rounded-full transition-all" style={{ width: `${pctB}%` }} />
                    </div>
                    <p className="text-xs text-theme-muted mt-1">{Math.round(pctB)}% · {battle.votes_b} голосов</p>
                    {battle.myVote === 'b' && (
                      <p className="text-xs text-theme-primary mt-1 flex items-center gap-1">
                        <Vote className="w-3 h-3" /> Твой голос
                      </p>
                    )}
                  </button>
                </div>

                {/* VS divider */}
                <div className="flex items-center justify-center -mt-[calc(50%+12px)] pointer-events-none" style={{ marginTop: '-88px' }}>
                  <span className="px-3 py-1 rounded-full bg-theme-surface border border-theme-border text-theme-text text-xs font-bold">
                    VS
                  </span>
                </div>

                {isCompleted && battle.winner_id && (
                  <div className="mt-3 flex items-center justify-center gap-2 text-sm">
                    <Trophy className="w-4 h-4 text-theme-warning" />
                    <span className="text-theme-text">
                      Победитель: {battle.winner_id === battle.creator_a_id ? battle.beatA?.title : battle.beatB?.title}
                    </span>
                    {iWon && (
                      <span className="px-2 py-0.5 rounded-md bg-theme-warning/15 text-theme-warning text-xs font-bold flex items-center gap-1">
                        <Zap className="w-3 h-3" /> 2x XP
                      </span>
                    )}
                  </div>
                )}
                {!isCompleted && battle.myVote === null && (
                  <p className="text-xs text-theme-muted text-center mt-3">Нажми на бит, чтобы отдать голос (+5 XP)</p>
                )}
                {!isCompleted && battle.myVote !== null && (
                  <p className="text-xs text-theme-success text-center mt-3">Спасибо за голос!</p>
                )}
              </div>
            );
          })}
        </div>
      )}

      {/* Create battle modal */}
      {showCreate && (
        <div
          className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4"
          onClick={() => setShowCreate(false)}
        >
          <div
            className="glass-surface bg-theme-surface border border-theme-border rounded-2xl p-6 w-full max-w-lg space-y-4 max-h-[80vh] overflow-y-auto"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between">
              <h3 className="text-theme-text font-semibold flex items-center gap-2">
                <Swords className="w-5 h-5 text-theme-primary" /> Новая битва
              </h3>
              <button onClick={() => setShowCreate(false)} className="text-theme-muted hover:text-theme-text">
                <X className="w-5 h-5" />
              </button>
            </div>
            <p className="text-xs text-theme-muted">Выбери два своих бита для битвы</p>

            {myBeats.length < 2 ? (
              <p className="text-sm text-theme-muted text-center py-4">
                Нужно минимум 2 бита. Создай их в секвенсоре!
              </p>
            ) : (
              <>
                <div>
                  <p className="text-xs text-theme-muted uppercase tracking-wider mb-2">Бит A</p>
                  <div className="space-y-1 max-h-40 overflow-y-auto">
                    {myBeats.map((b) => (
                      <button
                        key={b.id}
                        onClick={() => setSelectedA(b.id)}
                        className={`w-full flex items-center gap-2 px-2 py-1.5 rounded-lg text-left transition-colors ${
                          selectedA === b.id ? 'bg-theme-primary-bg border border-theme-primary-border' : 'hover:bg-theme-surface2'
                        }`}
                      >
                        <img src={coverFor(b)} alt="" className="w-8 h-8 rounded object-cover" />
                        <span className="text-sm text-theme-text truncate flex-1">{b.title}</span>
                        <span className="text-xs text-theme-muted">{b.genre}</span>
                      </button>
                    ))}
                  </div>
                </div>
                <div>
                  <p className="text-xs text-theme-muted uppercase tracking-wider mb-2">Бит B</p>
                  <div className="space-y-1 max-h-40 overflow-y-auto">
                    {myBeats.map((b) => (
                      <button
                        key={b.id}
                        onClick={() => setSelectedB(b.id)}
                        disabled={b.id === selectedA}
                        className={`w-full flex items-center gap-2 px-2 py-1.5 rounded-lg text-left transition-colors disabled:opacity-40 ${
                          selectedB === b.id ? 'bg-theme-primary-bg border border-theme-primary-border' : 'hover:bg-theme-surface2'
                        }`}
                      >
                        <img src={coverFor(b)} alt="" className="w-8 h-8 rounded object-cover" />
                        <span className="text-sm text-theme-text truncate flex-1">{b.title}</span>
                        <span className="text-xs text-theme-muted">{b.genre}</span>
                      </button>
                    ))}
                  </div>
                </div>
                <button
                  onClick={createBattle}
                  disabled={!selectedA || !selectedB || selectedA === selectedB}
                  className="w-full px-4 py-2 bg-theme-primary text-white rounded-lg text-sm font-medium hover:bg-theme-primary-hover transition-colors disabled:opacity-50"
                >
                  Начать битву
                </button>
              </>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
