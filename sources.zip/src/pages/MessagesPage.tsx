import { useState, useEffect, useRef, useCallback } from 'react';
import { useAuth } from '@/context/AuthContext';
import { supabase, type Profile, type PrivateMessage } from '@/lib/supabase';
import { MessageCircle, Send, Search, ArrowLeft, Circle, Check, CheckCheck } from 'lucide-react';

type Conversation = {
  user: Profile;
  lastMessage: PrivateMessage | null;
  unreadCount: number;
};

export default function MessagesPage() {
  const { profile } = useAuth();
  const [conversations, setConversations] = useState<Conversation[]>([]);
  const [selectedUser, setSelectedUser] = useState<Profile | null>(null);
  const [messages, setMessages] = useState<PrivateMessage[]>([]);
  const [newMessage, setNewMessage] = useState('');
  const [searchQuery, setSearchQuery] = useState('');
  const [searchResults, setSearchResults] = useState<Profile[]>([]);
  const [loading, setLoading] = useState(true);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const subscriptionRef = useRef<ReturnType<typeof supabase.channel> | null>(null);

  const loadConversations = useCallback(async () => {
    if (!profile) return;
    setLoading(true);

    // Get all messages involving this user
    const { data: msgs } = await supabase
      .from('private_messages')
      .select('*')
      .or(`sender_id.eq.${profile.id},recipient_id.eq.${profile.id}`)
      .order('created_at', { ascending: false });

    if (!msgs) {
      setLoading(false);
      return;
    }

    // Group by conversation partner
    const partnerIds = new Set<string>();
    (msgs as PrivateMessage[]).forEach((m) => {
      if (m.sender_id === profile.id) partnerIds.add(m.recipient_id);
      else partnerIds.add(m.sender_id);
    });

    // Fetch partner profiles
    const partnerProfiles: Profile[] = [];
    if (partnerIds.size > 0) {
      const { data: profiles } = await supabase
        .from('profiles')
        .select('*')
        .in('id', [...partnerIds]);
      if (profiles) partnerProfiles.push(...(profiles as Profile[]));
    }

    // Build conversation list
    const convs: Conversation[] = partnerProfiles.map((user) => {
      const userMsgs = (msgs as PrivateMessage[]).filter(
        (m) => m.sender_id === user.id || m.recipient_id === user.id
      );
      const lastMessage = userMsgs[0] || null;
      const unreadCount = userMsgs.filter(
        (m) => m.recipient_id === profile.id && !m.read
      ).length;
      return { user, lastMessage, unreadCount };
    });

    // Sort by last message time
    convs.sort((a, b) => {
      const aTime = a.lastMessage?.created_at || '';
      const bTime = b.lastMessage?.created_at || '';
      return bTime.localeCompare(aTime);
    });

    setConversations(convs);
    setLoading(false);
  }, [profile]);

  useEffect(() => {
    loadConversations();
  }, [loadConversations]);

  // Subscribe to new messages
  useEffect(() => {
    if (!profile) return;

    const channel = supabase
      .channel('private-messages')
      .on(
        'postgres_changes',
        {
          event: 'INSERT',
          schema: 'public',
          table: 'private_messages',
          filter: `recipient_id=eq.${profile.id}`,
        },
        () => {
          loadConversations();
          if (selectedUser) loadMessages(selectedUser.id);
        }
      )
      .on(
        'postgres_changes',
        {
          event: 'INSERT',
          schema: 'public',
          table: 'private_messages',
          filter: `sender_id=eq.${profile.id}`,
        },
        () => {
          loadConversations();
          if (selectedUser) loadMessages(selectedUser.id);
        }
      )
      .on(
        'postgres_changes',
        {
          event: 'UPDATE',
          schema: 'public',
          table: 'private_messages',
          filter: `sender_id=eq.${profile.id}`,
        },
        () => {
          if (selectedUser) loadMessages(selectedUser.id);
        }
      )
      .subscribe();

    subscriptionRef.current = channel;

    return () => {
      supabase.removeChannel(channel);
    };
  }, [profile, selectedUser, loadConversations]);

  const loadMessages = useCallback(async (otherUserId: string) => {
    if (!profile) return;
    const { data } = await supabase
      .from('private_messages')
      .select('*')
      .or(`and(sender_id.eq.${profile.id},recipient_id.eq.${otherUserId}),and(sender_id.eq.${otherUserId},recipient_id.eq.${profile.id})`)
      .order('created_at', { ascending: true });

    if (data) {
      setMessages(data as PrivateMessage[]);
      // Mark as read
      await supabase
        .from('private_messages')
        .update({ read: true })
        .eq('recipient_id', profile.id)
        .eq('sender_id', otherUserId)
        .eq('read', false);
    }
  }, [profile]);

  useEffect(() => {
    if (selectedUser) {
      loadMessages(selectedUser.id);
    } else {
      setMessages([]);
    }
  }, [selectedUser, loadMessages]);

  // Scroll to bottom when messages change
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const sendMessage = async () => {
    if (!profile || !selectedUser || !newMessage.trim()) return;
    const content = newMessage.trim();
    setNewMessage('');

    const { data } = await supabase
      .from('private_messages')
      .insert({
        sender_id: profile.id,
        recipient_id: selectedUser.id,
        content,
      })
      .select('*')
      .single();

    if (data) {
      setMessages((prev) => [...prev, data as PrivateMessage]);
      loadConversations();
    }
  };

  const searchUsers = async () => {
    if (!searchQuery.trim() || !profile) return;
    const { data } = await supabase
      .from('profiles')
      .select('*')
      .ilike('username', `%${searchQuery}%`)
      .neq('id', profile.id)
      .limit(10);
    if (data) setSearchResults(data as Profile[]);
  };

  const startConversation = (user: Profile) => {
    setSelectedUser(user);
    setSearchQuery('');
    setSearchResults([]);
    loadMessages(user.id);
  };

  const formatTime = (iso: string) => {
    const d = new Date(iso);
    const now = new Date();
    const diff = (now.getTime() - d.getTime()) / 1000;
    if (diff < 60) return 'сейчас';
    if (diff < 3600) return `${Math.floor(diff / 60)} мин`;
    if (diff < 86400) return d.toLocaleTimeString('ru', { hour: '2-digit', minute: '2-digit' });
    return d.toLocaleDateString('ru', { day: 'numeric', month: 'short' });
  };

  const formatMessageTime = (iso: string) => {
    return new Date(iso).toLocaleTimeString('ru', { hour: '2-digit', minute: '2-digit' });
  };

  if (!profile) return null;

  // Chat view
  if (selectedUser) {
    return (
      <div className="space-y-4">
        <div className="flex items-center gap-3">
          <button
            onClick={() => setSelectedUser(null)}
            className="p-2 text-theme-muted hover:text-theme-text transition-colors"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          {selectedUser.avatar_url ? (
            <img src={selectedUser.avatar_url} alt="" className="w-10 h-10 rounded-full object-cover" />
          ) : (
            <div className="w-10 h-10 rounded-full bg-gradient-to-br from-theme-primary to-theme-accent flex items-center justify-center text-white text-sm font-bold">
              {selectedUser.username[0]?.toUpperCase()}
            </div>
          )}
          <div className="flex-1">
            <p className="text-theme-text font-medium text-sm">{selectedUser.username}</p>
            <div className="flex items-center gap-1.5">
              <Circle
                className={`w-2.5 h-2.5 ${selectedUser.is_online ? 'fill-theme-success text-theme-success' : 'fill-theme-muted text-theme-muted'}`}
              />
              <span className="text-xs text-theme-muted">
                {selectedUser.is_online ? 'В сети' : `Был в сети ${formatTime(selectedUser.last_seen)}`}
              </span>
            </div>
          </div>
        </div>

        <div className="glass-surface bg-theme-surface/50 border border-theme-border rounded-2xl flex flex-col h-[60vh]">
          <div className="flex-1 overflow-y-auto p-4 space-y-3">
            {messages.length === 0 ? (
              <div className="flex items-center justify-center h-full">
                <p className="text-theme-muted text-sm">Нет сообщений. Напиши первым!</p>
              </div>
            ) : (
              messages.map((msg) => {
                const isMine = msg.sender_id === profile.id;
                return (
                  <div key={msg.id} className={`flex ${isMine ? 'justify-end' : 'justify-start'}`}>
                    <div
                      className={`max-w-[75%] px-4 py-2.5 rounded-2xl text-sm ${
                        isMine
                          ? 'bg-theme-primary text-white rounded-br-sm'
                          : 'bg-theme-surface2 text-theme-text rounded-bl-sm'
                      }`}
                    >
                      <p className="break-words">{msg.content}</p>
                      <div className={`flex items-center gap-1 mt-1 ${isMine ? 'justify-end' : 'justify-start'}`}>
                        <span className={`text-xs ${isMine ? 'text-white/60' : 'text-theme-muted'}`}>
                          {formatMessageTime(msg.created_at)}
                        </span>
                        {isMine && (
                          <span className={msg.read ? 'text-white/80' : 'text-white/50'}>
                            {msg.read ? <CheckCheck className="w-3.5 h-3.5" /> : <Check className="w-3.5 h-3.5" />}
                          </span>
                        )}
                      </div>
                    </div>
                  </div>
                );
              })
            )}
            <div ref={messagesEndRef} />
          </div>

          <div className="border-t border-theme-border p-3 flex items-center gap-2">
            <input
              type="text"
              value={newMessage}
              onChange={(e) => setNewMessage(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && sendMessage()}
              placeholder="Написать сообщение..."
              className="flex-1 px-4 py-2.5 bg-theme-surface2 border border-theme-border rounded-xl text-theme-text text-sm focus:outline-none focus:border-theme-primary transition-colors"
            />
            <button
              onClick={sendMessage}
              disabled={!newMessage.trim()}
              className="p-2.5 bg-theme-primary text-white rounded-xl hover:bg-theme-primary-hover transition-colors disabled:opacity-50"
            >
              <Send className="w-5 h-5" />
            </button>
          </div>
        </div>
      </div>
    );
  }

  // Conversation list view
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-theme-text flex items-center gap-2">
          <MessageCircle className="w-6 h-6 text-theme-primary" />
          Сообщения
        </h1>
        <p className="text-theme-muted text-sm mt-1">
          Личные сообщения с другими пользователями
        </p>
      </div>

      {/* Search users to start a conversation */}
      <div className="glass-surface bg-theme-surface/50 border border-theme-border rounded-2xl p-4">
        <h3 className="text-sm font-medium text-theme-text mb-3 flex items-center gap-2">
          <Search className="w-4 h-4 text-theme-muted" />
          Найти пользователя
        </h3>
        <div className="flex gap-2">
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && searchUsers()}
            placeholder="Введи имя пользователя..."
            className="flex-1 px-4 py-2.5 bg-theme-surface2 border border-theme-border rounded-xl text-theme-text text-sm focus:outline-none focus:border-theme-primary transition-colors"
          />
          <button
            onClick={searchUsers}
            className="px-4 py-2.5 bg-theme-primary text-white rounded-xl text-sm font-medium hover:bg-theme-primary-hover transition-colors"
          >
            Найти
          </button>
        </div>
        {searchResults.length > 0 && (
          <div className="mt-3 space-y-2">
            {searchResults.map((user) => (
              <button
                key={user.id}
                onClick={() => startConversation(user)}
                className="w-full flex items-center gap-3 p-2.5 bg-theme-surface2 rounded-lg hover:bg-theme-border transition-colors"
              >
                {user.avatar_url ? (
                  <img src={user.avatar_url} alt="" className="w-9 h-9 rounded-full object-cover" />
                ) : (
                  <div className="w-9 h-9 rounded-full bg-gradient-to-br from-theme-primary to-theme-accent flex items-center justify-center text-white text-xs font-bold">
                    {user.username[0]?.toUpperCase()}
                  </div>
                )}
                <div className="flex-1 text-left">
                  <p className="text-sm text-theme-text font-medium">{user.username}</p>
                  <p className="text-xs text-theme-muted">Уровень {user.level}</p>
                </div>
                <Circle
                  className={`w-2.5 h-2.5 ${user.is_online ? 'fill-theme-success text-theme-success' : 'fill-theme-muted text-theme-muted'}`}
                />
              </button>
            ))}
          </div>
        )}
      </div>

      {/* Conversations list */}
      <div>
        <h3 className="text-sm font-medium text-theme-muted mb-3">Диалоги</h3>
        {loading ? (
          <p className="text-theme-muted text-sm text-center py-8">Загрузка...</p>
        ) : conversations.length === 0 ? (
          <div className="glass-surface bg-theme-surface/50 border border-theme-border rounded-2xl p-8 text-center">
            <MessageCircle className="w-10 h-10 text-theme-muted mx-auto mb-3" />
            <p className="text-theme-muted text-sm">Пока нет диалогов. Найди пользователя выше, чтобы начать общение!</p>
          </div>
        ) : (
          <div className="space-y-2">
            {conversations.map((conv) => (
              <button
                key={conv.user.id}
                onClick={() => startConversation(conv.user)}
                className="w-full glass-surface flex items-center gap-3 p-3 bg-theme-surface/50 border border-theme-border rounded-xl hover:border-theme-primary transition-all"
              >
                {conv.user.avatar_url ? (
                  <img src={conv.user.avatar_url} alt="" className="w-11 h-11 rounded-full object-cover" />
                ) : (
                  <div className="w-11 h-11 rounded-full bg-gradient-to-br from-theme-primary to-theme-accent flex items-center justify-center text-white text-sm font-bold">
                    {conv.user.username[0]?.toUpperCase()}
                  </div>
                )}
                <div className="flex-1 min-w-0 text-left">
                  <div className="flex items-center gap-2">
                    <p className="text-sm text-theme-text font-medium truncate">{conv.user.username}</p>
                    <Circle
                      className={`w-2 h-2 shrink-0 ${conv.user.is_online ? 'fill-theme-success text-theme-success' : 'fill-theme-muted text-theme-muted'}`}
                    />
                  </div>
                  <p className="text-xs text-theme-muted truncate">
                    {conv.lastMessage
                      ? (conv.lastMessage.sender_id === profile.id ? 'Ты: ' : '') + conv.lastMessage.content
                      : 'Нет сообщений'}
                  </p>
                </div>
                <div className="flex flex-col items-end gap-1 shrink-0">
                  {conv.lastMessage && (
                    <span className="text-xs text-theme-muted">
                      {formatTime(conv.lastMessage.created_at)}
                    </span>
                  )}
                  {conv.unreadCount > 0 && (
                    <span className="px-2 py-0.5 text-xs font-bold bg-theme-primary text-white rounded-full">
                      {conv.unreadCount}
                    </span>
                  )}
                </div>
              </button>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
