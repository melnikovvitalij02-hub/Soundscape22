import type { CSSProperties } from 'react';
import type { Page } from '@/components/Sidebar';
import { useAuth } from '@/context/AuthContext';
import {
  ArrowDown,
  ArrowRight,
  BarChart3,
  Drum,
  Gamepad2,
  Headphones,
  Mic,
  Music2,
  Search,
  Sparkles,
} from 'lucide-react';

const stars = [
  { left: '8%', top: '18%', size: 2, delay: '0s' },
  { left: '17%', top: '32%', size: 3, delay: '1s' },
  { left: '28%', top: '14%', size: 2, delay: '2.5s' },
  { left: '41%', top: '27%', size: 2, delay: '.8s' },
  { left: '55%', top: '11%', size: 3, delay: '1.8s' },
  { left: '68%', top: '24%', size: 2, delay: '3s' },
  { left: '82%', top: '17%', size: 2, delay: '1.2s' },
  { left: '91%', top: '38%', size: 3, delay: '2.1s' },
  { left: '12%', top: '54%', size: 2, delay: '1.5s' },
  { left: '33%', top: '62%', size: 2, delay: '3.3s' },
  { left: '74%', top: '58%', size: 2, delay: '.4s' },
];

const quickLinks: { id: Page; label: string; icon: typeof Music2 }[] = [
  { id: 'beat', label: 'Создать бит', icon: Drum },
  { id: 'studio', label: 'Открыть студию', icon: Mic },
  { id: 'search', label: 'Найти музыку', icon: Search },
  { id: 'charts', label: 'Смотреть чарты', icon: BarChart3 },
  { id: 'games', label: 'Играть', icon: Gamepad2 },
];

export default function HomePage({ setPage }: { setPage: (p: Page) => void }) {
  const { profile } = useAuth();
  const displayName = profile?.username || 'исследователь';

  return (
    <div className="soundscape-home">
      <section className="soundscape-hero">
        <div className="soundscape-stars" aria-hidden="true">
          {stars.map((star, index) => (
            <span
              key={index}
              className="soundscape-star"
              style={{
                left: star.left,
                top: star.top,
                width: star.size,
                height: star.size,
                animationDelay: star.delay,
              }}
            />
          ))}
        </div>
        <div className="soundscape-aurora soundscape-aurora-one" />
        <div className="soundscape-aurora soundscape-aurora-two" />
        <div className="soundscape-orbit soundscape-orbit-one" />
        <div className="soundscape-orbit soundscape-orbit-two" />

        <div className="soundscape-hero-content">
          <div className="soundscape-kicker">
            <span className="soundscape-kicker-line" />
            <span>Добро пожаловать, {displayName}</span>
          </div>
          <h1>
            Музыка,
            <br />
            которая <em>живёт</em>
            <br />
            внутри тебя.
          </h1>
          <p>
            Твоя личная вселенная звука. Создавай, находи и слушай музыку,
            которая превращает обычный день в путешествие.
          </p>
          <div className="soundscape-hero-actions">
            <button className="soundscape-primary-button" onClick={() => setPage('beat')}>
              Начать создавать
              <ArrowRight size={16} />
            </button>
            <button className="soundscape-text-button" onClick={() => setPage('search')}>
              Исследовать музыку
              <ArrowDown size={15} />
            </button>
          </div>
        </div>

        <div className="soundscape-vertical-label">ВКЛЮЧИ СВОЙ SOUNDscape</div>
        <div className="soundscape-scroll-cue">
          <span>SCROLL TO EXPLORE</span>
          <ArrowDown size={14} />
        </div>
      </section>

      <section className="soundscape-intro">
        <div>
          <span className="soundscape-section-label">01 / THE SOUND UNIVERSE</span>
          <h2>
            Твоя музыка.
            <br />
            Твои правила.
          </h2>
        </div>
        <div className="soundscape-intro-copy">
          <p>
            Soundscape Pro собирает всё, что нужно для музыкального путешествия,
            в одном пространстве — от первого ритма до любимого трека.
          </p>
          <button className="soundscape-outline-button" onClick={() => setPage('studio')}>
            Открыть студию <ArrowRight size={15} />
          </button>
        </div>
      </section>

      <section className="soundscape-tools">
        <div className="soundscape-tools-heading">
          <div>
            <span className="soundscape-section-label">02 / YOUR FREQUENCY</span>
            <h2>Настройся на<br /><em>свою частоту.</em></h2>
          </div>
          <Headphones className="soundscape-headphones" size={52} strokeWidth={1} />
        </div>
        <div className="soundscape-tool-grid">
          {quickLinks.map((link, index) => {
            const Icon = link.icon;
            return (
              <button
                key={link.id}
                className="soundscape-tool-card"
                onClick={() => setPage(link.id)}
                style={{ '--tool-index': index } as CSSProperties}
              >
                <span className="soundscape-tool-number">0{index + 1}</span>
                <span className="soundscape-tool-icon"><Icon size={21} /></span>
                <span className="soundscape-tool-label">{link.label}</span>
                <ArrowRight className="soundscape-tool-arrow" size={17} />
              </button>
            );
          })}
        </div>
      </section>

      <section className="soundscape-bottom-cta">
        <Sparkles size={18} />
        <span>Звук начинается с тебя</span>
        <button onClick={() => setPage('profile')}>Настроить профиль <ArrowRight size={14} /></button>
      </section>
    </div>
  );
}
