import { useState, useEffect, useRef, type CSSProperties } from 'react';
import type { Page } from '@/components/Sidebar';
import {
  ArrowRight,
  ArrowDown,
  Music,
  Mic,
  Drum,
  Users,
  Radio,
  Headphones,
  Sparkles,
  Star,
  Quote,
  Check,
  Zap,
} from 'lucide-react';

const stars = [
  { left: '8%', top: '18%', size: 2, delay: '0s' },
  { left: '17%', top: '32%', size: 3, delay: '1s' },
  { left: '28%', top: '14%', size: 2, delay: '2.5s' },
  { left: '41%', top: '27%', size: 2, delay: '.8s' },
  { left: '55%', top: '11%', size: 3, delay: '1.8s' },
  { left: '68%', top: '24%', size: 2, delay: '3s' },
  { left: '82%', top: '17%', size: 2, delay: '1.2s' },
  { left: '91%', top: '38%', size: 3, delay: '2.1s' },
  { left: '12%', top: '54%', size: 2, delay: '1.5s' },
  { left: '33%', top: '62%', size: 2, delay: '3.3s' },
  { left: '74%', top: '58%', size: 2, delay: '.4s' },
];

const features = [
  {
    icon: Drum,
    title: 'Бит-секвенсор',
    description:
      'Создавай биты прямо в браузере. Полноценная сетка шагов, пресеты инструментов и экспорт в один клик.',
    color: 'from-purple-500 to-pink-500',
  },
  {
    icon: Mic,
    title: 'ИИ Студия',
    description:
      'Записывай вокал, миксуй треки и используй нейросетевые эффекты для профессионального звучания.',
    color: 'from-cyan-500 to-blue-500',
  },
  {
    icon: Radio,
    title: 'Прямые эфиры',
    description:
      'Стримь свою музыку в реальном времени. Общайся с слушателями в чате и получай сердечки.',
    color: 'from-red-500 to-orange-500',
  },
  {
    icon: Users,
    title: 'Сообщества',
    description:
      'Объединяйся с единомышленниками по жанрам. Lo-Fi, Трэп, Рок — найди свою музыкальную семью.',
    color: 'from-emerald-500 to-teal-500',
  },
  {
    icon: Headphones,
    title: 'Чарты и поиск',
    description:
      'Слушай топ-чарты и находи новую музыку. Тысячи треков доступны прямо в браузере.',
    color: 'from-amber-500 to-yellow-500',
  },
  {
    icon: Sparkles,
    title: 'Геймификация',
    description:
      'Получай XP за каждое действие, повышай уровень, открывай ачивки и зарабатывай монеты.',
    color: 'from-pink-500 to-rose-500',
  },
];

const stats = [
  { label: 'Треков создано', value: 125000, suffix: '+' },
  { label: 'Пользователей', value: 48000, suffix: '+' },
  { label: 'Битов опубликовано', value: 89000, suffix: '+' },
  { label: 'Часов прослушано', value: 2100000, suffix: '+' },
];

const testimonials = [
  {
    name: 'Алексей «DJ_Smooth»',
    role: 'Продюсер, 3 года на платформе',
    avatar: '/avatar-fox.webp',
    text: 'Soundscape Pro полностью изменил мой подход к созданию музыки. Бит-секвенсор — это просто восторг, а сообщество Lo-Fi стало моей второй семьёй.',
  },
  {
    name: 'Мария «GrooveQueen»',
    role: 'Диджей и стример',
    avatar: '/avatar-cat.webp',
    text: 'Прямые эфиры здесь — это нечто. Я стримлю каждый вечер и общаюсь с слушателями в реальном времени. Лучший опыт, что я видела.',
  },
  {
    name: 'Дмитрий «BeatMaster99»',
    role: 'Хип-хоп продюсер',
    avatar: '/avatar-dragon.webp',
    text: 'Геймификация затягивает! Получать XP за создание битов — это гениально. За полгода я поднялся с 1 до 47 уровня и ни разу не пожалел.',
  },
];

const pricingFeatures = [
  'Безлимитное создание треков',
  'Эксклюзивные пресеты и сэмплы',
  'Приоритет в чарах и эфирах',
  'Премиум-аватары и бейджи',
  'Двойной XP навсегда',
  'Реклама отключена',
];

export default function AboutPage({ setPage }: { setPage: (p: Page) => void }) {
  return (
    <div className="soundscape-home">
      {/* ===== HERO ===== */}
      <section className="soundscape-hero">
        <div className="soundscape-stars" aria-hidden="true">
          {stars.map((star, index) => (
            <span
              key={index}
              className="soundscape-star"
              style={{
                left: star.left,
                top: star.top,
                width: star.size,
                height: star.size,
                animationDelay: star.delay,
              }}
            />
          ))}
        </div>
        <div className="soundscape-aurora soundscape-aurora-one" />
        <div className="soundscape-aurora soundscape-aurora-two" />
        <div className="soundscape-orbit soundscape-orbit-one" />
        <div className="soundscape-orbit soundscape-orbit-two" />

        <div className="soundscape-hero-content">
          <div className="soundscape-kicker">
            <span className="soundscape-kicker-line" />
            <span>О платформе</span>
          </div>
          <h1>
            Soundscape
            <br />
            <em>Pro</em>
          </h1>
          <p>
            Музыкальная вселенная, где каждый ритм становится историей. Создавай,
            слушай и делись музыкой в пространстве, созданном для тебя.
          </p>
          <div className="soundscape-hero-actions">
            <button className="soundscape-primary-button" onClick={() => setPage('home')}>
              Начать путешествие
              <ArrowRight size={16} />
            </button>
            <button className="soundscape-text-button" onClick={() => setPage('search')}>
              Слушать музыку
              <ArrowDown size={15} />
            </button>
          </div>
        </div>

        <div className="soundscape-vertical-label">SOUNDSCAPE PRO · 2026</div>
        <div className="soundscape-scroll-cue">
          <span>SCROLL TO EXPLORE</span>
          <ArrowDown size={14} />
        </div>
      </section>

      {/* ===== STATS ===== */}
      <StatsSection />

      {/* ===== FEATURES ===== */}
      <section className="soundscape-tools">
        <div className="soundscape-tools-heading">
          <div>
            <span className="soundscape-section-label">01 / ВОЗМОЖНОСТИ</span>
            <h2>
              Всё для музыки
              <br />
              <em>в одном месте.</em>
            </h2>
          </div>
          <Headphones className="soundscape-headphones" size={52} strokeWidth={1} />
        </div>
        <div className="soundscape-tool-grid">
          {features.map((f, index) => {
            const Icon = f.icon;
            return (
              <div
                key={f.title}
                className="soundscape-tool-card"
                style={{ '--tool-index': index } as CSSProperties}
              >
                <span className="soundscape-tool-number">0{index + 1}</span>
                <span className="soundscape-tool-icon">
                  <Icon size={21} />
                </span>
                <span className="soundscape-tool-label">{f.title}</span>
                <p style={{ fontSize: '0.9rem', lineHeight: 1.6, color: 'rgba(232,232,240,0.5)', margin: 0 }}>
                  {f.description}
                </p>
                <ArrowRight className="soundscape-tool-arrow" size={17} />
              </div>
            );
          })}
        </div>
      </section>

      {/* ===== TESTIMONIALS ===== */}
      <section style={{ padding: '0 7vw 100px' }}>
        <div style={{ marginBottom: '48px' }}>
          <span className="soundscape-section-label">02 / ОТЗЫВЫ</span>
          <h2 style={{ fontSize: 'clamp(2rem, 4.5vw, 3.5rem)', fontWeight: 700, lineHeight: 1.05, letterSpacing: '-0.02em', color: '#f5f5fa', margin: 0 }}>
            Что говорят
            <br />
            <em style={{ fontStyle: 'italic', fontWeight: 300, color: 'rgba(232,232,240,0.4)' }}>
              наши пользователи.
            </em>
          </h2>
        </div>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(280px, 1fr))', gap: '24px' }}>
          {testimonials.map((t) => (
            <div
              key={t.name}
              style={{
                background: 'rgba(255,255,255,0.03)',
                border: '1px solid rgba(255,255,255,0.06)',
                borderRadius: '20px',
                padding: '32px 28px',
              }}
            >
              <Quote size={28} style={{ color: 'rgba(0,229,208,0.4)', marginBottom: '16px' }} />
              <p style={{ fontSize: '0.95rem', lineHeight: 1.7, color: 'rgba(232,232,240,0.7)', marginBottom: '24px' }}>
                {t.text}
              </p>
              <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
                <img src={t.avatar} alt="" style={{ width: '44px', height: '44px', borderRadius: '50%', objectFit: 'cover' }} />
                <div>
                  <p style={{ fontSize: '0.9rem', fontWeight: 600, color: '#f5f5fa', margin: 0 }}>{t.name}</p>
                  <p style={{ fontSize: '0.75rem', color: 'rgba(232,232,240,0.4)', margin: 0 }}>{t.role}</p>
                </div>
                <div style={{ marginLeft: 'auto', display: 'flex', gap: '2px' }}>
                  {[0, 1, 2, 3, 4].map((i) => (
                    <Star key={i} size={12} style={{ color: '#00e5d0', fill: '#00e5d0' }} />
                  ))}
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* ===== PRICING ===== */}
      <section style={{ padding: '0 7vw 100px' }}>
        <div style={{ textAlign: 'center', marginBottom: '48px' }}>
          <span className="soundscape-section-label" style={{ textAlign: 'center' }}>
            03 / ПРЕМИУМ
          </span>
          <h2 style={{ fontSize: 'clamp(2rem, 4.5vw, 3.5rem)', fontWeight: 700, lineHeight: 1.05, letterSpacing: '-0.02em', color: '#f5f5fa', margin: 0 }}>
            Soundscape <em style={{ fontStyle: 'italic', fontWeight: 300, background: 'linear-gradient(135deg, #00e5d0, #b07ee0)', WebkitBackgroundClip: 'text', backgroundClip: 'text', WebkitTextFillColor: 'transparent' }}>Pro</em>
          </h2>
          <p style={{ fontSize: '1rem', color: 'rgba(232,232,240,0.5)', marginTop: '16px' }}>
            Открой все возможности платформы
          </p>
        </div>
        <div style={{ display: 'flex', justifyContent: 'center' }}>
          <div
            style={{
              maxWidth: '420px',
              width: '100%',
              background: 'linear-gradient(135deg, rgba(0,229,208,0.08), rgba(176,126,224,0.08))',
              border: '1px solid rgba(0,229,208,0.3)',
              borderRadius: '24px',
              padding: '40px 32px',
              position: 'relative',
            }}
          >
            <div
              style={{
                position: 'absolute',
                top: '-12px',
                left: '50%',
                transform: 'translateX(-50%)',
                padding: '4px 16px',
                background: 'linear-gradient(135deg, #00e5d0, #b07ee0)',
                borderRadius: '100px',
                fontSize: '11px',
                fontWeight: 600,
                letterSpacing: '0.1em',
                textTransform: 'uppercase',
                color: '#03030a',
              }}
            >
              Популярный
            </div>
            <div style={{ textAlign: 'center', marginBottom: '32px' }}>
              <p style={{ fontSize: '0.85rem', color: 'rgba(232,232,240,0.5)', marginBottom: '8px' }}>Ежемесячная подписка</p>
              <div style={{ display: 'flex', alignItems: 'baseline', justifyContent: 'center', gap: '4px' }}>
                <span style={{ fontSize: '3rem', fontWeight: 800, color: '#f5f5fa' }}>299</span>
                <span style={{ fontSize: '1rem', color: 'rgba(232,232,240,0.5)' }}>₽/мес</span>
              </div>
            </div>
            <div style={{ spaceY: '12px' }}>
              {pricingFeatures.map((f) => (
                <div key={f} style={{ display: 'flex', alignItems: 'center', gap: '12px', marginBottom: '14px' }}>
                  <div style={{ width: '20px', height: '20px', borderRadius: '50%', background: 'rgba(0,229,208,0.2)', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
                    <Check size={12} style={{ color: '#00e5d0' }} />
                  </div>
                  <span style={{ fontSize: '0.9rem', color: 'rgba(232,232,240,0.8)' }}>{f}</span>
                </div>
              ))}
            </div>
            <button
              onClick={() => setPage('profile')}
              className="soundscape-primary-button"
              style={{ width: '100%', justifyContent: 'center', marginTop: '32px' }}
            >
              <Zap size={16} />
              Оформить подписку
            </button>
          </div>
        </div>
      </section>

      {/* ===== CTA ===== */}
      <section style={{ padding: '80px 7vw', textAlign: 'center', borderTop: '1px solid rgba(255,255,255,0.05)' }}>
        <Sparkles size={32} style={{ color: 'rgba(0,229,208,0.5)', margin: '0 auto 24px' }} />
        <h2 style={{ fontSize: 'clamp(2rem, 5vw, 3.5rem)', fontWeight: 800, lineHeight: 1.1, letterSpacing: '-0.02em', color: '#f5f5fa', margin: '0 0 16px' }}>
          Звук начинается <em style={{ fontStyle: 'italic', fontWeight: 300, background: 'linear-gradient(135deg, #00e5d0, #b07ee0)', WebkitBackgroundClip: 'text', backgroundClip: 'text', WebkitTextFillColor: 'transparent' }}>с тебя</em>
        </h2>
        <p style={{ fontSize: '1.1rem', color: 'rgba(232,232,240,0.5)', maxWidth: '480px', margin: '0 auto 40px' }}>
          Присоединяйся к тысячам музыкантов и слушателей. Твоя музыкальная вселенная ждёт.
        </p>
        <button className="soundscape-primary-button" onClick={() => setPage('beat')}>
          Начать создавать
          <ArrowRight size={16} />
        </button>
      </section>

      {/* ===== FOOTER ===== */}
      <footer style={{ padding: '40px 7vw', borderTop: '1px solid rgba(255,255,255,0.05)', textAlign: 'center' }}>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '8px', marginBottom: '12px' }}>
          <div style={{ width: '28px', height: '28px', borderRadius: '8px', background: 'linear-gradient(135deg, #00e5d0, #b07ee0)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
            <Music size={16} style={{ color: '#03030a' }} />
          </div>
          <span style={{ fontWeight: 700, fontSize: '0.9rem', color: '#f5f5fa' }}>Soundscape Pro</span>
        </div>
        <p style={{ fontSize: '0.8rem', color: 'rgba(232,232,240,0.3)' }}>
          © 2026 Soundscape Pro. Музыка, которая живёт внутри тебя.
        </p>
      </footer>
    </div>
  );
}

/* ---------- Animated Stats ---------- */

function StatsSection() {
  const [visible, setVisible] = useState(false);
  const ref = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        if (entries[0]?.isIntersecting) {
          setVisible(true);
          observer.disconnect();
        }
      },
      { threshold: 0.3 }
    );
    if (ref.current) observer.observe(ref.current);
    return () => observer.disconnect();
  }, []);

  return (
    <section ref={ref} style={{ padding: '100px 7vw', borderTop: '1px solid rgba(255,255,255,0.05)' }}>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(180px, 1fr))', gap: '32px', textAlign: 'center' }}>
        {stats.map((s) => (
          <div key={s.label}>
            <Counter value={s.value} suffix={s.suffix} active={visible} />
            <p style={{ fontSize: '0.85rem', color: 'rgba(232,232,240,0.5)', marginTop: '8px', textTransform: 'uppercase', letterSpacing: '0.1em' }}>
              {s.label}
            </p>
          </div>
        ))}
      </div>
    </section>
  );
}

function Counter({ value, suffix, active }: { value: number; suffix: string; active: boolean }) {
  const [display, setDisplay] = useState(0);

  useEffect(() => {
    if (!active) return;
    const duration = 2000;
    const start = performance.now();
    let raf = 0;
    const tick = (now: number) => {
      const elapsed = now - start;
      const progress = Math.min(elapsed / duration, 1);
      // ease-out
      const eased = 1 - Math.pow(1 - progress, 3);
      setDisplay(Math.floor(eased * value));
      if (progress < 1) {
        raf = requestAnimationFrame(tick);
      } else {
        setDisplay(value);
      }
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [active, value]);

  const formatted = display >= 1000 ? display.toLocaleString('ru-RU') : display.toString();

  return (
    <p style={{ fontSize: 'clamp(2rem, 4vw, 3rem)', fontWeight: 800, color: '#f5f5fa', margin: 0, lineHeight: 1 }}>
      {formatted}
      <span style={{ color: '#00e5d0' }}>{suffix}</span>
    </p>
  );
}
