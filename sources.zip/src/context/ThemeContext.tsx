import { createContext, useContext, useState, useEffect, type ReactNode } from 'react';

export type ThemeId = 'cosmos' | 'neon' | 'sunset' | 'minimal' | 'glass' | 'retrowave';

export type ThemeInfo = {
  id: ThemeId;
  name: string;
  emoji: string;
  gradient: string;
};

export const THEMES: ThemeInfo[] = [
  { id: 'cosmos', name: 'Космос', emoji: '🌌', gradient: 'from-violet-500 to-indigo-500' },
  { id: 'neon', name: 'Неон', emoji: '⚡', gradient: 'from-cyan-400 to-fuchsia-500' },
  { id: 'sunset', name: 'Закат', emoji: '🌅', gradient: 'from-orange-500 to-pink-500' },
  { id: 'minimal', name: 'Минимал', emoji: '⚪', gradient: 'from-blue-500 to-teal-500' },
  { id: 'glass', name: 'Стекло', emoji: '🪟', gradient: 'from-cyan-500 to-teal-500' },
  { id: 'retrowave', name: 'Ретро-вейв', emoji: '🌴', gradient: 'from-pink-500 to-cyan-400' },
];

type ThemeContextType = {
  theme: ThemeId;
  setTheme: (t: ThemeId) => void;
};

const ThemeContext = createContext<ThemeContextType | undefined>(undefined);

export function ThemeProvider({ children }: { children: ReactNode }) {
  const [theme, setThemeState] = useState<ThemeId>(() => {
    const saved = localStorage.getItem('soundscape-theme') as ThemeId | null;
    return saved || 'cosmos';
  });

  useEffect(() => {
    document.documentElement.setAttribute('data-theme', theme);
    localStorage.setItem('soundscape-theme', theme);
  }, [theme]);

  const setTheme = (t: ThemeId) => setThemeState(t);

  return <ThemeContext.Provider value={{ theme, setTheme }}>{children}</ThemeContext.Provider>;
}

export function useTheme() {
  const ctx = useContext(ThemeContext);
  if (!ctx) throw new Error('useTheme must be used within ThemeProvider');
  return ctx;
}
