import { createContext, useContext, useEffect, useState, useCallback, type ReactNode } from 'react';
import type { Session } from '@supabase/supabase-js';
import { supabase, type Profile } from '@/lib/supabase';

type AuthContextType = {
  session: Session | null;
  profile: Profile | null;
  loading: boolean;
  isGuest: boolean;
  signIn: (email: string, password: string) => Promise<{ error: string | null }>;
  signUp: (email: string, password: string, username: string) => Promise<{ error: string | null }>;
  signInGuest: () => void;
  signOut: () => Promise<void>;
  refreshProfile: () => Promise<void>;
  updateProfile: (updates: Partial<Profile>) => Promise<void>;
  addXp: (amount: number) => Promise<void>;
  addCoins: (amount: number) => Promise<void>;
};

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [session, setSession] = useState<Session | null>(null);
  const [profile, setProfile] = useState<Profile | null>(null);
  const [loading, setLoading] = useState(true);
  const [isGuest, setIsGuest] = useState(false);

  const guestProfile: Profile = {
    id: 'guest',
    username: 'Гость',
    avatar_url: '/avatar-ghost.webp',
    bio: 'Гостевой режим',
    xp: 0,
    level: 1,
    coins: 100,
    is_online: true,
    last_seen: new Date().toISOString(),
  };

  const fetchProfile = useCallback(async (userId: string) => {
    const { data, error } = await supabase
      .from('profiles')
      .select('*')
      .eq('id', userId)
      .maybeSingle();
    if (error) {
      console.error('Profile fetch error:', error);
      return;
    }
    // Mark as online first, then re-fetch to get the updated is_online value
    await supabase.from('profiles').update({ is_online: true, last_seen: new Date().toISOString() }).eq('id', userId);
    const { data: updated } = await supabase
      .from('profiles')
      .select('*')
      .eq('id', userId)
      .maybeSingle();
    setProfile((updated || data) as Profile | null);
  }, []);

  useEffect(() => {
    const savedGuest = localStorage.getItem('soundscape-guest');
    if (savedGuest === 'true') {
      setIsGuest(true);
      setProfile(guestProfile);
      setLoading(false);
      return;
    }

    supabase.auth.getSession().then(({ data }) => {
      setSession(data.session);
      if (data.session?.user) {
        fetchProfile(data.session.user.id).finally(() => setLoading(false));
      } else {
        setLoading(false);
      }
    });

    const { data: listener } = supabase.auth.onAuthStateChange((_event, newSession) => {
      setSession(newSession);
      if (newSession?.user) {
        fetchProfile(newSession.user.id);
      } else {
        setProfile(null);
      }
    });

    return () => listener.subscription.unsubscribe();
  }, [fetchProfile]);

  const signIn = async (email: string, password: string) => {
    const { error } = await supabase.auth.signInWithPassword({ email, password });
    if (!error) return { error: null };
    const ru: Record<string, string> = {
      'Invalid login credentials': 'Неверный email или пароль',
      'Email not confirmed': 'Email не подтверждён',
    };
    return { error: ru[error.message] || error.message };
  };

  const signUp = async (email: string, password: string, username: string) => {
    const { data, error } = await supabase.auth.signUp({ email, password });
    if (error) {
      const ru: Record<string, string> = {
        'Password is known to be weak and easy to guess, please choose a different one.': 'Пароль слишком простой. Выберите более надёжный пароль (минимум 6 символов).',
        'User already registered': 'Пользователь с таким email уже зарегистрирован',
        'Email rate limit exceeded': 'Слишком много попыток. Попробуйте позже.',
      };
      return { error: ru[error.message] || error.message };
    }
    if (data.user) {
      const { error: profileError } = await supabase.from('profiles').insert({
        id: data.user.id,
        username,
      });
      if (profileError) return { error: profileError.message };
    }
    return { error: null, success: true } as { error: string | null; success?: boolean };
  };

  const signInGuest = () => {
    localStorage.setItem('soundscape-guest', 'true');
    setIsGuest(true);
    setProfile(guestProfile);
  };

  const signOut = async () => {
    if (isGuest) {
      localStorage.removeItem('soundscape-guest');
      setIsGuest(false);
      setProfile(null);
      return;
    }
    if (session?.user) {
      await supabase.from('profiles').update({ is_online: false, last_seen: new Date().toISOString() }).eq('id', session.user.id);
    }
    await supabase.auth.signOut();
    setProfile(null);
    setSession(null);
  };

  // Heartbeat: keep online status fresh while the tab is open
  useEffect(() => {
    if (!session?.user) return;
    const interval = setInterval(async () => {
      await supabase
        .from('profiles')
        .update({ is_online: true, last_seen: new Date().toISOString() })
        .eq('id', session.user.id);
    }, 30000);
    return () => clearInterval(interval);
  }, [session?.user]);

  // Mark offline when the tab closes
  useEffect(() => {
    if (!session?.user) return;
    const handler = () => {
      navigator.sendBeacon(
        `${import.meta.env.VITE_SUPABASE_URL}/rest/v1/profiles?id=eq.${session.user.id}`,
        new Blob(
          [JSON.stringify({ is_online: false, last_seen: new Date().toISOString() })],
          { type: 'application/json' }
        )
      );
    };
    window.addEventListener('beforeunload', handler);
    return () => window.removeEventListener('beforeunload', handler);
  }, [session?.user]);

  const refreshProfile = useCallback(async () => {
    if (session?.user) await fetchProfile(session.user.id);
  }, [session, fetchProfile]);

  const updateProfile = async (updates: Partial<Profile>) => {
    if (isGuest) {
      setProfile((prev) => prev ? { ...prev, ...updates } : prev);
      return;
    }
    if (!session?.user) return;
    const { error } = await supabase
      .from('profiles')
      .update(updates)
      .eq('id', session.user.id);
    if (!error) await refreshProfile();
  };

  const addXp = async (amount: number) => {
    if (!profile) return;
    const newXp = profile.xp + amount;
    const newLevel = Math.floor(newXp / 500) + 1;
    await updateProfile({ xp: newXp, level: newLevel });
  };

  const addCoins = async (amount: number) => {
    if (!profile) return;
    await updateProfile({ coins: profile.coins + amount });
  };

  return (
    <AuthContext.Provider
      value={{ session, profile, loading, isGuest, signIn, signUp, signInGuest, signOut, refreshProfile, updateProfile, addXp, addCoins }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used within AuthProvider');
  return ctx;
}
