import { useState } from 'react';
import { AuthProvider, useAuth } from '@/context/AuthContext';
import { ThemeProvider } from '@/context/ThemeContext';
import AuthScreen from '@/components/AuthScreen';
import Sidebar, { type Page } from '@/components/Sidebar';
import HomePage from '@/pages/HomePage';
import BeatComposerPage from '@/pages/BeatComposerPage';
import AIStudioPage from '@/pages/AIStudioPage';
import MusicSearchPage from '@/pages/MusicSearchPage';
import ChartsPage from '@/pages/ChartsPage';
import ChatPage from '@/pages/ChatPage';
import MessagesPage from '@/pages/MessagesPage';
import GamesPage from '@/pages/GamesPage';
import ProfilePage from '@/pages/ProfilePage';
import BeatsFeedPage from '@/pages/BeatsFeedPage';
import ClansPage from '@/pages/ClansPage';
import PvPBattlesPage from '@/pages/PvPBattlesPage';
import PlaylistsPage from '@/pages/PlaylistsPage';
import CommunitiesPage from '@/pages/CommunitiesPage';
import AboutPage from '@/pages/AboutPage';
import StatsPage from '@/pages/StatsPage';
import SeasonalEventsPage from '@/pages/SeasonalEventsPage';
import DailyRewardsPage from '@/pages/DailyRewardsPage';
import ShopPage from '@/pages/ShopPage';
import AutoMixPage from '@/pages/AutoMixPage';
import AIStudioEnhancedPage from '@/pages/AIStudioEnhancedPage';
import { Loader2 } from 'lucide-react';

function AppContent() {
  const { session, profile, loading, isGuest } = useAuth();
  const [page, setPage] = useState<Page>('home');

  if (loading) {
    return (
      <div className="min-h-screen bg-theme-bg flex items-center justify-center">
        <Loader2 className="w-8 h-8 text-theme-primary animate-spin" />
      </div>
    );
  }

  if (!session && !isGuest) {
    return <AuthScreen />;
  }

  return (
    <div className="min-h-screen bg-theme-bg">
      <Sidebar page={page} setPage={setPage} />
      <main className="lg:ml-64 pt-14 lg:pt-0 min-h-screen">
        <div className={page === 'home' || page === 'about' ? '' : 'p-4 lg:p-8 max-w-6xl mx-auto'}>
          {page === 'home' && <HomePage setPage={setPage} />}
          {page === 'beat' && <BeatComposerPage />}
          {page === 'studio' && <AIStudioPage setPage={setPage} />}
          {page === 'search' && <MusicSearchPage />}
          {page === 'charts' && <ChartsPage />}
          {page === 'chat' && <ChatPage />}
          {page === 'messages' && <MessagesPage />}
          {page === 'games' && <GamesPage />}
          {page === 'profile' && <ProfilePage />}
          {page === 'feed' && <BeatsFeedPage setPage={setPage} />}
          {page === 'clans' && <ClansPage />}
          {page === 'pvp' && <PvPBattlesPage />}
          {page === 'playlists' && <PlaylistsPage />}
          {page === 'communities' && <CommunitiesPage />}
          {page === 'about' && <AboutPage setPage={setPage} />}
          {page === 'stats' && <StatsPage />}
          {page === 'seasonal' && <SeasonalEventsPage />}
          {page === 'daily' && <DailyRewardsPage />}
          {page === 'shop' && <ShopPage />}
          {page === 'automix' && <AutoMixPage />}
          {page === 'ai-enhanced' && <AIStudioEnhancedPage />}
        </div>
      </main>
    </div>
  );
}

function App() {
  return (
    <ThemeProvider>
      <AuthProvider>
        <AppContent />
      </AuthProvider>
    </ThemeProvider>
  );
}

export default App;
